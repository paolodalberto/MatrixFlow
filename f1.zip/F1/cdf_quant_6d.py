"""
cdf_quant_6d.py — CDF of Euclidean distances for pquant_6d
===========================================================
Plots the empirical CDF of d_6 and its three 2D sub-distances
(d_K, d_V, d_T) for turbo vs plain at each requested budget.

Usage:
    python cdf_quant_6d.py metrics_lowrank.csv --budget 4
    python cdf_quant_6d.py metrics_lowrank.csv --budget 2 3 4 5 6
    python cdf_quant_6d.py metrics_lowrank.csv --budget 4 --origin lloyd

Output (per budget):
    <mode>_cdf6d_B<n>.png   — 4-panel CDF figure
    stdout                  — median / MW / KS statistics per distance

Panels (2×2 grid):
    top-left    d_6  =  √(snr_err_K²+dir_err_K²+snr_err_V²+dir_err_V²+snr_err²+dir_err²)
    top-right   d_K  =  √(snr_err_K² + dir_err_K²)   K-cache
    bottom-left d_V  =  √(snr_err_V² + dir_err_V²)   V-cache
    bottom-right d_T =  √(snr_err²   + dir_err²)      attention output T
"""

import sys
import argparse
import pathlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats

from snr_metrics_6d import add_snr_err, SNR_ERR_LM, SCALAR_LOSS

# ── arguments ─────────────────────────────────────────────────────────────────
parser = argparse.ArgumentParser()
parser.add_argument("csv")
parser.add_argument("--budget",   required=True, nargs="+", type=int)
parser.add_argument("--scheme_a", default="KQV")
parser.add_argument("--scheme_b", default="KV")
parser.add_argument("--origin",   choices=["shannon", "lloyd"], default="shannon")
parser.add_argument("--show",     action="store_true")
args = parser.parse_args()

lm   = (args.origin == "lloyd")
suf  = "_lm" if lm else ""

DISTANCES = [
    (f"d_6{suf}",  "d_6",  "6D joint"),
    (f"d_K{suf}",  "d_K",  "K cache"),
    (f"d_V{suf}",  "d_V",  "V cache"),
    (f"d_T{suf}",  "d_T",  "T output"),
]

COLOR_A = "#D65F5F"   # turbo — orange/red
COLOR_B = "#4DAF4A"   # plain — green

# ── load ──────────────────────────────────────────────────────────────────────
df_raw = add_snr_err(pd.read_csv(args.csv))
mode   = pathlib.Path(args.csv).stem.replace("metrics_", "")

# ── helper: empirical CDF ─────────────────────────────────────────────────────
def ecdf(x):
    xs = np.sort(x)
    ys = np.arange(1, len(xs) + 1) / len(xs)
    return xs, ys

# ── helper: MW + KS stats ─────────────────────────────────────────────────────
def two_sample_stats(a, b):
    mw  = stats.mannwhitneyu(a, b, alternative="two-sided")
    ks  = stats.ks_2samp(a, b)
    r   = 1.0 - 2.0 * mw.statistic / (len(a) * len(b))
    return mw.pvalue, ks.statistic, ks.pvalue, r

# ── per-budget loop ───────────────────────────────────────────────────────────
for n in sorted(args.budget):
    sub = df_raw[df_raw["budget"] == n]
    if sub.empty:
        print(f"WARNING: no rows for budget={n}", file=sys.stderr)
        continue

    da = sub[sub["scheme"] == args.scheme_a]
    db = sub[sub["scheme"] == args.scheme_b]

    if da.empty or db.empty:
        print(f"WARNING: budget={n} missing one scheme", file=sys.stderr)
        continue

    print(f"\n── budget={n}  {args.scheme_a} vs {args.scheme_b}  "
          f"({'LM' if lm else 'Shannon'} origin) ──────")

    origin_tag = "Lloyd-Max-normalised" if lm else "Shannon-normalised"
    fig, axes = plt.subplots(2, 2, figsize=(11, 8))
    fig.suptitle(
        f"CDF of Euclidean distances [{origin_tag}] — budget={n}   mode: {mode}\n"
        f"{args.scheme_a} (orange) vs {args.scheme_b} (green)   "
        f"lower = better",
        fontsize=10)

    for ax, (col, short, title) in zip(axes.flat, DISTANCES):
        if col not in da.columns:
            ax.set_visible(False)
            continue

        a_vals = da[col].values
        b_vals = db[col].values

        mw_p, ks_d, ks_p, r_mw = two_sample_stats(a_vals, b_vals)

        xa, ya = ecdf(a_vals)
        xb, yb = ecdf(b_vals)

        ax.plot(xa, ya, color=COLOR_A, lw=1.8, label=args.scheme_a)
        ax.plot(xb, yb, color=COLOR_B, lw=1.8, label=args.scheme_b)

        # median markers
        med_a = np.median(a_vals)
        med_b = np.median(b_vals)
        ax.axvline(med_a, color=COLOR_A, lw=0.8, ls="--", alpha=0.7)
        ax.axvline(med_b, color=COLOR_B, lw=0.8, ls="--", alpha=0.7)

        # Lloyd-Max reference on d_T (2D sub-distance at LM point on x-axis)
        if short == "d_T" and not lm:
            ax.axvline(SNR_ERR_LM, color="steelblue", lw=0.8, ls=":", alpha=0.6)
            ax.text(SNR_ERR_LM + 0.01, 0.05, f"LM≈{SNR_ERR_LM:.2f}",
                    fontsize=7, color="steelblue")

        ax.set_title(f"{short}  —  {title}", fontsize=9)
        ax.set_xlabel(col, fontsize=8)
        ax.set_ylabel("CDF", fontsize=8)
        ax.set_xlim(left=0)
        ax.set_ylim(0, 1.05)
        ax.grid(True, alpha=0.3)
        ax.legend(fontsize=8, loc="lower right")

        # stats annotation
        stats_txt = (f"med {args.scheme_a}={med_a:.3f}  "
                     f"med {args.scheme_b}={med_b:.3f}\n"
                     f"MW p={mw_p:.2e}  r={r_mw:+.3f}\n"
                     f"KS D={ks_d:.3f}  p={ks_p:.2e}")
        ax.text(0.97, 0.05, stats_txt, transform=ax.transAxes,
                fontsize=7, ha="right", va="bottom",
                bbox=dict(boxstyle="round,pad=0.3", fc="white", alpha=0.7))

        print(f"  {short:<4}  med {args.scheme_a}={med_a:.4f}  "
              f"med {args.scheme_b}={med_b:.4f}  "
              f"MW p={mw_p:.2e}  r={r_mw:+.3f}  "
              f"KS D={ks_d:.3f}  p={ks_p:.2e}")

    plt.tight_layout()
    out_png = f"{mode}_cdf6d_B{n}.png"
    fig.savefig(out_png, dpi=150, bbox_inches="tight")
    print(f"  → {out_png}")
    if args.show:
        plt.show()
    plt.close(fig)
