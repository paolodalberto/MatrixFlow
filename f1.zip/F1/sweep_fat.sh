 #hipcc -O3 -o pquant_hip_metrics pquant_hip_metrics.hip -lrocblas

 #for nu in 10 5 3 2 1.5 1.2 1.05; do
 #    ./pquant_hip_metrics --trials 100 --seed 42 fattail --nu $nu > metrics_fattail_nu${nu}.csv &
 #done
 #wait 
 
#  Then analyze — focusing on budget 4 where you expect the first crossover:

 for nu in 10 5 3 2 1.5 1.2 1.05; do
     echo "=== nu=$nu === --scheme_a QKQV --scheme_b KQV "
     python3 compare_quant_6d.py metrics_fattail_nu${nu}.csv --budget 2 3 4 5 6 7  --n_perm 999 --scheme_a QKQV --scheme_b KQV 
 done
 for nu in 10 5 3 2 1.5 1.2 1.05; do
     echo "=== nu=$nu === --scheme_a KQV --scheme_b KV"
     python3 compare_quant_6d.py metrics_fattail_nu${nu}.csv --budget 2 3 4 5 6 7  --n_perm 999 --scheme_a KQV --scheme_b KV  
 done
 
