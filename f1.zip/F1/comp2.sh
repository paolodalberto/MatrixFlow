
  # KQV vs KV  (value of WHT + QJL-on-V)
  for f in metrics_lowrank.csv metrics_fattail.csv metrics_focused.csv metrics_random.csv; do
      echo "=== $f  KQV vs KV ==="
      python3 compare_quant_6d.py $f --budget 2 3 4 5 6 7 --scheme_a KQV --scheme_b KV --n_perm 999
  done

  # KQV vs QKQV  (cost of QJL-on-K)
  for f in metrics_lowrank.csv metrics_fattail.csv metrics_focused.csv metrics_random.csv; do
      echo "=== $f  KQV vs QKQV ==="
      python3 compare_quant_6d.py $f --budget 2 3 4 5 6 7 --scheme_a KQV --scheme_b QKQV --n_perm 999
  done
