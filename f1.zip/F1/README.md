# pquant_6d — KV Cache Quantization Benchmark

GPU benchmark and statistical analysis for three KV-cache quantization schemes,
evaluated on a 6-dimensional error geometry across multiple attention-distribution regimes.

---

## 1. The Three Schemes

At bit budget `n` per element, every scheme allocates the same total bits to K and V:

| Scheme | K cache | V cache | WHT | QJL |
|--------|---------|---------|-----|-----|
| **KV**   | Lloyd-Max scalar @ n bits | Lloyd-Max scalar @ n bits | No | No |
| **KQV**  | WHT + Lloyd-Max scalar @ n bits | WHT + Lloyd-Max scalar @ (n−1) bits + 1 QJL bit | K+V | V only |
| **QKQV** | WHT + Lloyd-Max scalar @ (n−1) bits + 1 QJL bit | WHT + Lloyd-Max scalar @ (n−1) bits + 1 QJL bit | K+V | K+V |

**Effective bit budgets:**
- KV: K\_eff = V\_eff = n
- KQV: K\_eff = n (scalar only), V\_eff = (n−1) scalar + 1 QJL
- QKQV: K\_eff = V\_eff = (n−1) scalar + 1 QJL

All three have the same Shannon ceiling at budget n, so comparisons are fair.

**Components:**
- **WHT**: Walsh-Hadamard Transform preceded by a random ±1 sign flip (`s` vector), i.e., `H·diag(s)`. This is a fast randomised JL projection that spreads energy uniformly regardless of input structure.
- **QJL**: Johnson-Lindenstrauss binary sketch of the WHT residual. Captures the direction of quantisation error at 1 bit/dimension.
- **Lloyd-Max**: optimal scalar quantiser for the Beta((D−1)/2, (D−1)/2) marginal that WHT produces for near-spherical inputs (D=128).

---

## 2. The 6D Error Vector

Every (scheme, budget, S, Nq) configuration produces a point in R^6:

```
e = (snr_err_K, dir_err_K, snr_err_V, dir_err_V, snr_err, dir_err)
```

| Dimension | Formula | Meaning |
|-----------|---------|---------|
| `snr_err_K` | clip(1 − SNR\_K\_actual / SNR\_K\_shannon, 0, 1) | K-cache scale error vs Shannon ceiling |
| `dir_err_K` | 1 − ptcosine\_K | K-cache direction error (per-token cosine) |
| `snr_err_V` | clip(1 − SNR\_V\_actual / SNR\_V\_shannon, 0, 1) | V-cache scale error |
| `dir_err_V` | 1 − ptcosine\_V | V-cache direction error |
| `snr_err`   | clip(1 − SNR\_actual / SNR\_shannon, 0, 1) | End-to-end attention output scale error |
| `dir_err`   | 1 − cosine(out, out\_ref) | Attention output direction error |

The ideal point is the origin (0,0,0,0,0,0). The 6D Euclidean distance is:

```
d_6 = sqrt(snr_err_K^2 + dir_err_K^2 + snr_err_V^2 + dir_err_V^2 + snr_err^2 + dir_err^2)
```

A Lloyd-Max-normalised variant (`_lm` suffix) shifts the origin to the scalar-optimal point
(SNR = 2^(2n) / π√3), expanding the useful range near the engineering target.

**Reference computation**: all four attention passes (reference fp32, quantised fp32,
K-isolation, V-isolation) run on GPU. The reference is the unquantised GPU fp32 path,
not CPU attention, making the benchmark precision-agnostic and generalisable to fp8.

---

## 3. Files

| File | Role |
|------|------|
| `pquant_hip_metrics.hip` | HIP/GPU benchmark — generates CSV |
| `snr_metrics_6d.py` | Core metric transforms (`add_snr_err`, `energy_distance`) |
| `compare_quant_6d.py` | Per-budget statistical comparison (energy distance, MW, scatter plot) |
| `cdf_quant_6d.py` | CDF plots for all 6 dimensions |
| `CSV/metrics_random.csv` | Baseline: random Gaussian K/V |
| `CSV/metrics_lowrank.csv` | Baseline: lowrank (rank=8) |
| `CSV/metrics_fattail.csv` | Baseline: fat-tail Student-t (ν=3) |
| `CSV/metrics_focused.csv` | Baseline: focused attention (noise=0.1) |
| `CSV/metrics_lowrank_r{1,2,4,8,16,32,64}.csv` | Rank sweep data |
| `CSV/metrics_fattail_nu{10,5,3,2,1.5,1.2,1.05}.csv` | ν sweep data |
| `PNG/` | All scatter PNGs from compare_quant_6d.py |

---

## 4. Build and Run

### Compile

```bash
hipcc -O3 -o pquant_hip_metrics pquant_hip_metrics.hip -lrocblas
```

### CLI

```
./pquant_hip_metrics [OPTIONS] MODE
```

**Modes:** `random`, `lowrank`, `fattail`, `focused`

**Options (all named, no positional numeric args):**

| Flag | Default | Description |
|------|---------|-------------|
| `--seed N` | 42 | RNG seed |
| `--trials N` | 20 | Trials per (scheme, budget, S, Nq) configuration |
| `--rank N` | 8 | Rank for `lowrank` mode |
| `--nu N` | 3.0 | Degrees of freedom for `fattail` mode |
| `--noise N` | 0.1 | Query noise level for `focused` mode |

**Important:** bare positive integers are parsed as `--seed`. Always use named flags for
numeric parameters other than seed.

### Generate the four baselines

```bash
mkdir -p CSV PNG

./pquant_hip_metrics --seed 42 --trials 100 random  > CSV/metrics_random.csv  &
./pquant_hip_metrics --seed 42 --trials 100 lowrank > CSV/metrics_lowrank.csv &
./pquant_hip_metrics --seed 42 --trials 100 fattail > CSV/metrics_fattail.csv &
./pquant_hip_metrics --seed 42 --trials 100 focused > CSV/metrics_focused.csv &
wait
```

---

## 5. Analysis

### Per-budget scatter + statistics

```bash
python compare_quant_6d.py CSV/metrics_lowrank.csv \
    --budget 2 3 4 5 6 7 \
    --scheme_a KQV --scheme_b QKQV \
    --outdir PNG
```

**MW r convention:** positive r means scheme\_a has *lower* d\_6 (scheme\_a wins).
Negative r means scheme\_b wins.

The script reports:
- Energy distance in 6D (Shannon and Lloyd-Max coordinates) + permutation p-value
- Mann-Whitney U with rank-biserial r
- Per-dimension medians for all 6 components
- Scatter PNG: shape encodes component (● K, ▲ V, ■ T), colour encodes scheme

NaN/inf rows are automatically filtered with a per-scheme count printed to stderr.

### CDF plots

```bash
python cdf_quant_6d.py CSV/metrics_fattail.csv --budget 4
```

---

## 6. Reproducing the Sweeps

### Fat-tail ν sweep (ν = 10, 5, 3, 2, 1.5, 1.2, 1.05)

```bash
mkdir -p CSV PNG

for nu in 10 5 3 2 1.5 1.2 1.05; do
    ./pquant_hip_metrics --seed 42 --trials 100 fattail --nu $nu \
        > CSV/metrics_fattail_nu${nu}.csv &
done
wait

for nu in 10 5 3 2 1.5 1.2 1.05; do
    echo "=== nu=$nu === --scheme_a QKQV --scheme_b KQV"
    python compare_quant_6d.py CSV/metrics_fattail_nu${nu}.csv \
        --budget 2 3 4 5 6 7 --scheme_a QKQV --scheme_b KQV \
        --outdir PNG
    echo "=== nu=$nu === --scheme_a KQV --scheme_b KV"
    python compare_quant_6d.py CSV/metrics_fattail_nu${nu}.csv \
        --budget 2 3 4 5 6 7 --scheme_a KQV --scheme_b KV \
        --outdir PNG
done
```

Expect NaN/inf warnings at ν ≤ 1.5 for some (S, Nq) — fp32 overflow at extreme tails.
The filter drops those rows and reports counts; statistics are valid on the remainder.

### Lowrank rank sweep (rank = 1, 2, 4, 8, 16, 32, 64)

```bash
mkdir -p CSV PNG

for rank in 1 2 4 8 16 32 64; do
    ./pquant_hip_metrics --seed 42 --trials 100 lowrank --rank $rank \
        > CSV/metrics_lowrank_r${rank}.csv &
done
wait

for rank in 1 2 4 8 16 32 64; do
    echo "=== rank=$rank === --scheme_a QKQV --scheme_b KQV"
    python compare_quant_6d.py CSV/metrics_lowrank_r${rank}.csv \
        --budget 2 3 4 5 6 7 --scheme_a QKQV --scheme_b KQV \
        --outdir PNG
    echo "=== rank=$rank === --scheme_a KQV --scheme_b KV"
    python compare_quant_6d.py CSV/metrics_lowrank_r${rank}.csv \
        --budget 2 3 4 5 6 7 --scheme_a KQV --scheme_b KV \
        --outdir PNG
done
```

---

## 7. Experimental Findings

### 7.1 QKQV vs KQV — the alternating pattern

**Result:** QKQV wins at odd budgets (n=2, 3, 5, 7); KQV wins at even budgets (n=4, 6).

This alternation is:
- **Rank-invariant**: holds at all ranks 1–64 in lowrank mode
- **Nearly ν-invariant**: holds at all ν=10 down to 1.05 in fattail mode, with two exceptions

**Exceptions:**
1. **n=3 at high rank or near-Gaussian inputs**: effect size shrinks to zero (indeterminate at r=32,64 or ν≥5). The alternation sign stays positive but p is no longer significant.
2. **n=5 at extreme heavy tails (ν ≤ 1.2)**: KQV wins instead of QKQV. Mechanism: at extreme concentration (softmax near one-hot), QJL direction error on K compounds with peaked attention weights and drives output `dir_err` much higher for QKQV (0.23 vs 0.08 at ν=1.2, n=5).

**Mechanism of the alternation:** at odd n, QJL's 1-bit residual on K (QKQV) captures direction information that (n−1)-bit scalar misses; at even n, n-bit scalar on K (KQV) is more efficient than (n−1)+QJL. This is a rate-distortion crossover in the Beta codebook vs JL residual plane — stated as an open problem without first-principles derivation.

### 7.2 KQV vs KV — WHT protection depends on attention structure

**Result:** not universally one-sided. The winner depends on the attention regime.

#### Fattail mode: KQV wins universally

KQV wins at all budgets and all ν, with effect size growing monotonically as tails get heavier.
The decisive signal is `dir_err_K`. At ν=1.05, n=4:
- KQV `dir_err_K` = 0.027, KV `dir_err_K` = 0.199 — a 7× gap
- Translated to output: KQV `dir_err` = 0.178, KV `dir_err` = 0.703

WHT's randomised projection corrects the component-wise direction bias that heavy tails create.
KV's plain codebook cannot handle the outlier-dominated directions.

**KV saturation:** at n=2, ν ≤ 1.5, KV's 2-level codebook catastrophically fails without WHT
(`ptrelMSE_K > 1`, reconstruction error exceeds signal energy). KQV/QKQV do not saturate.

#### Lowrank mode: rank-dependent at even budgets

| n | Winner | Condition |
|---|--------|-----------|
| 2 | KQV | All ranks |
| 3 | KQV | All ranks |
| 4 | KV | rank ≤ 8 |
| 4 | KQV | rank ≥ 16 (weakly, p < 0.05) |
| 5 | KQV | All ranks |
| 6 | KV | All ranks (weakens at r=64) |
| 7 | KQV | All ranks |

**Mechanism:** at low rank, all K vectors lie near a low-dimensional subspace.
Scalar quantisation recovers the direction of near-degenerate vectors well even without WHT
(the codebook naturally aligns with the subspace). Inspect `dir_err_K` at rank=1, n=6:

- KQV: 0.0032, KV: 0.0033 — **essentially identical**

WHT's K-direction protection disappears when K is near-degenerate. What remains is the cost:
KQV's V uses (n−1) scalar bits instead of n, giving worse `snr_err_V` and `dir_err_V`.
At even budgets where this cost is largest, KV wins.

Contrast with fattail ν=3, n=6:
- KQV `dir_err_K` = 0.0033, KV `dir_err_K` = 0.0208 — a 6× gap

The presence or absence of WHT's K-direction benefit is the single variable that switches the winner.

### 7.3 Invariants across all regimes

1. **n=2, 5, 7**: QKQV > KQV > KV in every regime tested. These are stable.
2. **n=6**: KQV > QKQV in every regime (even lowrank KV-wins at n=6 is KV > KQV, not KV > QKQV). QKQV is consistently worst at n=6.
3. **V direction** (dir\_err\_V): any scheme with QJL on V beats any without, at every budget and in every regime. QJL's benefit on V is unconditional.
4. **K saturation threshold**: the first regime where KV reconstruction fails outright (ptrelMSE\_K > 1) is n=2 + extreme heavy tails. KQV/QKQV never saturate in the tested range.

---

## 8. Open Problem

Under what condition does (n−1)-bit scalar + 1-bit QJL produce lower ‖K − K̂‖²/‖K‖²
than n-bit scalar alone? The crossover budget n\* should be derivable from the Beta codebook
rate-distortion curve and the JL residual variance as a function of n and D, but no
closed-form derivation has been found. The crossover at n=2 (QKQV wins K) and n=4 (KQV wins K)
is empirically stable across all regimes.

---

## 9. Theoretical Notes

### Why WHT but not QJL on K

K enters softmax as `Q·K^T / √D`. Errors propagate nonlinearly — softmax exponentially amplifies
score differences. A QJL-reconstructed K̂ has O(1/√m) per-component direction error, but the
resulting inner product error `Q·(K̂ − K)^T` is not small relative to inter-key score differences
at D=128. QJL cannot be exactly inverted, which is acceptable for V (linear aggregation, errors
average out over sequence length) but catastrophic for K (argmax softmax collapse).

WHT is exactly invertible: `K̂ = H^T · diag(s) · dequantise(diag(s)·H·K)`. The only error is
scalar quantisation noise, which is reduced by WHT's energy spreading.

### WHT = distribution-free energy spreading

`H·diag(s)` is a fast randomised JL projection. For any fixed input vector x, the projected
coordinates are approximately i.i.d. regardless of the structure of x. This means:
- WHT's benefit is rank-independent in principle (confirmed empirically at ranks 1–64)
- Plain WHT without the random signs would fail for lowrank inputs (energy concentrates in the Hadamard coefficient aligned with the subspace basis)
- The Lloyd-Max codebook, optimal for the uniform-sphere marginal, is approximately valid at every rank

In practice the rank-independence breaks down only when WHT's K-direction protection was
already unnecessary (K is near-degenerate, as in lowrank mode), not because the JL guarantee fails.

### p-value interpretation

`p = P(statistic ≥ observed | H₀)` — probability of seeing a result at least this extreme
under the null hypothesis of equal distributions. It is not the error committed. Small p = strong
evidence against H₀. The Phipson & Smyth (2010) permutation correction `p = (count + 1) / (n_perm + 1)`
keeps p > 0 and controls type-I error at small n\_perm.
