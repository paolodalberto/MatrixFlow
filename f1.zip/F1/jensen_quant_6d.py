"""
jensen_quant_6d.py — Jensen bridge figure
==========================================
Three-panel scatter showing the K-driven causal chain:

    dir_err_K  →  KL(p_ref ‖ p_quant)   [left   — K errors corrupt attention]
    KL         →  1 − topk5 recall       [middle — attention distortion → routing]
    KL         →  dir_err               [right  — attention distortion → output]

Note: KL = KL(softmax(QK^T) ‖ softmax(QK̂^T)). V never enters the softmax,
so V quantisation has identically zero effect on KL. The three panels show
the complete K-driven path; V's separate linear path is not shown here.

Usage:
    python jensen_quant_6d.py CSV/metrics_fattail.csv
    python jensen_quant_6d.py CSV/metrics_fattail_nu*.csv --outdir PNG
    python jensen_quant_6d.py CSV/metrics_fattail.csv CSV/metrics_lowrank.csv \\
        --label fattail lowrank --outdir PNG
"""

import argparse
import pathlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.lines

from snr_metrics_6d import add_snr_err

# ── arguments ─────────────────────────────────────────────────────────────────
parser = argparse.ArgumentParser()
parser.add_argument("csvs", nargs="+", help="one or more metrics CSV files")
parser.add_argument("--label", nargs="*", default=None,
                    help="short label per CSV file (used in output filename)")
parser.add_argument("--budget", nargs="*", type=int, default=None,
                    help="budgets to include (default: all)")
parser.add_argument("--outdir", default=".",
                    help="output directory for PNG (default: current dir)")
parser.add_argument("--alpha",  type=float, default=0.35)
parser.add_argument("--logkl", action="store_true",
                    help="log scale on KL axis (recommended when pooling modes)")
parser.add_argument("--show",  action="store_true")
args = parser.parse_args()

pathlib.Path(args.outdir).mkdir(parents=True, exist_ok=True)

# ── scheme colours and markers ────────────────────────────────────────────────
SCHEME_STYLE = {
    "KQV":  dict(color="#D65F5F", marker="o", label="KQV"),
    "QKQV": dict(color="#8B5CF6", marker="^", label="QKQV"),
    "KV":   dict(color="#4DAF4A", marker="s", label="KV"),
}
BUDGET_SIZES = {2: 12, 3: 18, 4: 26, 5: 36, 6: 48, 7: 62}

# ── load and merge ─────────────────────────────────────────────────────────────
frames = []
for i, path in enumerate(args.csvs):
    df = add_snr_err(pd.read_csv(path))
    tag = args.label[i] if (args.label and i < len(args.label)) else \
          pathlib.Path(path).stem.replace("metrics_", "")
    df["_tag"] = tag
    frames.append(df)
df_all = pd.concat(frames, ignore_index=True)

if args.budget:
    df_all = df_all[df_all["budget"].isin(args.budget)]

# drop NaN/inf rows
_guard = ["dir_err_K", "dir_err", "KL", "topk5"]
mask = df_all[_guard].replace([np.inf, -np.inf], np.nan).isna().any(axis=1)
if mask.sum():
    print(f"  dropping {mask.sum()} NaN/inf rows")
df_all = df_all[~mask].copy()

df_all["routing_err"] = 1.0 - df_all["topk5"]

# ── figure ────────────────────────────────────────────────────────────────────
fig, axes = plt.subplots(1, 3, figsize=(15, 5))

panels = [
    dict(ax=axes[0], x="dir_err_K", y="KL",
         xlabel="dir_err_K   (1 − cos K, K̂)",
         ylabel="KL( p_ref ‖ p_quant )  [nats]",
         title="K error → attention distortion"),
    dict(ax=axes[1], x="KL", y="routing_err",
         xlabel="KL( p_ref ‖ p_quant )  [nats]",
         ylabel="1 − topk5 recall",
         title="Attention distortion → routing corruption"),
    dict(ax=axes[2], x="KL", y="dir_err",
         xlabel="KL( p_ref ‖ p_quant )  [nats]",
         ylabel="dir_err   (1 − cos T, T̂)",
         title="Attention distortion → output error"),
]

schemes_present = [s for s in ["KQV", "QKQV", "KV"] if s in df_all["scheme"].unique()]

for p in panels:
    ax = p["ax"]
    for scheme in schemes_present:
        sub = df_all[df_all["scheme"] == scheme]
        st  = SCHEME_STYLE[scheme]
        sizes = sub["budget"].map(lambda b: BUDGET_SIZES.get(b, 20))
        ax.scatter(sub[p["x"]], sub[p["y"]],
                   c=st["color"], marker=st["marker"],
                   s=sizes, alpha=args.alpha,
                   edgecolors="none", zorder=3)
    ax.set_xlabel(p["xlabel"], fontsize=10)
    ax.set_ylabel(p["ylabel"], fontsize=10)
    ax.set_title(p["title"], fontsize=10)
    ax.grid(True, alpha=0.3)
    if args.logkl:
        if p["x"] == "KL":
            ax.set_xscale("log")
            ax.set_xlim(left=1e-3)
        elif p["y"] == "KL":
            ax.set_yscale("log")
            ax.set_ylim(bottom=1e-3)
        else:
            ax.set_xlim(left=0)
            ax.set_ylim(bottom=0)
    else:
        ax.set_xlim(left=0)
        ax.set_ylim(bottom=0)

# ── shared legend ─────────────────────────────────────────────────────────────
legend_handles = [
    matplotlib.lines.Line2D([0], [0], marker=SCHEME_STYLE[s]["marker"],
                             color=SCHEME_STYLE[s]["color"],
                             ls="none", markersize=8, label=s)
    for s in schemes_present
] + [
    matplotlib.lines.Line2D([0], [0], marker="o", color="gray",
                             ls="none", markersize=sz**0.5,
                             label=f"n={b}")
    for b, sz in sorted(BUDGET_SIZES.items())
    if b in df_all["budget"].unique()
]
fig.legend(handles=legend_handles, fontsize=8,
           loc="lower center", ncol=len(legend_handles),
           bbox_to_anchor=(0.5, -0.04))

tag_str = "_".join(args.label) if args.label else \
          "_".join(pathlib.Path(c).stem.replace("metrics_", "") for c in args.csvs)
if len(tag_str) > 60:
    tag_str = tag_str[:60]

fig.suptitle(
    f"Jensen bridge — K error → KL → routing corruption → output error\n"
    f"(KL is by construction K-only: V never enters softmax)\n"
    f"data: {tag_str}",
    fontsize=10)

plt.tight_layout(rect=[0, 0.05, 1, 1])
out_png = str(pathlib.Path(args.outdir) / f"jensen_{tag_str}.png")
fig.savefig(out_png, dpi=150, bbox_inches="tight")
print(f"→ {out_png}")
if args.show:
    plt.show()
plt.close(fig)
