 #hipcc -O3 -o pquant_hip_metrics pquant_hip_metrics.hip -lrocblas


  #for rank in 1 2 4 8 16 32 64; do
  #    ./pquant_hip_metrics --trials 100 --seed 42 lowrank --rank $rank \
  #        > metrics_lowrank_r${rank}.csv &
  #done
  #wait

  #Then analyze:
  for rank in 1 2 4 8 16 32 64; do
      echo "=== rank=$rank === --scheme_a QKQV --scheme_b KQV"
      python compare_quant_6d.py metrics_lowrank_r${rank}.csv \
          --budget 2 3 4 5 6 7 --n_perm 999 \
          --scheme_a QKQV --scheme_b KQV 
  done
  for rank in 1 2 4 8 16 32 64; do
      echo "=== rank=$rank === --scheme_a KQV --scheme_b KV"
      python compare_quant_6d.py metrics_lowrank_r${rank}.csv \
          --budget 2 3 4 5 6 7 --n_perm 999 \
          --scheme_a KQV --scheme_b KV 
  done
