
hipcc -O3 -o pquant_hip_metrics pquant_hip_metrics.hip -lrocblas


./pquant_hip_metrics --trials 100  --seed 42 lowrank  --rank 8   | tee metrics_lowrank.csv &
./pquant_hip_metrics --trials 100 --seed 42 focused  --noise 0.1| tee metrics_focused.csv &
./pquant_hip_metrics --trials 100 --seed 42 fattail  --nu 3     | tee metrics_fattail.csv &
./pquant_hip_metrics --trials 100 --seed 42 random              | tee metrics_random.csv &




#The mode and param are printed to stderr so they don't pollute the CSV:
#[pquant_hip_metrics] seed=42  mode=lowrank  param=8.0
