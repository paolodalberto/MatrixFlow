"""
four_scheme_ablation.py  —  compute Table 4: four-scheme ablation at b=2
=========================================================================
Reports dir_err_T, energy distance vs plain SQ, and 1-topk5 for the four
SQ ablation schemes at a given budget and regime.

Energy distance: E(A,B) = 2*E[|a-b|] - E[|a-a'|] - E[|b-b'|]
computed on the 2D (AS, NF) point cloud per trial.

Usage:
    python four_scheme_ablation.py sq_d256_t200.csv
    python four_scheme_ablation.py sq_d256_t200.csv --budget 2 --regime lowrank
"""

import argparse
import numpy as np
import pandas as pd
from itertools import combinations

ap = argparse.ArgumentParser()
ap.add_argument("csv")
ap.add_argument("--budget",  type=int, default=2)
ap.add_argument("--regime",  default="lowrank")
ap.add_argument("--schemes", nargs="+",
                default=["SQ-uniform", "SQ-uniform-qjlK",
                         "SQ-uniform-qjlV", "SQ-uniform-qjlKV"])
args = ap.parse_args()

df = pd.read_csv(args.csv)
df.columns = [c.strip() for c in df.columns]
df["AS"] = 1.0 - df["cosine"]
df["NF"] = df["relMSE"] / (1.0 + df["relMSE"])
df["dir_err_T"] = df["AS"]

sub = df[(df["regime"] == args.regime) & (df["budget"] == args.budget)]

def energy_distance(A, B):
    """Energy distance between two 2D point clouds A, B (n x 2 arrays)."""
    def mean_dist(X, Y):
        # E[||x - y||] over all pairs — use broadcasting for small clouds
        # For large clouds subsample to 500 per side
        n = min(len(X), 500)
        m = min(len(Y), 500)
        Xi = X[np.random.choice(len(X), n, replace=False)]
        Yi = Y[np.random.choice(len(Y), m, replace=False)]
        diff = Xi[:, np.newaxis, :] - Yi[np.newaxis, :, :]
        return np.sqrt((diff**2).sum(axis=2)).mean()
    rng = np.random.default_rng(42)
    return 2 * mean_dist(A, B) - mean_dist(A, A) - mean_dist(B, B)

# reference point cloud for energy distance
plain_rows = sub[sub["scheme"] == args.schemes[0]][["AS", "NF"]].values

print(f"Four-scheme ablation at b={args.budget}, regime={args.regime}")
print(f"Source: {args.csv}")
print()
print(f"{'Scheme':28s}  {'dir_err_T':>10}  {'E_dist_vs_plain':>16}  {'1-topk5':>8}")
print("-" * 70)

results = []
for scheme in args.schemes:
    rows = sub[sub["scheme"] == scheme]
    if rows.empty:
        print(f"{scheme:28s}  NO DATA")
        continue

    det  = rows["dir_err_T"].median()
    tk5  = (1 - rows["topk5"]).median()
    cloud = rows[["AS", "NF"]].values

    if scheme == args.schemes[0]:
        edist = 0.0
        edist_str = "---"
    else:
        edist = energy_distance(plain_rows, cloud)
        edist_str = f"{edist:.4f}"

    print(f"{scheme:28s}  {det:>10.4f}  {edist_str:>16}  {tk5:>8.4f}")
    results.append((scheme, det, edist, tk5))

print()
print("LaTeX rows:")
for scheme, det, edist, tk5 in results:
    edist_str = "---" if edist == 0 else f"{edist:.3f}"
    print(f"{scheme:28s} & {det:.3f} & {edist_str} & {tk5:.3f} \\\\")
