"""
plot_results.py — visualize sweep_results/sweep_all.csv
========================================================

Produces four figures:

  Fig 1  rate_distortion.png
         T 1-cos vs total_bits_K per regime (rate-distortion curves)
         One subplot per regime; lines per scheme; fixed n_tokens=4096, n_queries=64

  Fig 2  scaling_tokens.png
         T 1-cos vs n_tokens at fixed budget=3 per regime
         Shows how quality changes with context length

  Fig 3  throughput.png
         Encode throughput (tokens/sec) vs n_tokens per scheme
         Shows computational scaling

  Fig 4  accuracy_vs_time.png
         T 1-cos vs encode time per token (ms) — Pareto frontier
         One point per (scheme, budget, n_tokens)

Usage
-----
    python plot_results.py                                  # default input
    python plot_results.py --csv sweep_results/sweep_all.csv
    python plot_results.py --out_dir plots
"""

from __future__ import annotations
import argparse
import os

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

# ── colour / style map ─────────────────────────────────────────────────────────
SCHEME_STYLE = {
    "Plain-KV":      dict(color="#888888", ls=":",  marker="x", lw=1.5),
    "TQ-KV":         dict(color="#1f77b4", ls="-",  marker="o", lw=2),
    "TQ-QKV":        dict(color="#aec7e8", ls="--", marker="s", lw=1.5),
    "TQ-KQV":        dict(color="#ff7f0e", ls="--", marker="^", lw=1.5),
    "TQ-QKQV":       dict(color="#ffbb78", ls=":",  marker="D", lw=1.5),
    "SQ-uniform":    dict(color="#2ca02c", ls="-",  marker="o", lw=2),
    "SQ-waterfill":  dict(color="#98df8a", ls="--", marker="s", lw=1.5),
    "SQ-wf-qjl-K":  dict(color="#d62728", ls=":",  marker="^", lw=1.5),
    "SQ-wf-qjl-V":  dict(color="#9467bd", ls="-",  marker="D", lw=2),
    "SQ-wf-qjl-KV": dict(color="#c5b0d5", ls="--", marker="x", lw=1.5),
}

KEY_SCHEMES = [
    "Plain-KV", "TQ-KV", "TQ-KQV",
    "SQ-uniform", "SQ-waterfill", "SQ-wf-qjl-V",
]

METRIC_LABEL = {
    "dirT":      "T  1 − cosine  (↓ better)",
    "relMSE":    "T  rel-MSE  (↓ better)",
    "kl_sm":     "SM KL-divergence  (↓ better)",
    "ptrelMSE_K":"K  rel-MSE  (↓ better)",
}


def load(csv_path):
    df = pd.read_csv(csv_path)
    if "dirT" not in df.columns:
        df["dirT"] = 1 - df["cosine"]
    if "dirK" not in df.columns:
        df["dirK"] = 1 - df["ptcosine_K"]
    return df


# ── Figure 1: rate-distortion ──────────────────────────────────────────────────

def fig_rate_distortion(df, out_dir, metric="dirT",
                        n_tokens_fixed=4096, n_queries_fixed=64):
    sub = df[
        (df["n_tokens"]  == n_tokens_fixed) &
        (df["n_queries"] == n_queries_fixed) &
        (df["scheme"].isin(KEY_SCHEMES))
    ]
    regimes = sorted(sub["regime"].unique())
    ncols = min(3, len(regimes))
    nrows = int(np.ceil(len(regimes) / ncols))

    fig, axes = plt.subplots(nrows, ncols, figsize=(5 * ncols, 4 * nrows),
                             squeeze=False)
    fig.suptitle(
        f"Rate–Distortion  |  {METRIC_LABEL[metric]}\n"
        f"n_tokens={n_tokens_fixed}  n_queries={n_queries_fixed}  d_h=128",
        fontsize=12,
    )

    for ax_idx, regime in enumerate(regimes):
        ax = axes[ax_idx // ncols][ax_idx % ncols]
        rsub = sub[sub["regime"] == regime].copy()

        for scheme in KEY_SCHEMES:
            ssub = rsub[rsub["scheme"] == scheme].sort_values("total_bits_K")
            if ssub.empty:
                continue
            style = SCHEME_STYLE.get(scheme, {})
            ax.plot(
                ssub["total_bits_K"], ssub[metric],
                label=scheme, **style,
            )

        ax.set_title(regime, fontsize=10)
        ax.set_xlabel("Total bits per K vector")
        ax.set_ylabel(METRIC_LABEL[metric])
        ax.set_yscale("log")
        ax.grid(True, which="both", alpha=0.3)
        ax.legend(fontsize=7)

    # hide unused axes
    for i in range(len(regimes), nrows * ncols):
        axes[i // ncols][i % ncols].set_visible(False)

    plt.tight_layout()
    path = os.path.join(out_dir, f"rate_distortion_{metric}.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    print(f"Saved: {path}")
    plt.close()


# ── Figure 2: quality vs n_tokens ─────────────────────────────────────────────

def fig_scaling_tokens(df, out_dir, metric="dirT",
                       budget_fixed=3, n_queries_fixed=64):
    sub = df[
        (df["budget"]    == budget_fixed) &
        (df["n_queries"] == n_queries_fixed) &
        (df["scheme"].isin(KEY_SCHEMES))
    ]
    regimes = sorted(sub["regime"].unique())
    ncols = min(3, len(regimes))
    nrows = int(np.ceil(len(regimes) / ncols))

    fig, axes = plt.subplots(nrows, ncols, figsize=(5 * ncols, 4 * nrows),
                             squeeze=False)
    fig.suptitle(
        f"Quality vs Context Length  |  {METRIC_LABEL[metric]}\n"
        f"budget={budget_fixed} bits/dim  n_queries={n_queries_fixed}  d_h=128",
        fontsize=12,
    )

    for ax_idx, regime in enumerate(regimes):
        ax = axes[ax_idx // ncols][ax_idx % ncols]
        rsub = sub[sub["regime"] == regime]

        for scheme in KEY_SCHEMES:
            ssub = rsub[rsub["scheme"] == scheme].sort_values("n_tokens")
            if ssub.empty:
                continue
            style = SCHEME_STYLE.get(scheme, {})
            ax.plot(ssub["n_tokens"], ssub[metric], label=scheme, **style)

        ax.set_title(regime, fontsize=10)
        ax.set_xlabel("n_tokens (context length)")
        ax.set_xscale("log")
        ax.set_ylabel(METRIC_LABEL[metric])
        ax.set_yscale("log")
        ax.grid(True, which="both", alpha=0.3)
        ax.legend(fontsize=7)

    for i in range(len(regimes), nrows * ncols):
        axes[i // ncols][i % ncols].set_visible(False)

    plt.tight_layout()
    path = os.path.join(out_dir, f"scaling_tokens_b{budget_fixed}_{metric}.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    print(f"Saved: {path}")
    plt.close()


# ── Figure 3: encode throughput ────────────────────────────────────────────────

def fig_throughput(df, out_dir, n_queries_fixed=64):
    sub = df[
        (df["n_queries"] == n_queries_fixed) &
        (df["budget"]    == 3) &               # one budget representative
        (df["scheme"].isin(KEY_SCHEMES))
    ].copy()
    sub["ms_per_tok_K"] = sub["t_enc_K_ms"] / sub["n_tokens"] * 1000.0  # µs/tok

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    fig.suptitle(
        f"Encode Throughput  |  budget=3 bits/dim  n_queries={n_queries_fixed}",
        fontsize=12,
    )

    # Left: tokens/s vs n_tokens
    ax = axes[0]
    for scheme in KEY_SCHEMES:
        ssub = sub[sub["scheme"] == scheme].groupby("n_tokens")["tok_per_s_K"].mean().reset_index()
        if ssub.empty:
            continue
        style = SCHEME_STYLE.get(scheme, {})
        ax.plot(ssub["n_tokens"], ssub["tok_per_s_K"] / 1e6,
                label=scheme, **style)
    ax.set_xlabel("n_tokens")
    ax.set_xscale("log")
    ax.set_ylabel("K encode throughput  (M tokens/s)")
    ax.set_yscale("log")
    ax.grid(True, which="both", alpha=0.3)
    ax.legend(fontsize=8)
    ax.set_title("Throughput (K encode)")

    # Right: encode latency per token (µs) vs n_tokens
    ax = axes[1]
    for scheme in KEY_SCHEMES:
        ssub = sub[sub["scheme"] == scheme].groupby("n_tokens")["ms_per_tok_K"].mean().reset_index()
        if ssub.empty:
            continue
        style = SCHEME_STYLE.get(scheme, {})
        ax.plot(ssub["n_tokens"], ssub["ms_per_tok_K"],
                label=scheme, **style)
    ax.set_xlabel("n_tokens")
    ax.set_xscale("log")
    ax.set_ylabel("Encode latency  (µs / token)")
    ax.grid(True, which="both", alpha=0.3)
    ax.legend(fontsize=8)
    ax.set_title("Latency per token (K encode)")

    plt.tight_layout()
    path = os.path.join(out_dir, "throughput.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    print(f"Saved: {path}")
    plt.close()


# ── Figure 4: accuracy vs time (Pareto) ───────────────────────────────────────

def fig_accuracy_vs_time(df, out_dir, metric="dirT",
                         n_queries_fixed=64):
    sub = df[
        (df["n_queries"] == n_queries_fixed) &
        (df["scheme"].isin(KEY_SCHEMES))
    ].copy()
    sub["ms_per_tok_K"] = sub["t_enc_K_ms"] / sub["n_tokens"] * 1000.0  # µs/tok

    regimes = sorted(sub["regime"].unique())
    ncols = min(3, len(regimes))
    nrows = int(np.ceil(len(regimes) / ncols))

    fig, axes = plt.subplots(nrows, ncols, figsize=(5 * ncols, 4 * nrows),
                             squeeze=False)
    fig.suptitle(
        f"Accuracy vs Encode Latency  |  {METRIC_LABEL[metric]}\n"
        f"n_queries={n_queries_fixed}  (each point = one budget × n_tokens config)",
        fontsize=12,
    )

    for ax_idx, regime in enumerate(regimes):
        ax = axes[ax_idx // ncols][ax_idx % ncols]
        rsub = sub[sub["regime"] == regime]

        for scheme in KEY_SCHEMES:
            ssub = rsub[rsub["scheme"] == scheme]
            if ssub.empty:
                continue
            style = SCHEME_STYLE.get(scheme, {})
            marker_style = {k: v for k, v in style.items()
                            if k in ("color", "marker")}
            ax.scatter(
                ssub["ms_per_tok_K"], ssub[metric],
                label=scheme, s=40, alpha=0.7, **marker_style,
            )

        ax.set_title(regime, fontsize=10)
        ax.set_xlabel("K encode latency  (µs / token)")
        ax.set_ylabel(METRIC_LABEL[metric])
        ax.set_yscale("log")
        ax.grid(True, which="both", alpha=0.3)
        ax.legend(fontsize=7)

    for i in range(len(regimes), nrows * ncols):
        axes[i // ncols][i % ncols].set_visible(False)

    plt.tight_layout()
    path = os.path.join(out_dir, f"accuracy_vs_time_{metric}.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    print(f"Saved: {path}")
    plt.close()


# ── main ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv",     default="sweep_results/sweep_all.csv")
    parser.add_argument("--out_dir", default="plots")
    parser.add_argument("--metric",  default="dirT",
                        choices=["dirT", "relMSE", "kl_sm", "ptrelMSE_K"])
    parser.add_argument("--n_tokens_rd", type=int, default=4096,
                        help="n_tokens for rate-distortion plot")
    parser.add_argument("--budget_scaling", type=int, default=3,
                        help="budget for scaling-vs-tokens plot")
    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    df = load(args.csv)
    print(f"Loaded {len(df)} rows from {args.csv}")
    print(f"Regimes  : {sorted(df['regime'].unique())}")
    print(f"Schemes  : {sorted(df['scheme'].unique())}")
    print(f"n_tokens : {sorted(df['n_tokens'].unique())}")
    print(f"n_queries: {sorted(df['n_queries'].unique())}")

    fig_rate_distortion(df, args.out_dir, metric=args.metric,
                        n_tokens_fixed=args.n_tokens_rd)
    fig_scaling_tokens(df, args.out_dir, metric=args.metric,
                       budget_fixed=args.budget_scaling)
    fig_throughput(df, args.out_dir)
    fig_accuracy_vs_time(df, args.out_dir, metric=args.metric)

    print("\nAll plots saved to:", args.out_dir)


if __name__ == "__main__":
    main()
