import sys
import numpy as np
sys.path.insert(0, '.')
from spectralquant_proto import calibrate, SpectralQuantCodec, water_fill, cosine_sim, attention_output
from turbo_proto import REGIMES

rng = np.random.default_rng(42)
regime_fn = REGIMES['lowrank_aligned']   # or whichever regime name exists
K, V, Q, K_cal = regime_fn(512, 128, 512, 64)

calib = calibrate(K_cal)
d_eff = calib['d_eff']
B_TAIL = 2
budget = 2
print(f"d_eff={d_eff}")

# Uniform allocation
wf_uniform = [budget] * d_eff
# Waterfill allocation
wf_wf = water_fill(calib['sig_eff'], budget * d_eff, min_bits=B_TAIL)
print(f"uniform bits: {wf_uniform}")
print(f"waterfill bits: {wf_wf}")
print(f"same allocation: {wf_uniform == list(wf_wf)}")

codec_u = SpectralQuantCodec(calib, wf_uniform, b_tail=B_TAIL, rng=np.random.default_rng(0))
codec_u.fit_codebooks(K_cal)
codec_w = SpectralQuantCodec(calib, wf_wf,     b_tail=B_TAIL, rng=np.random.default_rng(0))
codec_w.fit_codebooks(K_cal)

K_hat_u = codec_u.encode_decode(K, is_key=True)
K_hat_w = codec_w.encode_decode(K, is_key=True)

print(f"K_hat identical: {np.allclose(K_hat_u, K_hat_w, atol=0)}")
print(f"K_hat max diff:  {np.max(np.abs(K_hat_u - K_hat_w)):.2e}")

d_h = 128
T_ref = attention_output(Q, K,     V,     d_h)
T_u   = attention_output(Q, K_hat_u, V, d_h)
T_w   = attention_output(Q, K_hat_w, V, d_h)
print(f"cosine uniform:   {cosine_sim(T_ref, T_u):.6f}")
print(f"cosine waterfill: {cosine_sim(T_ref, T_w):.6f}")
print(f"cosine diff: {abs(cosine_sim(T_ref,T_u) - cosine_sim(T_ref,T_w)):.2e}")
