# Iso-quality budget analysis
*Source: sq_full_final.csv | all S and Nq*
*Winner: TQ-QKQV at b=3*
*d_2 = sqrt(AS^2 + NF^2),  AS = 1-cosine,  NF = relMSE/(1+relMSE)  [budget-independent]*

## 1. Crossover budget table

### Crossover budget  (winner: TQ-QKQV at b=3)

| regime | d_2 winner | cosine_W | NF_W | best SQ | b_cross | d_2 SQ | bits_W | bits_SQ | surcharge |
|--------|------------|----------|------|---------|---------|--------|--------|---------|-----------|
| unit_sphere | 1.129 | 0.330 | 0.909 | SQ-waterfill-qjlKV | 2 | 0.986 | 4 | 2 | 1.50× |
| lowrank_aligned | 0.946 | 0.540 | 0.826 | SQ-uniform-qjlKV | 2 | 0.272 | 4 | 2 | 1.07× |
| lowrank | 0.988 | 0.471 | 0.835 | SQ-uniform-qjlKV | 2 | 0.394 | 4 | 2 | 1.07× |
| fattail | 0.473 | 0.737 | 0.394 | SQ-uniform-qjlKV | >b=7 | 0.515† | 4 | 12 | never |
| lowrank_steep | 0.854 | 0.496 | 0.689 | SQ-uniform-qjlKV | 2 | 0.517 | 4 | 2 | 0.98× |
| lowrank_misalign | 1.052 | 0.414 | 0.873 | SQ-uniform-qjlKV | 2 | 0.941 | 4 | 2 | 1.00× |

† SQ never reaches d_2(winner) — value shown is best achieved at max budget.
bits_W / bits_SQ = total bits per token (n_bits_K + n_bits_V).
surcharge = vram_B(SQ, b_cross) / vram_B(winner, b_winner).
d_2 = sqrt(AS^2 + NF^2),  AS = 1-cosine,  NF = relMSE/(1+relMSE).

## 2. d_2 profile per regime  (bold = matches or beats winner)

### unit_sphere  (d_2 winner=1.129  cosine=0.330  relMSE=9.9950  NF=0.909)

| scheme | b=2 | b=3 | b=4 | b=5 | b=6 | b=7 |
|---|---|---|---|---|---|---|
| SQ-uniform | 1.226 | 1.227 | 1.230 | 1.228 | 1.229 | 1.230 |
| SQ-waterfill | 1.226 | 1.227 | 1.230 | 1.228 | 1.229 | 1.230 |
| SQ-uniform-qjlK | 1.229 | 1.225 | 1.226 | 1.229 | 1.228 | 1.230 |
| SQ-uniform-qjlV | **1.000** | **0.986** | **0.997** | **1.007** | **1.010** | **1.016** |
| SQ-uniform-qjlKV | **1.000** | **0.986** | **0.997** | **1.007** | **1.010** | **1.016** |
| SQ-waterfill-qjlK | 1.226 | 1.225 | 1.226 | 1.229 | 1.228 | 1.230 |
| SQ-waterfill-qjlV | **0.986** | **0.986** | **0.997** | **1.007** | **1.010** | **1.016** |
| SQ-waterfill-qjlKV | **0.986** | **0.986** | **0.997** | **1.007** | **1.010** | **1.016** |

**bold** = d_2 ≤ d_2(winner) (1.129)

### lowrank_aligned  (d_2 winner=0.946  cosine=0.540  relMSE=4.7614  NF=0.826)

| scheme | b=2 | b=3 | b=4 | b=5 | b=6 | b=7 |
|---|---|---|---|---|---|---|
| SQ-uniform | 1.257 | 1.284 | **0.926** | **0.788** | **0.637** | **0.645** |
| SQ-waterfill | 1.257 | 1.284 | **0.926** | **0.788** | **0.637** | **0.645** |
| SQ-uniform-qjlK | **0.880** | 1.382 | 1.215 | 1.127 | **0.698** | **0.644** |
| SQ-uniform-qjlV | **0.279** | 1.074 | **0.667** | **0.445** | **0.191** | **0.167** |
| SQ-uniform-qjlKV | **0.272** | 1.073 | **0.665** | **0.445** | **0.191** | **0.167** |
| SQ-waterfill-qjlK | 1.258 | 1.382 | 1.215 | 1.127 | **0.698** | **0.644** |
| SQ-waterfill-qjlV | 1.047 | 1.074 | **0.667** | **0.445** | **0.191** | **0.167** |
| SQ-waterfill-qjlKV | 1.047 | 1.073 | **0.665** | **0.445** | **0.191** | **0.167** |

**bold** = d_2 ≤ d_2(winner) (0.946)

### lowrank  (d_2 winner=0.988  cosine=0.471  relMSE=5.0486  NF=0.835)

| scheme | b=2 | b=3 | b=4 | b=5 | b=6 | b=7 |
|---|---|---|---|---|---|---|
| SQ-uniform | 1.116 | 1.161 | 1.116 | **0.894** | **0.925** | **0.949** |
| SQ-waterfill | 1.116 | 1.161 | 1.116 | **0.894** | **0.925** | **0.949** |
| SQ-uniform-qjlK | **0.819** | 1.222 | 1.135 | 1.088 | **0.881** | **0.909** |
| SQ-uniform-qjlV | **0.558** | **0.914** | **0.715** | **0.583** | **0.382** | **0.430** |
| SQ-uniform-qjlKV | **0.394** | **0.881** | **0.700** | **0.561** | **0.350** | **0.410** |
| SQ-waterfill-qjlK | 1.107 | 1.222 | 1.135 | 1.088 | **0.881** | **0.909** |
| SQ-waterfill-qjlV | **0.845** | **0.914** | **0.715** | **0.583** | **0.382** | **0.430** |
| SQ-waterfill-qjlKV | **0.825** | **0.881** | **0.700** | **0.561** | **0.350** | **0.410** |

**bold** = d_2 ≤ d_2(winner) (0.988)

### fattail  (d_2 winner=0.473  cosine=0.737  relMSE=0.6490  NF=0.394)

| scheme | b=2 | b=3 | b=4 | b=5 | b=6 | b=7 |
|---|---|---|---|---|---|---|
| SQ-uniform | 1.213 | 1.080 | 1.065 | 1.066 | 1.056 | 1.055 |
| SQ-waterfill | 1.213 | 1.079 | 1.065 | 1.066 | 1.056 | 1.055 |
| SQ-uniform-qjlK | 0.849 | 1.144 | 0.858 | 0.845 | 0.836 | 0.844 |
| SQ-uniform-qjlV | 0.863 | 0.999 | 0.895 | 0.873 | 0.880 | 0.872 |
| SQ-uniform-qjlKV | 0.505 | 0.861 | 0.564 | 0.503 | 0.504 | 0.515 |
| SQ-waterfill-qjlK | 1.090 | 1.144 | 0.858 | 0.845 | 0.836 | 0.844 |
| SQ-waterfill-qjlV | 0.959 | 0.999 | 0.895 | 0.876 | 0.879 | 0.871 |
| SQ-waterfill-qjlKV | 0.724 | 0.861 | 0.564 | 0.503 | 0.504 | 0.515 |

**bold** = d_2 ≤ d_2(winner) (0.473)

### lowrank_steep  (d_2 winner=0.854  cosine=0.496  relMSE=2.2160  NF=0.689)

| scheme | b=2 | b=3 | b=4 | b=5 | b=6 | b=7 |
|---|---|---|---|---|---|---|
| SQ-uniform | 1.079 | 1.011 | 1.014 | 1.071 | 1.074 | 1.077 |
| SQ-waterfill | 1.079 | 1.002 | 1.014 | 1.071 | 1.074 | 1.077 |
| SQ-uniform-qjlK | 0.895 | 1.025 | 0.956 | 0.997 | 1.037 | 1.060 |
| SQ-uniform-qjlV | **0.702** | **0.722** | **0.598** | **0.652** | **0.678** | **0.707** |
| SQ-uniform-qjlKV | **0.517** | **0.601** | **0.484** | **0.565** | **0.618** | **0.670** |
| SQ-waterfill-qjlK | 1.025 | 1.025 | 0.949 | 0.997 | 1.038 | 1.060 |
| SQ-waterfill-qjlV | **0.722** | **0.722** | **0.598** | **0.652** | **0.678** | **0.707** |
| SQ-waterfill-qjlKV | **0.601** | **0.601** | **0.483** | **0.565** | **0.618** | **0.670** |

**bold** = d_2 ≤ d_2(winner) (0.854)

### lowrank_misalign  (d_2 winner=1.052  cosine=0.414  relMSE=6.8926  NF=0.873)

| scheme | b=2 | b=3 | b=4 | b=5 | b=6 | b=7 |
|---|---|---|---|---|---|---|
| SQ-uniform | 1.367 | 1.387 | 1.248 | 1.126 | 1.074 | **1.047** |
| SQ-waterfill | 1.367 | 1.387 | 1.248 | 1.126 | 1.074 | **1.047** |
| SQ-uniform-qjlK | 1.323 | 1.415 | 1.384 | 1.239 | 1.131 | 1.081 |
| SQ-uniform-qjlV | **1.037** | 1.292 | 1.155 | **0.757** | **0.564** | **0.442** |
| SQ-uniform-qjlKV | **0.941** | 1.283 | 1.155 | **0.726** | **0.518** | **0.409** |
| SQ-waterfill-qjlK | 1.364 | 1.415 | 1.384 | 1.239 | 1.131 | 1.081 |
| SQ-waterfill-qjlV | 1.245 | 1.292 | 1.155 | **0.757** | **0.564** | **0.442** |
| SQ-waterfill-qjlKV | 1.238 | 1.283 | 1.155 | **0.726** | **0.518** | **0.409** |

**bold** = d_2 ≤ d_2(winner) (1.052)
