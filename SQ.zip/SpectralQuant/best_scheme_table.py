"""
best_scheme_table.py -- regime x budget winner table from sweep CSV
Uses snr_metrics_6d.py for the primary ranking criterion (median d_6).

Primary metric : median d_6  (6D Euclidean distance from Shannon-optimal origin)
                 lower = better, combines scale AND direction errors for K, V, T
Secondary check: mean 1-cosine  (end-to-end attention output direction error)
                 lower = better, 0 = perfect alignment
Disagreement   : flagged with ! when d_6 winner != 1-cosine winner

Usage:
    python best_scheme_table.py sq_full.csv
    python best_scheme_table.py sq_full.csv --eps 0.05 --out results.md
    python best_scheme_table.py sq_full.csv --s 256 --nq 64 --out results_s256.md
"""

import sys
import argparse
import pandas as pd
import numpy as np

from snr_metrics_6d import add_snr_err, DIM_NAMES

EQUIV_EPS_D6  = 0.05    # schemes within this d_6  of winner are "equivalent"
EQUIV_EPS_COS = 0.01    # schemes within this cosine of winner are "equivalent"

SCHEME_ORDER = [
    "Plain-KV",
    "TQ-KV", "TQ-QKV", "TQ-KQV", "TQ-QKQV",
    "SQ-uniform", "SQ-waterfill",
    "SQ-uniform-qjlK",  "SQ-uniform-qjlV",  "SQ-uniform-qjlKV",
    "SQ-waterfill-qjlK","SQ-waterfill-qjlV","SQ-waterfill-qjlKV",
]

REGIME_ORDER = [
    "unit_sphere", "lowrank_aligned", "lowrank",
    "fattail", "lowrank_steep", "lowrank_misalign",
]


# ---------------------------------------------------------------------------
# Load and enrich
# ---------------------------------------------------------------------------

def load(path, s_filter, nq_filter):
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    if s_filter  is not None: df = df[df["S"]  == s_filter]
    if nq_filter is not None: df = df[df["Nq"] == nq_filter]
    if df.empty:
        sys.exit(f"No rows after filtering S={s_filter} Nq={nq_filter}.")
    # Compute full 6D error geometry
    df = add_snr_err(df)
    return df


def summarise(df):
    """
    Per (regime, budget, scheme):
        d6_med  -- median d_6  (primary ranking, budget-relative)
        d2_med  -- median d_2  (secondary, budget-independent)
                   d_2 = sqrt(AS^2 + NF^2)
                   AS  = 1 - cosine   (direction error)
                   NF  = relMSE/(1+relMSE)   (scale error)
        plus median of each 6D component for the detail table
    """
    agg = {}
    agg["d6_med"]   = ("d_6",    "median")
    agg["cos_med"]  = ("cosine", "median")
    agg["mse_med"]  = ("relMSE", "median")
    for dim in DIM_NAMES:
        agg[f"{dim}_med"] = (dim, "median")

    s = (df.groupby(["regime", "budget", "scheme"])
           .agg(**agg)
           .reset_index())
    s["AS_med"] = 1.0 - s["cos_med"]
    s["NF_med"] = s["mse_med"] / (1.0 + s["mse_med"])
    s["d2_med"] = np.sqrt(s["AS_med"]**2 + s["NF_med"]**2)
    return s


# ---------------------------------------------------------------------------
# Helper: ordered scheme list for a regime subset
# ---------------------------------------------------------------------------

def ordered_schemes(present):
    return ([s for s in SCHEME_ORDER if s in present] +
            [s for s in present      if s not in SCHEME_ORDER])


# ---------------------------------------------------------------------------
# Output 1: compact regime x budget table
# ---------------------------------------------------------------------------

def compact_table(s, eps_d6, eps_cos):
    regimes = [r for r in REGIME_ORDER if r in s["regime"].values]
    budgets = sorted(s["budget"].unique())

    header = "| regime \\ budget |" + "".join(f" b={b} |" for b in budgets)
    sep    = "|" + "---|" * (1 + len(budgets))
    lines  = [header, sep]

    for reg in regimes:
        row = f"| **{reg}** |"
        for b in budgets:
            sub = (s[(s["regime"] == reg) & (s["budget"] == b)]
                   .sort_values("d6_med")
                   .reset_index(drop=True))
            if sub.empty:
                row += " -- |"
                continue

            best_d6  = sub.iloc[0]["d6_med"]
            best_sch = sub.iloc[0]["scheme"]
            best_d2  = sub.iloc[0]["d2_med"]

            # equivalent by d_6
            n_equiv = (sub["d6_med"] <= best_d6 + eps_d6).sum()
            tag = "*" if n_equiv > 1 else ""

            # d_2 winner disagrees with d_6 winner?
            d2_winner = sub.sort_values("d2_med", ascending=True).iloc[0]["scheme"]
            conflict = "!" if d2_winner != best_sch else ""

            row += f" {best_sch}{tag}{conflict} ({best_d6:.3f}/{best_d2:.3f}) |"
        lines.append(row)

    lines += [
        "",
        "Format: scheme* ! (d_6 / d_2)",
        "\\* equivalent scheme within eps_d6 of winner",
        "! d_2 winner differs from d_6 winner",
        "d_2 = sqrt(AS^2 + NF^2),  AS = 1-cosine,  NF = relMSE/(1+relMSE)  [budget-independent]",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Output 2: detailed per-regime ranking (all schemes, both metrics)
# ---------------------------------------------------------------------------

def detailed_tables(s, eps_d6):
    regimes = [r for r in REGIME_ORDER if r in s["regime"].values]
    budgets = sorted(s["budget"].unique())
    blocks  = []

    for reg in regimes:
        rsub = s[s["regime"] == reg]

        best_d6_per_b = {b: rsub[rsub["budget"]==b]["d6_med"].min()
                         for b in budgets
                         if not rsub[rsub["budget"]==b].empty}
        best_d2_per_b = {b: rsub[rsub["budget"]==b]["d2_med"].min()
                         for b in budgets
                         if not rsub[rsub["budget"]==b].empty}

        header = "| scheme |" + "".join(f" b={b} d6/d2 |" for b in budgets)
        sep    = "|" + "---|" * (1 + len(budgets))
        lines  = [f"### {reg}", "", header, sep]

        for sch in ordered_schemes(rsub["scheme"].unique()):
            row = f"| {sch} |"
            for b in budgets:
                cell = rsub[(rsub["scheme"]==sch) & (rsub["budget"]==b)]
                if cell.empty:
                    row += " -- |"
                    continue
                d6 = cell.iloc[0]["d6_med"]
                d2 = cell.iloc[0]["d2_med"]
                best_d6 = best_d6_per_b.get(b, d6)
                best_d2 = best_d2_per_b.get(b, d2)
                d6_win = d6 <= best_d6 + eps_d6
                d2_win = d2 <= best_d2 + EQUIV_EPS_COS
                if d6_win and d2_win:
                    row += f" **{d6:.3f}/{d2:.3f}** |"
                elif d6_win:
                    row += f" **{d6:.3f}**/{d2:.3f} |"
                elif d2_win:
                    row += f" {d6:.3f}/**{d2:.3f}** |"
                else:
                    row += f" {d6:.3f}/{d2:.3f} |"
            lines.append(row)

        lines += ["", "bold d_6 = d_6 winner/equiv | bold d_2 = budget-independent winner/equiv", ""]
        blocks.append("\n".join(lines))

    return "\n".join(blocks)


# ---------------------------------------------------------------------------
# Output 3: 6D component breakdown for winners (where does the error come from?)
# ---------------------------------------------------------------------------

def component_breakdown(s):
    regimes = [r for r in REGIME_ORDER if r in s["regime"].values]
    budgets = [2, 3]   # low-budget is what matters most

    blocks = []
    for reg in regimes:
        rsub = s[s["regime"] == reg]
        lines = [f"### {reg} — 6D component breakdown (b=2,3)", "",
                 "| scheme | b | snr_K | dir_K | snr_V | dir_V | snr_T | dir_T | d_6 |",
                 "|--------|---|-------|-------|-------|-------|-------|-------|-----|"]

        for b in budgets:
            bsub = rsub[rsub["budget"] == b].sort_values("d6_med")
            if bsub.empty:
                continue
            for _, row in bsub.iterrows():
                sch = row["scheme"]
                lines.append(
                    f"| {sch} | {b} "
                    f"| {row['snr_err_K_med']:.3f} | {row['dir_err_K_med']:.3f} "
                    f"| {row['snr_err_V_med']:.3f} | {row['dir_err_V_med']:.3f} "
                    f"| {row['snr_err_med']:.3f}   | {row['dir_err_med']:.3f} "
                    f"| {row['d6_med']:.3f} |"
                )
        lines.append("")  # one blank line after the whole table

        blocks.append("\n".join(lines))

    return "\n".join(blocks)


# ---------------------------------------------------------------------------
# Output 4: recommendation per regime (averaged across budgets)
# ---------------------------------------------------------------------------

def recommendations(s):
    regimes  = [r for r in REGIME_ORDER if r in s["regime"].values]
    sq_names = [x for x in SCHEME_ORDER if x.startswith("SQ")]
    tq_names = [x for x in SCHEME_ORDER if not x.startswith("SQ")]

    lines = [
        "### Recommendation per regime  (budget-averaged d_6; values shown as d_6/d_2)",
        "",
        "| regime | best SQ (d_6/d_2) | best TQ (d_6/d_2) | overall (d_6/d_2) | note |",
        "|--------|-------------------|-------------------|-------------------|------|",
    ]

    for reg in regimes:
        avg = (s[s["regime"] == reg]
               .groupby("scheme")[["d6_med","d2_med"]]
               .mean())
        if avg.empty:
            lines.append(f"| {reg} | -- | -- | -- | |")
            continue

        sq = avg[avg.index.isin(sq_names)]
        tq = avg[avg.index.isin(tq_names)]

        bsq  = sq["d6_med"].idxmin()  if not sq.empty else "--"
        btq  = tq["d6_med"].idxmin()  if not tq.empty else "--"
        bov  = avg["d6_med"].idxmin() if not avg.empty else "--"

        d_sq  = f"{sq.loc[bsq,'d6_med']:.3f}/{sq.loc[bsq,'d2_med']:.3f}"   if bsq != "--" else "--"
        d_tq  = f"{tq.loc[btq,'d6_med']:.3f}/{tq.loc[btq,'d2_med']:.3f}"   if btq != "--" else "--"
        d_ov  = f"{avg.loc[bov,'d6_med']:.3f}/{avg.loc[bov,'d2_med']:.3f}"  if bov != "--" else "--"

        # flag if best SQ and best TQ are close (by d_6)
        note = ""
        if bsq != "--" and btq != "--":
            gap = abs(sq.loc[bsq, "d6_med"] - tq.loc[btq, "d6_med"])
            if gap < 0.05:
                note = "near tie"
            elif sq.loc[bsq,"d6_med"] < tq.loc[btq,"d6_med"]:
                note = "SQ wins"
            else:
                note = "TQ wins"

        lines.append(
            f"| {reg} | {bsq} ({d_sq}) | {btq} ({d_tq}) | {bov} ({d_ov}) | {note} |"
        )

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Output 5: TQ-KQV vs TQ-QKQV parity by budget
# ---------------------------------------------------------------------------

def parity_table(s):
    regimes = [r for r in REGIME_ORDER if r in s["regime"].values]
    budgets = sorted(s["budget"].unique())

    lines = [
        "### TQ-KQV vs TQ-QKQV by budget  (delta d_6, negative = KQV better)",
        "",
        "| regime |" + "".join(f" b={b} |" for b in budgets),
        "|" + "---|" * (1 + len(budgets)),
    ]

    for reg in regimes:
        row  = f"| {reg} |"
        rsub = s[s["regime"] == reg]
        for b in budgets:
            kqv  = rsub[(rsub["scheme"]=="TQ-KQV")  & (rsub["budget"]==b)]
            qkqv = rsub[(rsub["scheme"]=="TQ-QKQV") & (rsub["budget"]==b)]
            if kqv.empty or qkqv.empty:
                row += " -- |"; continue
            dk = kqv.iloc[0]["d6_med"]
            dq = qkqv.iloc[0]["d6_med"]
            delta = dk - dq   # negative = KQV has lower d_6 = KQV better
            if abs(delta) < 0.005:
                row += " tie |"
            elif delta < 0:
                row += f" KQV {abs(delta):.3f} |"
            else:
                row += f" QKQV {abs(delta):.3f} |"
        lines.append(row)

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        description="Best scheme table using 6D error geometry (snr_metrics_6d)")
    ap.add_argument("csv",           help="Sweep CSV (e.g. sq_full.csv)")
    ap.add_argument("--eps_d6",  type=float, default=EQUIV_EPS_D6,
                    help=f"Equivalence tolerance in d_6 (default {EQUIV_EPS_D6})")
    ap.add_argument("--eps_cos", type=float, default=EQUIV_EPS_COS,
                    help=f"Equivalence tolerance in cosine (default {EQUIV_EPS_COS})")
    ap.add_argument("--s",   type=int, default=None,
                    help="Filter to single S (default: all)")
    ap.add_argument("--nq",  type=int, default=None,
                    help="Filter to single Nq (default: all)")
    ap.add_argument("--out", default=None,
                    help="Write markdown to file (default: stdout)")
    args = ap.parse_args()

    df = load(args.csv, args.s, args.nq)
    s  = summarise(df)

    scope = ""
    if args.s  is not None: scope += f" S={args.s}"
    if args.nq is not None: scope += f" Nq={args.nq}"
    if not scope:            scope  = " all S and Nq"

    sections = [
        "# Scheme ranking by regime and budget",
        f"*Source: {args.csv} |{scope}*",
        "*Primary metric: median d_6 (6D, Shannon-normalised, budget-relative)*",
        "*Secondary metric: median d_2 = sqrt(AS^2+NF^2), AS=1-cosine, NF=relMSE/(1+relMSE) (budget-independent)*",
        "*! flags cells where d_2 winner differs from d_6 winner*",
        "",
        "## 1. Compact winner table",
        "",
        compact_table(s, args.eps_d6, args.eps_cos),
        "",
        "## 2. Detailed ranking per regime  (d_6 / cosine)",
        "",
        detailed_tables(s, args.eps_d6),
        "## 3. 6D component breakdown at b=2,3",
        "",
        component_breakdown(s),
        "## 4. Recommendation per regime",
        "",
        recommendations(s),
        "",
        "## 5. TQ-KQV vs TQ-QKQV parity",
        "",
        parity_table(s),
    ]

    text = "\n".join(sections)

    if args.out:
        with open(args.out, "w") as f:
            f.write(text)
        print(f"Written to {args.out}")
    else:
        print(text)


if __name__ == "__main__":
    main()
