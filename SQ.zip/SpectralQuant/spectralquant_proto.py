"""
spectralquant_proto.py — CPU prototype for SpectralQuant KV-cache quantization
===============================================================================

Pipeline (per layer/head):
  1. Calibrate: Sigma_K = (1/N) K_cal^T K_cal  →  eigh  →  U, sigma
  2. Participation ratio: d_eff = (sum sigma_i)^2 / sum(sigma_i^2)
  3. Rotate:  K_rot = K @ U_eff,  V_rot = V @ U_eff   (same U, algebraically exact)
  4. Water-filling: greedy integer allocation  b_i  given budget B = b * d_eff
  5. Per-dim Lloyd-Max: one codebook per semantic dim, fit to empirical marginal
  6. Tail: uniform-bit codebook on dims d_eff..d_h
  7. Selective QJL: 1-bit JL sketch of scalar residual on semantic dims only
  8. Encode / decode roundtrip
  9. Reconstruct: K_hat = K_rot_hat @ U_eff.T  (back to d_h space)
 10. 6D error vector compatible with snr_metrics_6d.py

Usage:
    python spectralquant_proto.py --mode random --budget 4 --n_tokens 4096 --n_cal 512
    python spectralquant_proto.py --mode lowrank --rank 4 --budget 4
    python spectralquant_proto.py --mode all
"""

import sys
import os
import argparse
import numpy as np
import pandas as pd
from scipy.stats import ks_2samp

# ── path: import snr_metrics_6d from sibling pquant_6d dir ────────────────────
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(_HERE, "pquant_6d"))
from snr_metrics_6d import add_snr_err, SCALAR_LOSS

# ── reproducibility ────────────────────────────────────────────────────────────
RNG_SEED = 42

# ═══════════════════════════════════════════════════════════════════════════════
# 1.  CALIBRATION
# ═══════════════════════════════════════════════════════════════════════════════

def calibrate(K_cal: np.ndarray) -> dict:
    """
    Compute eigenbasis from calibration keys.

    Parameters
    ----------
    K_cal : (N_cal, d_h)  float32/64 calibration key vectors

    Returns
    -------
    dict with keys:
        U       : (d_h, d_h)  eigenvectors, descending order
        sig     : (d_h,)      eigenvalues sigma_i, descending
        d_eff   : int         participation ratio (rounded)
        U_eff   : (d_h, d_eff)  top eigenvectors
        sig_eff : (d_eff,)    top eigenvalues sigma_1..sigma_{d_eff}
    """
    N, d_h = K_cal.shape
    Sigma = (K_cal.T @ K_cal) / N              # (d_h, d_h)
    sig, U = np.linalg.eigh(Sigma)            # ascending order
    idx = np.argsort(sig)[::-1]               # sort descending
    sig, U = sig[idx], U[:, idx]
    sig = np.maximum(sig, 0.0)               # numerical clamp

    d_eff = participation_ratio(sig)
    U_eff  = U[:, :d_eff]
    sig_eff = sig[:d_eff]

    return dict(U=U, sig=sig, d_eff=d_eff, U_eff=U_eff, sig_eff=sig_eff)


def participation_ratio(sig: np.ndarray) -> int:
    """d_eff = round((sum sigma_i)^2 / sum(sigma_i^2)), clamped to [1, len(sig)]."""
    sig = sig[sig > 0]
    if len(sig) == 0:
        return 1
    d_eff = (sig.sum() ** 2) / (sig ** 2).sum()
    return int(np.clip(round(d_eff), 1, len(sig)))


# ═══════════════════════════════════════════════════════════════════════════════
# 2.  WATER-FILLING  (Algorithm 1 — greedy integer)
# ═══════════════════════════════════════════════════════════════════════════════

def water_fill(sig: np.ndarray, budget_bits: int, min_bits: int = 2) -> np.ndarray:
    """
    Greedy integer water-filling with per-dimension floor.

    Start with b_i = min_bits for all i, then distribute the remaining
    (budget_bits - d * min_bits) bits greedily:
        i* = argmax_i  sigma_i * 4^{-b_i}
        b_{i*} += 1

    The 4^{-b} factor comes from MSE ∝ step^2 ∝ (2^{-b})^2 = 4^{-b}.

    min_bits=2 matches b_tail so no semantic dim receives fewer bits than
    the tail floor, preventing the inversion where a high-eigenvalue semantic
    dim gets 0 bits while a low-eigenvalue tail dim gets 2 bits.

    Parameters
    ----------
    sig          : (d_eff,)  eigenvalues sigma_i, descending
    budget_bits  : int       total bits to distribute  (= b_target * d_eff)
    min_bits     : int       per-dimension floor (default 2, matches b_tail)

    Returns
    -------
    b : (d_eff,) int  bits per dimension
    """
    d = len(sig)
    b = np.full(d, min_bits, dtype=int)
    dist = sig.copy().astype(float)
    # Reflect min_bits already consumed in the distortion proxy
    for i in range(d):
        dist[i] = sig[i] * (4.0 ** (-min_bits))
    remaining = budget_bits - d * min_bits
    for _ in range(max(0, remaining)):
        i_star = int(np.argmax(dist))
        b[i_star] += 1
        dist[i_star] = sig[i_star] * (4.0 ** (-b[i_star]))
    return b


def water_fill_uniform(d_eff: int, b_per_dim: int) -> np.ndarray:
    """Uniform allocation: every semantic dim gets b_per_dim bits."""
    return np.full(d_eff, b_per_dim, dtype=int)


# ═══════════════════════════════════════════════════════════════════════════════
# 3.  LLOYD-MAX SCALAR QUANTIZER  (distribution-agnostic, empirical)
# ═══════════════════════════════════════════════════════════════════════════════

def lloyd_max_fit(samples: np.ndarray, n_levels: int,
                  max_iter: int = 200, tol: float = 1e-8) -> tuple:
    """
    Fit a Lloyd-Max scalar quantizer to empirical samples.

    Parameters
    ----------
    samples  : (N,)   scalar samples from the marginal distribution
    n_levels : int    number of quantization levels (2^b)

    Returns
    -------
    boundaries : (n_levels + 1,)  decision thresholds (includes ±inf endpoints)
    centroids  : (n_levels,)      reconstruction values
    """
    if n_levels == 1:
        return np.array([-np.inf, np.inf]), np.array([float(np.mean(samples))])

    # Initialise centroids at uniform quantiles of the empirical distribution
    probs = np.linspace(0, 100, n_levels + 2)[1:-1]
    centroids = np.percentile(samples, probs)
    centroids = np.unique(centroids)
    # If percentiles collapsed (e.g. constant input), spread them
    if len(centroids) < n_levels:
        span = max(np.std(samples) * 4, 1e-6)
        centroids = np.linspace(np.mean(samples) - span/2,
                                np.mean(samples) + span/2, n_levels)

    for _ in range(max_iter):
        # Boundaries = midpoints between consecutive centroids
        bounds_inner = 0.5 * (centroids[:-1] + centroids[1:])
        boundaries = np.concatenate([[-np.inf], bounds_inner, [np.inf]])

        # New centroids = conditional mean of samples in each cell
        new_centroids = np.empty(n_levels)
        for k in range(n_levels):
            mask = (samples >= boundaries[k]) & (samples < boundaries[k + 1])
            new_centroids[k] = samples[mask].mean() if mask.any() else centroids[k]

        if np.max(np.abs(new_centroids - centroids)) < tol:
            centroids = new_centroids
            break
        centroids = new_centroids

    boundaries = np.concatenate([[-np.inf],
                                  0.5 * (centroids[:-1] + centroids[1:]),
                                  [np.inf]])
    return boundaries, centroids


def lloyd_max_encode(x: np.ndarray, boundaries: np.ndarray) -> np.ndarray:
    """Scalar quantize x using decision boundaries → integer indices."""
    return np.searchsorted(boundaries[1:-1], x).astype(np.int32)


def lloyd_max_decode(indices: np.ndarray, centroids: np.ndarray) -> np.ndarray:
    """Reconstruct from integer indices."""
    return centroids[np.clip(indices, 0, len(centroids) - 1)]


# ═══════════════════════════════════════════════════════════════════════════════
# 4.  SELECTIVE QJL  (semantic dims only, 1-bit per dim)
# ═══════════════════════════════════════════════════════════════════════════════

def qjl_encode(residuals: np.ndarray, proj: np.ndarray) -> np.ndarray:
    """
    1-bit JL sketch of scalar residuals.

    residuals : (L, d_eff)   z_i - z_hat_i  per token per semantic dim
    proj      : (d_eff,)     random ±1 projection vector (one scalar per dim)

    Returns
    -------
    bits : (L, d_eff)  int8  sign(residual * proj)  in {0, 1}
    """
    signs = np.sign(residuals * proj[np.newaxis, :])
    return ((signs + 1) // 2).astype(np.int8)   # 0 or 1


def qjl_decode(bits: np.ndarray, proj: np.ndarray,
               residual_scale: np.ndarray) -> np.ndarray:
    """
    Reconstruct residual estimate from JL bits.

    bits           : (L, d_eff)  int8  from qjl_encode
    proj           : (d_eff,)    same projection vector used in encode
    residual_scale : (d_eff,)    expected |residual| per dim (e.g. sqrt(sigma_i * 4^{-b}))

    Returns
    -------
    r_hat : (L, d_eff)  float   estimated residuals
    """
    signs = (bits.astype(float) * 2 - 1)     # {0,1} → {-1,+1}
    # direction from proj, magnitude from residual_scale
    return signs * proj[np.newaxis, :] * residual_scale[np.newaxis, :]


# ═══════════════════════════════════════════════════════════════════════════════
# 5.  FULL ENCODE / DECODE ROUNDTRIP
# ═══════════════════════════════════════════════════════════════════════════════

class SpectralQuantCodec:
    """
    Full SpectralQuant codec for one (layer, head).

    Parameters
    ----------
    calib     : dict from calibrate()
    b_sem     : (d_eff,) int  bits per semantic dim (from water_fill or uniform)
    b_tail    : int           bits per tail dim (uniform, default 2)
    use_qjl_K : bool          apply selective QJL residual correction on K
    use_qjl_V : bool          apply selective QJL residual correction on V
    rng       : np.random.Generator
    """

    def __init__(self, calib: dict, b_sem: np.ndarray,
                 b_tail: int = 2,
                 use_qjl_K: bool = False, use_qjl_V: bool = False,
                 rng: np.random.Generator = None):
        self.U_eff    = calib["U_eff"]      # (d_h, d_eff)
        self.U_tail   = calib["U"][:, calib["d_eff"]:]   # (d_h, d_h - d_eff)
        self.sig_eff  = calib["sig_eff"]    # (d_eff,)
        self.d_h      = calib["U"].shape[0]
        self.d_eff    = calib["d_eff"]
        self.b_sem    = b_sem               # (d_eff,)
        self.b_tail   = b_tail
        self.use_qjl_K = use_qjl_K
        self.use_qjl_V = use_qjl_V

        if rng is None:
            rng = np.random.default_rng(RNG_SEED)
        self.rng = rng

        # JL projection vectors: one scalar per semantic dim
        self.qjl_proj = rng.choice([-1.0, 1.0], size=self.d_eff)

        # Codebooks: fit during fit_codebooks()
        self.sem_bounds    = [None] * self.d_eff   # list of boundary arrays
        self.sem_centroids = [None] * self.d_eff   # list of centroid arrays
        self.tail_bounds    = None
        self.tail_centroids = None

    def fit_codebooks(self, K_cal: np.ndarray, V_cal: np.ndarray = None):
        """
        Fit Lloyd-Max codebooks from calibration data.

        Uses K_cal for semantic dims (rotated marginals).
        Tail codebook is shared and fit to all tail dims jointly
        (uniform-bit assumption: tail has no per-dim structure worth fitting).

        If V_cal is provided, V tail codebook is also fit (currently same as K tail).
        """
        K_sem = K_cal @ self.U_eff     # (N_cal, d_eff)
        K_tail = K_cal @ self.U_tail   # (N_cal, d_h - d_eff)

        for i in range(self.d_eff):
            n_levels = max(1, 2 ** int(self.b_sem[i]))
            self.sem_bounds[i], self.sem_centroids[i] = lloyd_max_fit(
                K_sem[:, i], n_levels
            )

        if self.b_tail > 0 and K_tail.shape[1] > 0:
            n_levels_tail = 2 ** self.b_tail
            # Fit to flattened tail (shared codebook across all tail dims)
            self.tail_bounds, self.tail_centroids = lloyd_max_fit(
                K_tail.ravel(), n_levels_tail
            )
        else:
            self.tail_bounds = np.array([-np.inf, np.inf])
            self.tail_centroids = np.array([0.0])

    def encode_decode(self, X: np.ndarray, is_key: bool = True) -> tuple:
        """
        Full roundtrip: rotate → quantize → dequantize → rotate back.

        Parameters
        ----------
        X      : (L, d_h)  key or value vectors
        is_key : bool       True → use use_qjl_K; False → use use_qjl_V

        Returns
        -------
        X_hat      : (L, d_h)  reconstructed vectors
        meta       : dict with per-dim distortions and QJL bits
        """
        use_qjl = self.use_qjl_K if is_key else self.use_qjl_V

        # ── rotate ────────────────────────────────────────────────────────────
        X_sem  = X @ self.U_eff    # (L, d_eff)
        X_tail = X @ self.U_tail   # (L, d_h - d_eff)

        # ── semantic: per-dim Lloyd-Max ────────────────────────────────────────
        X_sem_hat = np.empty_like(X_sem)
        qjl_bits  = None

        for i in range(self.d_eff):
            if self.b_sem[i] == 0:
                # sigma_i ≈ 0: dimension is near-constant; mean is the optimal 0-bit prediction
                X_sem_hat[:, i] = float(np.mean(X_sem[:, i]))
                continue
            idx = lloyd_max_encode(X_sem[:, i], self.sem_bounds[i])
            X_sem_hat[:, i] = lloyd_max_decode(idx, self.sem_centroids[i])

        # ── selective QJL on semantic dims ─────────────────────────────────────
        if use_qjl:
            residuals = X_sem - X_sem_hat           # (L, d_eff)
            qjl_bits  = qjl_encode(residuals, self.qjl_proj)
            # Expected residual magnitude: sqrt(sigma_i * 4^{-b_i})
            res_scale = np.sqrt(self.sig_eff *
                                np.array([4.0 ** (-b) for b in self.b_sem]))
            r_hat = qjl_decode(qjl_bits, self.qjl_proj, res_scale)
            X_sem_hat = X_sem_hat + r_hat

        # ── tail: shared uniform-bit codebook ─────────────────────────────────
        if self.b_tail > 0 and X_tail.shape[1] > 0:
            idx_tail = lloyd_max_encode(X_tail.ravel(), self.tail_bounds)
            X_tail_hat = lloyd_max_decode(idx_tail, self.tail_centroids).reshape(X_tail.shape)
        else:
            X_tail_hat = np.zeros_like(X_tail)

        # ── rotate back ────────────────────────────────────────────────────────
        X_hat = X_sem_hat @ self.U_eff.T + X_tail_hat @ self.U_tail.T

        meta = dict(
            X_sem=X_sem, X_sem_hat=X_sem_hat,
            X_tail=X_tail, X_tail_hat=X_tail_hat,
            qjl_bits=qjl_bits,
        )
        return X_hat, meta


# ═══════════════════════════════════════════════════════════════════════════════
# 6.  METRICS  (compatible with snr_metrics_6d.py CSV schema)
# ═══════════════════════════════════════════════════════════════════════════════

def cosine_sim(A: np.ndarray, B: np.ndarray) -> float:
    """Mean cosine similarity between rows of A and B."""
    nA = np.linalg.norm(A, axis=1, keepdims=True).clip(1e-12)
    nB = np.linalg.norm(B, axis=1, keepdims=True).clip(1e-12)
    return float(np.mean(np.sum((A / nA) * (B / nB), axis=1)))


def rel_mse(orig: np.ndarray, recon: np.ndarray) -> float:
    """Relative MSE = E[||orig - recon||^2] / E[||orig||^2]."""
    err  = np.mean(np.sum((orig - recon) ** 2, axis=1))
    norm = np.mean(np.sum(orig ** 2, axis=1))
    return float(err / norm) if norm > 0 else 0.0


def softmax_weights(Q: np.ndarray, K: np.ndarray, d_h: int) -> np.ndarray:
    """Attention weights: softmax(Q K^T / sqrt(d_h)). Shape: (L_q, L_k)."""
    scores = Q @ K.T / np.sqrt(d_h)
    scores -= scores.max(axis=1, keepdims=True)
    alpha  = np.exp(scores)
    alpha /= alpha.sum(axis=1, keepdims=True)
    return alpha


def attention_output(Q: np.ndarray, K: np.ndarray, V: np.ndarray,
                     d_h: int) -> np.ndarray:
    """Scaled dot-product attention: softmax(Q K^T / sqrt(d_h)) V."""
    return softmax_weights(Q, K, d_h) @ V


def kl_softmax(Q: np.ndarray, K_ref: np.ndarray, K_hat: np.ndarray,
               d_h: int, eps: float = 1e-10) -> float:
    """
    KL(alpha_ref || alpha_hat) averaged over queries.

    Measures how much K quantization distorts the attention distribution.
    V does not enter — this isolates the K-path effect only.

    KL = 0 when K_hat == K_ref (perfect quantization).
    KL grows as the attention pattern shifts due to K error.
    """
    alpha_ref = softmax_weights(Q, K_ref, d_h)   # (L_q, L_k)
    alpha_hat = softmax_weights(Q, K_hat, d_h)   # (L_q, L_k)
    kl = np.sum(alpha_ref * np.log((alpha_ref + eps) / (alpha_hat + eps)), axis=1)
    return float(np.mean(kl))


def compute_row(scheme: str, budget: int,
                b_sem: np.ndarray, b_tail: int,
                use_qjl_K: bool, use_qjl_V: bool,
                Q: np.ndarray, K: np.ndarray, V: np.ndarray,
                K_hat: np.ndarray, V_hat: np.ndarray,
                d_h: int) -> dict:
    """Build one CSV row in the snr_metrics_6d schema."""
    n_bits_K = float(np.mean(b_sem))   # effective bits/dim (semantic avg)
    n_bits_V = float(np.mean(b_sem))   # V uses same allocation
    has_qjl_K = 1 if use_qjl_K else 0
    has_qjl_V = 1 if use_qjl_V else 0

    T_ref = attention_output(Q, K,     V,     d_h)
    T_hat = attention_output(Q, K_hat, V_hat, d_h)

    return dict(
        scheme     = scheme,
        budget     = budget,
        n_bits_K   = n_bits_K,
        n_bits_V   = n_bits_V,
        has_qjl_K  = has_qjl_K,
        has_qjl_V  = has_qjl_V,
        relMSE     = rel_mse(T_ref, T_hat),
        cosine     = cosine_sim(T_ref, T_hat),
        ptrelMSE_K = rel_mse(K, K_hat),
        ptrelMSE_V = rel_mse(V, V_hat),
        ptcosine_K = cosine_sim(K, K_hat),
        ptcosine_V = cosine_sim(V, V_hat),
        kl_sm      = kl_softmax(Q, K, K_hat, d_h),
    )


# ═══════════════════════════════════════════════════════════════════════════════
# 7.  DIAGNOSTIC: Beta fit in reduced subspace
# ═══════════════════════════════════════════════════════════════════════════════

def beta_diagnostic(K: np.ndarray, calib: dict) -> dict:
    """
    Project → whiten → d_eff-WHT → check Beta((d_eff-1)/2, (d_eff-1)/2).

    Returns dict with:
        w          : (N, d_eff) WHT-transformed whitened coordinates
        ks_stat    : KS statistic vs reference Beta samples
        ks_pval    : KS p-value
        kl_div     : KL divergence estimate (histogram-based)
    """
    from scipy.stats import beta as beta_dist
    d_eff = calib["d_eff"]

    # Project and whiten
    z_eff = K @ calib["U_eff"]                            # (N, d_eff)
    sig_eff = calib["sig_eff"].clip(1e-12)
    z_white = z_eff / np.sqrt(sig_eff)[np.newaxis, :]    # (N, d_eff)

    # d_eff × d_eff Walsh-Hadamard (normalised)
    H = _hadamard(d_eff)
    w = (z_white @ H.T) / np.sqrt(d_eff)                 # (N, d_eff)

    # Reference: Beta((d_eff-1)/2, (d_eff-1)/2) on [-1, 1]
    alpha_beta = (d_eff - 1) / 2.0
    # Convert: if X ~ Beta(a,a) on [0,1], then 2X-1 ~ on [-1,1]
    rng = np.random.default_rng(0)
    ref_01 = rng.beta(alpha_beta, alpha_beta, size=w.size)
    ref = 2 * ref_01 - 1

    flat_w = w.ravel()
    ks_stat, ks_pval = ks_2samp(flat_w, ref)

    # KL divergence via histogram
    bins = np.linspace(-1, 1, 51)
    p, _ = np.histogram(flat_w, bins=bins, density=True)
    q, _ = np.histogram(ref,    bins=bins, density=True)
    p = p + 1e-10; q = q + 1e-10
    p /= p.sum(); q /= q.sum()
    kl_div = float(np.sum(p * np.log(p / q)))

    return dict(w=w, ks_stat=float(ks_stat), ks_pval=float(ks_pval), kl_div=kl_div)


def _hadamard(n: int) -> np.ndarray:
    """Unnormalised Hadamard matrix for n (must be power of 2, else pad+slice)."""
    import scipy.linalg
    # Find smallest power of 2 >= n
    p = 1
    while p < n:
        p *= 2
    H = scipy.linalg.hadamard(p)
    return H[:n, :n].astype(float)


# ═══════════════════════════════════════════════════════════════════════════════
# 8.  END-TO-END EXPERIMENT
# ═══════════════════════════════════════════════════════════════════════════════

def run_experiment(K: np.ndarray, V: np.ndarray, Q: np.ndarray,
                   K_cal: np.ndarray,
                   budgets=(2, 3, 4, 5),
                   b_tail: int = 2,
                   verbose: bool = True) -> pd.DataFrame:
    """
    Run the full SpectralQuant comparison for one (layer, head) simulation.

    Schemes compared:
        SQ-uniform   — eigenbasis + uniform bits on d_eff dims + tail
        SQ-waterfill — eigenbasis + water-filled bits on d_eff dims + tail
        SQ-wf-qjl    — same as waterfill + selective QJL on semantic dims

    Parameters
    ----------
    K, V  : (L, d_h)   key / value vectors (test set)
    Q     : (L_q, d_h) query vectors
    K_cal : (N_cal, d_h) calibration keys
    budgets : average bits per dimension to sweep

    Returns
    -------
    DataFrame with 6D error columns (from snr_metrics_6d.add_snr_err)
    """
    d_h = K.shape[1]
    rng = np.random.default_rng(RNG_SEED)

    calib = calibrate(K_cal)
    d_eff = calib["d_eff"]

    if verbose:
        print(f"  d_h={d_h}  d_eff={d_eff}  "
              f"sig_eff={calib['sig_eff'].round(3)}")
        diag = beta_diagnostic(K_cal, calib)
        print(f"  Beta diagnostic: KS={diag['ks_stat']:.3f} "
              f"p={diag['ks_pval']:.3f}  KL={diag['kl_div']:.4f}")

    rows = []

    for b in budgets:
        budget_bits = b * d_eff   # total bits for semantic subspace

        wf_bits = water_fill(calib["sig_eff"], budget_bits, min_bits=b_tail)

        for scheme_name, b_sem, use_qjl_K, use_qjl_V in [
            ("SQ-uniform",    water_fill_uniform(d_eff, b), False, False),
            ("SQ-waterfill",  wf_bits,                      False, False),
            ("SQ-wf-qjl-K",  wf_bits,                      True,  False),
            ("SQ-wf-qjl-V",  wf_bits,                      False, True),
            ("SQ-wf-qjl-KV", wf_bits,                      True,  True),
        ]:
            codec = SpectralQuantCodec(calib, b_sem, b_tail=b_tail,
                                       use_qjl_K=use_qjl_K, use_qjl_V=use_qjl_V,
                                       rng=rng)
            codec.fit_codebooks(K_cal)

            K_hat, _ = codec.encode_decode(K, is_key=True)
            V_hat, _ = codec.encode_decode(V, is_key=False)

            row = compute_row(scheme_name, b, b_sem, b_tail,
                              use_qjl_K, use_qjl_V,
                              Q, K, V, K_hat, V_hat, d_h)
            rows.append(row)

            if verbose:
                print(f"  {scheme_name:<18} b={b}  bits_sem={list(b_sem)}")
                print(f"    K:  relMSE={row['ptrelMSE_K']:.4f}  1-cos={1-row['ptcosine_K']:.4f}")
                print(f"    V:  relMSE={row['ptrelMSE_V']:.4f}  1-cos={1-row['ptcosine_V']:.4f}")
                print(f"    SM: KL={row['kl_sm']:.4f}")
                print(f"    T:  relMSE={row['relMSE']:.4f}  1-cos={1-row['cosine']:.4f}")

    df = pd.DataFrame(rows)
    df = add_snr_err(df)
    return df


# ═══════════════════════════════════════════════════════════════════════════════
# 9.  MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def make_random_kv(n_tokens, d_h, n_cal, rng):
    K_cal = rng.standard_normal((n_cal, d_h)).astype(np.float32)
    K     = rng.standard_normal((n_tokens, d_h)).astype(np.float32)
    V     = rng.standard_normal((n_tokens, d_h)).astype(np.float32)
    Q     = rng.standard_normal((min(64, n_tokens), d_h)).astype(np.float32)
    return K, V, Q, K_cal


def make_lowrank_kv(n_tokens, d_h, rank, n_cal, rng, sigma_noise=0.01):
    from scipy.linalg import orth
    U_sub = orth(rng.standard_normal((d_h, rank)))
    lam   = np.exp(-np.arange(rank) * 0.5)           # decaying eigenvalues

    def sample(n):
        Z = rng.standard_normal((n, rank)) * np.sqrt(lam)
        noise = sigma_noise * rng.standard_normal((n, d_h))
        return (Z @ U_sub.T + noise).astype(np.float32)

    K_cal = sample(n_cal)
    K     = sample(n_tokens)
    V     = sample(n_tokens)
    Q     = sample(min(64, n_tokens))
    return K, V, Q, K_cal


def main():
    parser = argparse.ArgumentParser(description="SpectralQuant CPU prototype")
    parser.add_argument("--mode",     default="random",
                        choices=["random", "lowrank", "all"])
    parser.add_argument("--budget",   type=int, nargs="+", default=[2, 3, 4, 5])
    parser.add_argument("--n_tokens", type=int, default=4096)
    parser.add_argument("--n_cal",    type=int, default=512)
    parser.add_argument("--d_h",      type=int, default=128)
    parser.add_argument("--rank",     type=int, default=4,
                        help="Effective rank for lowrank mode")
    parser.add_argument("--b_tail",   type=int, default=2)
    parser.add_argument("--out",      default=None,
                        help="CSV output path (default: metrics_<mode>.csv)")
    args = parser.parse_args()

    rng = np.random.default_rng(RNG_SEED)
    modes = ["random", "lowrank"] if args.mode == "all" else [args.mode]
    all_dfs = []

    for mode in modes:
        print(f"\n{'='*60}")
        print(f"Mode: {mode}")
        print(f"{'='*60}")

        if mode == "random":
            K, V, Q, K_cal = make_random_kv(
                args.n_tokens, args.d_h, args.n_cal, rng)
        else:
            K, V, Q, K_cal = make_lowrank_kv(
                args.n_tokens, args.d_h, args.rank, args.n_cal, rng)

        df = run_experiment(K, V, Q, K_cal,
                            budgets=args.budget,
                            b_tail=args.b_tail,
                            verbose=True)
        df["mode"] = mode
        all_dfs.append(df)

        # Print summary table
        cols = ["scheme", "budget", "d_K", "d_V", "d_T", "d_6",
                "ptrelMSE_K", "ptcosine_K"]
        print(f"\n{df[cols].to_string(index=False)}")

    result = pd.concat(all_dfs, ignore_index=True)
    out_path = args.out or f"metrics_sq_{args.mode}.csv"
    result.to_csv(out_path, index=False)
    print(f"\nSaved: {out_path}")


if __name__ == "__main__":
    main()
