
#!/bin/bash
echo "[$(date +%T)] Starting sweep on 3 GPUs..."

HIP_VISIBLE_DEVICES=0 ./sweep_hip --regime unit_sphere lowrank_aligned \
		      --budget 2 3 4 5 6 7 --trials 100 > sq_gpu0.csv 2>err0.log &
PID0=$!

HIP_VISIBLE_DEVICES=1 ./sweep_hip --regime lowrank fattail \
		      --budget 2 3 4 5 6 7 --trials 100 > sq_gpu1.csv 2>err1.log &
PID1=$!

HIP_VISIBLE_DEVICES=2 ./sweep_hip --regime lowrank_steep lowrank_misalign \
		      --budget 2 3 4 5 6 7 --trials 100 > sq_gpu2.csv 2>err2.log &
PID2=$!

wait $PID0 $PID1 $PID2 && echo "ALL DONE" || echo "SOME FAILED"

cat sq_gpu0.csv <(tail -n +2 sq_gpu1.csv) <(tail -n +2 sq_gpu2.csv) > sq_full.csv
  
