# Non-Monotone d₂ Bump: Theoretical Notes

_Developed session 2026-05-29. Replaces earlier "Lloyd-Max floor" and "attention sharpening" rationalizations with rigorous mechanistic derivation._

---

## Setup

**Notation.** S tokens, d dims, N_q queries. Attention output per query q:

$$T_q = \text{SM}(QK^T/\sqrt{d})_q \cdot V \quad \in \mathbb{R}^d$$

Quantized version with errors $\hat{K}, \hat{V}$:

$$\hat{T}_q = \hat{a}_q \cdot \hat{V}$$

where $a_q = \text{softmax}(QK^T/\sqrt{d})_q$ and $\hat{a}_q = \text{softmax}(Q\hat{K}^T/\sqrt{d})_q$.

---

## Error Decomposition

$$T_q - \hat{T}_q = \underbrace{\sum_i a_i (V_i - \hat{V}_i)}_{\text{Term 1: V-path}} + \underbrace{\sum_i (a_i - \hat{a}_i)\hat{V}_i}_{\text{Term 2: K-path}}$$

This is exact (add and subtract $\sum_i a_i \hat{V}_i$).

---

## Term 1: V-path — Zero Mean, Variance-Driven Bump

### Zero mean

Lloyd-Max fits its codebook to the **column distribution** of $V$ — i.e., each coordinate $j$ separately. This gives $\mathbb{E}[e_{i,j}] = 0$ for all $(i,j)$, where $e_{i,j} = V_{i,j} - \hat{V}_{i,j}$.

Therefore Term 1 along coordinate $j$ is:

$$[\text{Term 1}]_j = \sum_i a_i e_{i,j}, \qquad \mathbb{E}[\cdot] = \sum_i a_i \mathbb{E}[e_{i,j}] = 0$$

**The bump is not a bias effect. It is a variance effect.**

### Variance mechanism

$$\text{Var}\!\left[\sum_i a_i e_{i,j}\right] = \sum_i a_i^2 \,\sigma^2_{e_j} = \sigma^2_{e_j} \cdot \|a\|_2^2$$

Two extremes:

| Attention regime | $a_i$ | $\|a\|_2^2$ | $\text{Var}[\text{Term 1}_j]$ |
|---|---|---|---|
| Diffuse (uniform) | $1/S$ each | $1/S$ | $\sigma^2_{e_j}/S$ |
| Concentrated (1 token) | $a_k \approx 1$ | $\approx 1$ | $\sigma^2_{e_j}$ |

**As budget $b$ increases, $K$ becomes more accurate → attention sharpens → $\|a\|_2^2$ jumps → variance of Term 1 jumps.** The bump occurs at the budget where this variance jump is large relative to the simultaneous improvement in $\sigma^2_{e_j}$ (V quantization error).

---

## Term 2: K-path — Self-Correcting Dot Product

The attention weight error $a_i - \hat{a}_i$ depends on the dot product error:

$$Q_q \cdot \hat{K}_i - Q_q \cdot K_i = \sum_j Q_{q,j}(K_{i,j} - \hat{K}_{i,j}) = \sum_j Q_{q,j} \epsilon_{i,j}$$

This is a sum over $d$ terms with zero-mean errors $\epsilon_{i,j}$. By CLT:

$$\text{error in } Q_q \cdot K_i = O(\sigma_\epsilon / \sqrt{d})$$

**The dot product is self-correcting through dimension.** This is the same mechanism that makes WHT work for unit_sphere (randomization achieves the CLT averaging).

---

## QJL Channels Are Orthogonal in Mechanism

### QJL on V

Adds a 1-bit sketch $\delta V_i$ that estimates the residual $e_{i,j}$ via a second random projection. This corrects **Term 1 directly** — it reduces $\sigma^2_{e_j}$ without touching the softmax weights. The correction is linear and operates on the V-path.

### QJL on K

Adds a 1-bit sketch of the K residual. Its effect on the dot product $Q_q \cdot K_i$ adds one more corrected dimension, but:
- The dot product already sums over $d$ zero-mean terms → improvement is $O(1/d)$ marginal
- QJL-K cannot improve the $d-1$ orthogonal directions invisible to the $Q_q$ projection

**QJL-K's actual effect is on the softmax distribution SM(QK^T)**: it perturbs the partition function $Z_q = \sum_j \exp(Q_q \cdot K_j / \sqrt{d})$ and hence the attention concentration $\|a\|_2^2$. This is a **nonlinear, second-order** correction.

Experimentally: QJL-K has large effect on attention concentration metrics (1-topk5), small direct effect on 6D error.

---

## Two Distinct Bump Phenomena

### 1. unit_sphere / TQ-QKQV bump

**S-dependent and d-dependent.**

Mechanism: For isotropic data, dot products $Q_q \cdot K_i / \sqrt{d} \sim N(0, 1/d)$ by CLT. At $b=2$, quantization errors widen the effective distribution, but at large $S$ and $d$, scores concentrate near zero → softmax output is approximately uniform → **$b=2$ accidentally produces near-uniform attention** (low variance → low d₂).

At $b=3$, quantized keys gain enough range to break uniformity → attention sharpens → variance of Term 1 jumps → d₂ spikes. 

As $S$ grows, this concentration deepens (more terms in the partition function $Z_q$) → deeper $b=2$ valley → larger $b=3$ spike.

As $d$ grows, CLT applies more strongly → tighter concentration → same effect amplified.

### 2. lowrank / SQ-uniform bump

**S-independent, d-dependent.**

Mechanism: SQ allocates $b$ bits to $d_{\text{eff}}=8$ semantic dims, but fixes $b_{\text{tail}}=2$ bits for the remaining $d - 8$ tail dims. The tail floor is:

| $d$ | tail dims | tail/semantic ratio |
|---|---|---|
| 64  | 56  | 7×  |
| 128 | 120 | 15× |
| 256 | 248 | 31× |

The effective concentration $k$ (number of tokens receiving significant attention weight) is determined by the **signal subspace structure** for low-rank data, not by $S$. Therefore the variance jump $\sigma^2/k$ is the same regardless of $S$ → bump is S-independent.

The tail error $\sigma^2_{\text{tail}}$ does not decrease with $b$ (tail is always at $b_{\text{tail}}=2$). At high $d$, tail dims dominate the reconstruction error, producing a plateau. At $d=64$ the tail is proportionally smaller → SQ-uniform actually continues improving at high $b$.

**Prediction**: At $d=256$, SQ-uniform plateau is worse/longer than at $d=128$ due to 31× tail/semantic ratio.

---

## Metric Note

`relMSE` = $\|T - \hat{T}\|_F^2 / \|T\|_F^2$ where $T$ is $N_q \times d$. Since $T = \text{SM}(QK^T)V$ where the attention matrix is $(N_q \times S)(S \times d) = N_q \times d$, the $S$ dimension cancels. **relMSE is correctly normalized per output query; S-dependence in plots is real physics (attention concentration changes with S), not a measurement artifact.**

The metric `ptrelMSE_T` (per-query output relMSE) does not exist in current CSVs. Future sweeps should add it: $\frac{1}{N_q}\sum_q \|T_q - \hat{T}_q\|^2/\|T_q\|^2$.

---

## Summary Table

| Phenomenon | S-dep? | d-dep? | Root cause | Corrected by |
|---|---|---|---|---|
| unit_sphere TQ-QKQV bump | Yes | Yes | Concentration of measure → b=2 accidentally uniform | n/a (structural) |
| lowrank SQ-uniform bump | No | Yes | Attention conc. variance jump + tail floor | QJL-V (Term 1 direct), not QJL-K |
| QJL-V effectiveness | — | — | Corrects Term 1 linearly (reduces σ²_e) | — |
| QJL-K limited effect | — | — | Dot product self-corrects over d dims; K effect is on SM not Q·K | — |
