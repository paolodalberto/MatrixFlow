"""
run_comparison.py — TurboQuant vs SpectralQuant head-to-head
============================================================

Feeds identical (K, V, Q, K_cal) to both frameworks and prints a
unified summary table.

Budget convention
-----------------
  TurboQuant  : b bits per dimension across all d_h dims
                total bits = b * d_h

  SpectralQuant: b bits per semantic dimension across d_eff dims
                 tail dims use b_tail=2 bits
                 total bits = b * d_eff + b_tail * (d_h - d_eff)

  For matched total bits (d_h=128, d_eff≈8, b_tail=2):
    TQ uses 128*b bits; SQ uses 8*b + 120*2 bits
    Equal only when b=2. At b=3 TQ uses 45% more bits.
  The table notes total_bits so you can compare at matched compression.

Usage:
    python run_comparison.py                           # all regimes, b=2..5
    python run_comparison.py --regime lowrank_r8_exp random
    python run_comparison.py --budget 2 3 4 5 --quiet
"""

from __future__ import annotations
import argparse
import os
import sys

import numpy as np
import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
sys.path.insert(0, os.path.join(_HERE, "pquant_6d"))

from turbo_proto import run_turbo_experiment, REGIMES
from spectralquant_proto import run_experiment as run_sq_experiment, calibrate

D_H    = 128
B_TAIL = 2


def run_regime(name, budgets, n_tokens, n_cal, seed, verbose):
    print(f"\n{'='*68}")
    print(f"Regime: {name}")
    print(f"{'='*68}")

    fn = REGIMES[name]
    K, V, Q, K_cal = fn(n_tokens, D_H, n_cal, seed)

    # ── TurboQuant ──────────────────────────────────────────────────────────
    print("\n[TurboQuant]")
    df_tq = run_turbo_experiment(K, V, Q, K_cal, budgets=budgets,
                                 verbose=verbose)
    df_tq["framework"] = "TurboQuant"
    df_tq["total_bits_K"] = df_tq["n_bits_K"] * D_H
    df_tq["total_bits_V"] = df_tq["n_bits_V"] * D_H

    # ── SpectralQuant ───────────────────────────────────────────────────────
    print("\n[SpectralQuant]")
    calib = calibrate(K_cal)
    d_eff = calib["d_eff"]
    df_sq = run_sq_experiment(K, V, Q, K_cal, budgets=budgets,
                              b_tail=B_TAIL, verbose=verbose)
    df_sq["framework"] = "SpectralQuant"
    # SQ total bits: b_sem bits on d_eff dims + b_tail on tail
    # b_sem per dim stored in n_bits_K column (uniform / waterfill average)
    df_sq["total_bits_K"] = df_sq["n_bits_K"] * d_eff + B_TAIL * (D_H - d_eff)
    df_sq["total_bits_V"] = df_sq["n_bits_V"] * d_eff + B_TAIL * (D_H - d_eff)

    df = pd.concat([df_tq, df_sq], ignore_index=True)
    df["regime"] = name
    df["d_eff"]  = d_eff
    return df


def print_summary(all_df: pd.DataFrame):
    all_df = all_df.copy()
    all_df["dirT"] = 1 - all_df["cosine"]
    all_df["dirK"] = 1 - all_df["ptcosine_K"]
    all_df["dirV"] = 1 - all_df["ptcosine_V"]

    g = all_df.groupby(["regime", "framework", "scheme", "budget"])

    for metric, label in [
        ("ptrelMSE_K", "K  relMSE"),
        ("ptrelMSE_V", "V  relMSE"),
        ("kl_sm",      "SM KL-div"),
        ("relMSE",     "T  relMSE"),
        ("dirT",       "T  1-cos "),
    ]:
        print(f"\n{'='*68}")
        print(f"SUMMARY — {label}  (lower is better, budget = nominal bits/dim)")
        print(f"{'='*68}")
        pivot = g[metric].mean().unstack("budget")
        print(pivot.to_string())

    # total-bits breakdown for reference
    print(f"\n{'='*68}")
    print("Total bits per K vector at each budget (d_h=128, d_eff=d_eff, b_tail=2)")
    print(f"{'='*68}")
    bits_tbl = (
        all_df.groupby(["regime", "framework", "scheme", "budget"])["total_bits_K"]
        .mean()
        .unstack("budget")
    )
    print(bits_tbl.to_string())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--regime",   nargs="+", default=list(REGIMES.keys()),
                        choices=list(REGIMES.keys()))
    parser.add_argument("--budget",   type=int, nargs="+", default=[2, 3, 4, 5])
    parser.add_argument("--n_tokens", type=int, default=4096)
    parser.add_argument("--n_cal",    type=int, default=512)
    parser.add_argument("--seed",     type=int, default=42)
    parser.add_argument("--out_dir",  default=".")
    parser.add_argument("--quiet",    action="store_true")
    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    all_dfs = []

    for name in args.regime:
        df = run_regime(name, args.budget,
                        args.n_tokens, args.n_cal, args.seed,
                        verbose=not args.quiet)
        out = os.path.join(args.out_dir, f"metrics_cmp_{name}.csv")
        df.to_csv(out, index=False)
        print(f"\n  → {out}")
        all_dfs.append(df)

    all_df = pd.concat(all_dfs, ignore_index=True)
    combined = os.path.join(args.out_dir, "metrics_cmp_all.csv")
    all_df.to_csv(combined, index=False)
    print(f"\nCombined: {combined}")

    print_summary(all_df)


if __name__ == "__main__":
    main()
