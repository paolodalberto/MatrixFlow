"""
fattail_direrr_fig.py  — dir_err(T) vs budget on fattail (Results III figure)
==============================================================================
Three schemes: TQ-QKQV, SQ-uniform, Plain-KV.
X-axis: budget b=2..7.  Y-axis: median dir_err = 1 - cosine.

Usage:
    python fattail_direrr_fig.py sq_full.csv --out Paper/figures/fattail_direrr.png
"""

import argparse
import pathlib
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.lines as mlines

ap = argparse.ArgumentParser()
ap.add_argument("csv")
ap.add_argument("--out", default="fattail_direrr.png")
ap.add_argument("--dpi", type=int, default=180)
args = ap.parse_args()

SCHEMES = {
    "TQ-QKQV":   ("TQ-QKQV",   "#C62828", "-",  "o"),
    "SQ-uniform": ("SQ-uniform", "#1565C0", "--", "s"),
    "Plain-KV":   ("Plain-KV",   "#424242", ":",  "D"),
}

df = pd.read_csv(args.csv)
df.columns = [c.strip() for c in df.columns]
df = df[df["regime"] == "fattail"]
if df.empty:
    sys.exit("ERROR: no fattail rows in CSV.")

df["dir_err"] = 1.0 - df["cosine"]
budgets = sorted(df["budget"].unique())

fig, ax = plt.subplots(figsize=(6.5, 3.8))

for csv_name, (label, color, ls, marker) in SCHEMES.items():
    vals = []
    for b in budgets:
        rows = df[(df["scheme"] == csv_name) & (df["budget"] == b)]
        vals.append(rows["dir_err"].median() if not rows.empty else np.nan)
    ax.plot(budgets, vals, color=color, ls=ls, marker=marker,
            markersize=6, lw=1.8, label=label, zorder=3)

ax.set_xlabel("bit budget  $b$  (bits per cache)", fontsize=11)
ax.set_ylabel(r"$\mathrm{dir\_err}(T) = 1 - \mathrm{cosine}$", fontsize=11)
ax.set_title("fattail  —  direction error of attention output $T$",
             fontsize=11, fontweight="bold")
ax.set_xticks(budgets)
ax.set_ylim(0, 1.05)
ax.grid(True, alpha=0.28, lw=0.7)
ax.spines[["top", "right"]].set_visible(False)

handles = [
    mlines.Line2D([], [], color=c, ls=ls, marker=m, markersize=6,
                  lw=1.8, label=lbl)
    for _, (lbl, c, ls, m) in SCHEMES.items()
]
ax.legend(handles=handles, fontsize=9.5, loc="center right")

plt.tight_layout()
out = pathlib.Path(args.out)
out.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(out, dpi=args.dpi, bbox_inches="tight")
print(f"Saved → {out}")
plt.close(fig)
