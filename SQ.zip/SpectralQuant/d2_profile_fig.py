"""
d2_profile_fig.py  — D_2 profile figure for paper (3×1 panel)
=============================================================
Plots median d_2 vs. budget for four schemes across three regimes,
stacked vertically (one panel per regime).

Usage:
    python d2_profile_fig.py sq_full.csv --out Paper/figures/d2_profiles.png
    python d2_profile_fig.py sq_full.csv --out d2_profiles.png --dpi 200

Output: single PNG, 3 panels stacked vertically.
"""

import argparse
import pathlib
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.lines as mlines

# ── argument parsing ──────────────────────────────────────────────────────────
ap = argparse.ArgumentParser()
ap.add_argument("csv", help="sq_full.csv (or re-run output)")
ap.add_argument("--out", default="d2_profiles.png", help="output PNG path")
ap.add_argument("--dpi", type=int, default=180)
ap.add_argument("--regimes", nargs="+",
                default=["unit_sphere", "lowrank", "fattail"],
                help="regimes to plot (in order)")
args = ap.parse_args()

# ── scheme mapping: CSV name → display label ──────────────────────────────────
# Update left-hand side when CSV scheme names change after re-run.
SCHEME_MAP = {
    "TQ-QKQV":            "TQ-QKQV",
    "SQ-uniform":         "SQ-uniform",
    "SQ-uniform-qjlV":   "SQ-QV",
    "SQ-uniform-qjlKV":  "SQ-QKQV",
    "Plain-KV":           "Plain-KV",
}

SCHEMES = list(SCHEME_MAP.keys())   # order for legend

COLORS = {
    "TQ-QKQV":           "#C62828",   # deep red
    "SQ-uniform":        "#1565C0",   # deep blue
    "SQ-uniform-qjlV":  "#2E7D32",   # deep green
    "SQ-uniform-qjlKV": "#6A1B9A",   # deep purple
    "Plain-KV":          "#424242",   # dark grey
}

LINESTYLES = {
    "TQ-QKQV":           "-",
    "SQ-uniform":        "--",
    "SQ-uniform-qjlV":  "-.",
    "SQ-uniform-qjlKV": (0, (3, 1, 1, 1, 1, 1)),  # dash-dot-dot
    "Plain-KV":          ":",
}

MARKERS = {
    "TQ-QKQV":           "o",
    "SQ-uniform":        "s",
    "SQ-uniform-qjlV":  "^",
    "SQ-uniform-qjlKV": "v",
    "Plain-KV":          "D",
}

# ── regimes and panel titles ──────────────────────────────────────────────────
ALL_PANELS = {
    "unit_sphere": "unit_sphere  —  isotropic baseline",
    "lowrank":     "lowrank  —  structured baseline",
    "fattail":     "fattail  —  A1 violated: heavy-tailed distribution",
}
PANELS = [(r, ALL_PANELS[r]) for r in args.regimes if r in ALL_PANELS]

# ── mechanism annotations: (regime, scheme_csv, budget_x, text, offset_xy) ───
# offset_xy in data units, applied as (dx, dy) from the annotated point.
ANNOTATIONS = [
    # Lloyd-Max floor at b=2: TQ-QKQV on unit_sphere is near-zero,
    # then spikes at b=3.
    ("unit_sphere", "TQ-QKQV", 2,
     "Lloyd-Max\nfloor (b=2)", (-0.05, +0.06)),
    # Attention sharpening hump: SQ-uniform worst at b=4 in lowrank.
    ("lowrank", "SQ-uniform", 4,
     "attention\nsharpening\nhump (b=4)", (+0.15, +0.04)),
    # Flat fattail floor: annotate the SQ-uniform line mid-range.
    ("fattail", "SQ-uniform", 4,
     "eigenbasis\nmiscalibration\nfloor", (+0.15, +0.03)),
]

# ── load and compute d_2 ──────────────────────────────────────────────────────
df = pd.read_csv(args.csv)
df.columns = [c.strip() for c in df.columns]

# keep only our four schemes
df = df[df["scheme"].isin(SCHEMES)]
if df.empty:
    sys.exit("ERROR: none of the four target schemes found in CSV.")

# budget-independent quality distance
df["AS"]  = 1.0 - df["cosine"]
df["NF"]  = df["relMSE"] / (1.0 + df["relMSE"])
df["d_2"] = np.sqrt(df["AS"]**2 + df["NF"]**2)

budgets = sorted(df["budget"].unique())

def median_d2(regime, scheme):
    rows = df[(df["regime"] == regime) & (df["scheme"] == scheme)]
    return [rows[rows["budget"] == b]["d_2"].median() if not rows[rows["budget"] == b].empty
            else np.nan
            for b in budgets]

# ── build annotation lookup for quick access ─────────────────────────────────
ann_lookup = {}   # (regime, scheme_csv, b) → (text, (dx, dy))
for regime, scheme_csv, bx, text, offset in ANNOTATIONS:
    ann_lookup[(regime, scheme_csv, bx)] = (text, offset)

# ── figure ────────────────────────────────────────────────────────────────────
nrows = len(PANELS)
fig, axes = plt.subplots(
    nrows=nrows, ncols=1,
    figsize=(6.5, 2.2 * nrows + 0.4),
    sharex=True,
    squeeze=False,
)
axes = [ax[0] for ax in axes]   # flatten: always a list
fig.subplots_adjust(hspace=0.45, top=0.96)

SQRT2 = np.sqrt(2)

for ax, (regime, panel_title) in zip(axes, PANELS):
    d2_vals = {}
    for sch in SCHEMES:
        vals = median_d2(regime, sch)
        d2_vals[sch] = vals
        ax.plot(
            budgets, vals,
            color=COLORS[sch],
            ls=LINESTYLES[sch],
            marker=MARKERS[sch],
            markersize=6,
            lw=1.8,
            label=SCHEME_MAP[sch],
            zorder=3,
        )

    # annotations
    for sch in SCHEMES:
        for b in budgets:
            key = (regime, sch, b)
            if key in ann_lookup:
                text, (dx, dy) = ann_lookup[key]
                bidx = budgets.index(b)
                y0 = d2_vals[sch][bidx]
                if np.isnan(y0):
                    continue
                ax.annotate(
                    text,
                    xy=(b, y0),
                    xytext=(b + dx, y0 + dy),
                    fontsize=7.5,
                    color=COLORS[sch],
                    arrowprops=dict(arrowstyle="-|>", color=COLORS[sch],
                                   lw=0.9, mutation_scale=8),
                    va="bottom", ha="left",
                )

    # panel formatting
    ax.set_title(panel_title, fontsize=10, pad=3, fontweight="bold")
    ax.set_ylabel(r"$d_2 = \sqrt{AS^2 + NF^2}$", fontsize=10)
    ax.set_ylim(0, None)
    ax.set_xticks(budgets)
    ax.grid(True, alpha=0.28, lw=0.7)
    ax.spines[["top", "right"]].set_visible(False)

    # y upper limit: slightly above the max finite value in this panel
    # cap at sqrt(2) only if data actually reaches it
    all_vals = [v for sch in SCHEMES for v in d2_vals[sch] if not np.isnan(v)]
    if all_vals:
        ymax = max(all_vals) * 1.18
        ax.set_ylim(0, ymax)
        # only show sqrt(2) reference if it's within the plot range
        if SQRT2 < ymax:
            ax.axhline(SQRT2, color="lightgray", lw=0.8, ls="--", zorder=0)
            ax.text(budgets[-1] + 0.05, SQRT2, r"$\sqrt{2}$",
                    fontsize=7, color="lightgray", va="center")

# shared x-axis label on bottom panel only
axes[-1].set_xlabel("bit budget  $b$  (bits per cache)", fontsize=11)

# ── legend inside the top panel (lower right, where data is sparse) ──────────
legend_handles = [
    mlines.Line2D([], [], color=COLORS[sch], ls=LINESTYLES[sch],
                  marker=MARKERS[sch], markersize=6, lw=1.8,
                  label=SCHEME_MAP[sch])
    for sch in SCHEMES
]
axes[0].legend(
    handles=legend_handles,
    loc="upper right",
    ncol=1,
    fontsize=8.5,
    frameon=True,
    framealpha=0.92,
    edgecolor="lightgray",
)

# ── save ──────────────────────────────────────────────────────────────────────
out_path = pathlib.Path(args.out)
out_path.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(out_path, dpi=args.dpi, bbox_inches="tight")
print(f"Saved → {out_path}")
plt.close(fig)
