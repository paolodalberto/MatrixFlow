"""
iso_quality_budget.py  — iso-quality budget crossover analysis
==============================================================
For each regime the winner is TQ-QKQV at budget=3 (configurable).

Quality metric:
    AS  = 1 - cosine                  direction error  ∈ [0, 1]
    NF  = relMSE / (1 + relMSE)      scale error      ∈ [0, 1)
    d_2 = sqrt(AS^2 + NF^2)          budget-independent quality distance ∈ [0, sqrt(2)]
    d_2 = 0 means perfect reconstruction.

Question: minimum budget b_SQ at which best-SQ achieves d_2(b_SQ) <= d_2(winner).

Output: crossover table + per-regime d_2 profile + space surcharge (vram_B ratio).

Usage:
    python iso_quality_budget.py sq_full.csv
    python iso_quality_budget.py sq_full.csv --winner_budget 4 --out iso.md
    python iso_quality_budget.py sq_full.csv --s 256 --nq 64 --out iso_s256.md
"""

import sys
import argparse
import pandas as pd
import numpy as np

WINNER_SCHEME = "TQ-QKQV"
WINNER_BUDGET = 3

SQ_SCHEMES = [
    "SQ-uniform",        "SQ-waterfill",
    "SQ-uniform-qjlK",   "SQ-uniform-qjlV",   "SQ-uniform-qjlKV",
    "SQ-waterfill-qjlK", "SQ-waterfill-qjlV", "SQ-waterfill-qjlKV",
]

REGIME_ORDER = [
    "unit_sphere", "lowrank_aligned", "lowrank",
    "fattail", "lowrank_steep", "lowrank_misalign",
]


# ---------------------------------------------------------------------------
# Metric
# ---------------------------------------------------------------------------

def snr_err(relMSE):
    return relMSE / (1.0 + relMSE)

def quality_d2(cosine, relMSE):
    """d_2 = sqrt(AS^2 + NF^2), budget-independent quality distance."""
    AS = 1.0 - cosine
    NF = snr_err(relMSE)
    return np.sqrt(AS**2 + NF**2)


# ---------------------------------------------------------------------------
# Load and aggregate
# ---------------------------------------------------------------------------

def load(path, s_filter, nq_filter):
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    if s_filter  is not None: df = df[df["S"]  == s_filter]
    if nq_filter is not None: df = df[df["Nq"] == nq_filter]
    if df.empty:
        sys.exit(f"No rows after filtering S={s_filter} Nq={nq_filter}.")
    return df


def summarise(df):
    agg = (df.groupby(["regime", "scheme", "budget"])
             .agg(
                 med_cosine = ("cosine", "median"),
                 med_relMSE = ("relMSE", "median"),
                 med_vram   = ("vram_B", "median"),
                 med_nK     = ("n_bits_K", "median"),
                 med_nV     = ("n_bits_V", "median"),
             )
             .reset_index())
    agg["d_2"]        = quality_d2(agg["med_cosine"], agg["med_relMSE"])
    agg["total_bits"] = agg["med_nK"] + agg["med_nV"]
    return agg


# ---------------------------------------------------------------------------
# Crossover search
# ---------------------------------------------------------------------------

def find_crossover(reg_sq, d2_win, budgets):
    """Return (crossover_budget, best_scheme, d_2_at_crossover, vram, bits) or None."""
    for b in budgets:
        bsub = reg_sq[reg_sq["budget"] == b].sort_values("d_2")
        if bsub.empty:
            continue
        best = bsub.iloc[0]
        if best["d_2"] <= d2_win:
            return (b, best["scheme"], best["d_2"],
                    best["med_vram"], best["total_bits"])
    return None


# ---------------------------------------------------------------------------
# Output 1: compact crossover table
# ---------------------------------------------------------------------------

def crossover_table(agg, winner_scheme, winner_budget):
    regimes = [r for r in REGIME_ORDER if r in agg["regime"].values]
    budgets = sorted(agg["budget"].unique())

    lines = [
        f"### Crossover budget  (winner: {winner_scheme} at b={winner_budget})",
        "",
        "| regime | d_2 winner | cosine_W | NF_W | best SQ | b_cross | d_2 SQ | "
        "bits_W | bits_SQ | surcharge |",
        "|--------|------------|----------|------|---------|---------|--------|"
        "--------|---------|-----------|",
    ]

    for reg in regimes:
        w = agg[(agg["regime"]   == reg) &
                (agg["scheme"]   == winner_scheme) &
                (agg["budget"]   == winner_budget)]
        if w.empty:
            lines.append(f"| {reg} | -- | -- | -- | -- | -- | -- | -- | -- | -- |")
            continue

        wr       = w.iloc[0]
        d2_win   = wr["d_2"]
        cos_win  = wr["med_cosine"]
        nf_win   = snr_err(wr["med_relMSE"])
        vram_win = wr["med_vram"]
        bits_win = int(wr["total_bits"])

        reg_sq = agg[(agg["regime"] == reg) & agg["scheme"].isin(SQ_SCHEMES)]
        result = find_crossover(reg_sq, d2_win, budgets)

        if result is None:
            max_b  = max(budgets)
            bsub   = reg_sq[reg_sq["budget"] == max_b].sort_values("d_2")
            best7  = bsub.iloc[0] if not bsub.empty else None
            b_str  = f">b={max_b}"
            d2_str = f"{best7['d_2']:.3f}†" if best7 is not None else "--"
            sch    = best7["scheme"] if best7 is not None else "--"
            bits_s = int(best7["total_bits"]) if best7 is not None else 0
            sur    = "never"
        else:
            b_cross, sch, d2_sq, vram_sq, bits_sq = result
            b_str  = str(b_cross)
            d2_str = f"{d2_sq:.3f}"
            bits_s = int(bits_sq)
            sur    = f"{vram_sq / vram_win:.2f}×"

        lines.append(
            f"| {reg} | {d2_win:.3f} | {cos_win:.3f} | {nf_win:.3f} | "
            f"{sch} | {b_str} | {d2_str} | "
            f"{bits_win} | {bits_s} | {sur} |"
        )

    lines += [
        "",
        "† SQ never reaches d_2(winner) — value shown is best achieved at max budget.",
        "bits_W / bits_SQ = total bits per token (n_bits_K + n_bits_V).",
        "surcharge = vram_B(SQ, b_cross) / vram_B(winner, b_winner).",
        "d_2 = sqrt(AS^2 + NF^2),  AS = 1-cosine,  NF = relMSE/(1+relMSE).",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Output 2: per-regime d_2 profile
# ---------------------------------------------------------------------------

def e_profile(agg, winner_scheme, winner_budget):
    regimes = [r for r in REGIME_ORDER if r in agg["regime"].values]
    budgets = sorted(agg["budget"].unique())
    blocks  = []

    for reg in regimes:
        w = agg[(agg["regime"] == reg) &
                (agg["scheme"] == winner_scheme) &
                (agg["budget"] == winner_budget)]
        if w.empty:
            continue
        d2_win  = w.iloc[0]["d_2"]
        cos_win = w.iloc[0]["med_cosine"]
        mse_win = w.iloc[0]["med_relMSE"]

        reg_sq = agg[(agg["regime"] == reg) & agg["scheme"].isin(SQ_SCHEMES)]

        hdr = (f"### {reg}  "
               f"(d_2 winner={d2_win:.3f}  cosine={cos_win:.3f}  "
               f"relMSE={mse_win:.4f}  NF={snr_err(mse_win):.3f})")
        cols = "| scheme |" + "".join(f" b={b} |" for b in budgets)
        sep  = "|" + "---|" * (1 + len(budgets))
        lines = [hdr, "", cols, sep]

        for sch in SQ_SCHEMES:
            row = f"| {sch} |"
            for b in budgets:
                cell = reg_sq[(reg_sq["scheme"] == sch) & (reg_sq["budget"] == b)]
                if cell.empty:
                    row += " -- |"
                else:
                    d2 = cell.iloc[0]["d_2"]
                    if d2 <= d2_win:
                        row += f" **{d2:.3f}** |"
                    else:
                        row += f" {d2:.3f} |"
            lines.append(row)

        lines += ["", f"**bold** = d_2 ≤ d_2(winner) ({d2_win:.3f})", ""]
        blocks.append("\n".join(lines))

    return "\n".join(blocks)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        description="Iso-quality budget crossover: min SQ budget to match winner E")
    ap.add_argument("csv",                    help="Sweep CSV (sq_full.csv)")
    ap.add_argument("--winner_scheme", default=WINNER_SCHEME)
    ap.add_argument("--winner_budget", type=int, default=WINNER_BUDGET)
    ap.add_argument("--s",   type=int, default=None, help="Filter to single S")
    ap.add_argument("--nq",  type=int, default=None, help="Filter to single Nq")
    ap.add_argument("--out", default=None,            help="Write markdown to file")
    args = ap.parse_args()

    df  = load(args.csv, args.s, args.nq)
    agg = summarise(df)

    scope = ""
    if args.s  is not None: scope += f" S={args.s}"
    if args.nq is not None: scope += f" Nq={args.nq}"
    if not scope:            scope  = " all S and Nq"

    sections = [
        "# Iso-quality budget analysis",
        f"*Source: {args.csv} |{scope}*",
        f"*Winner: {args.winner_scheme} at b={args.winner_budget}*",
        "*d_2 = sqrt(AS^2 + NF^2),  AS = 1-cosine,  NF = relMSE/(1+relMSE)  [budget-independent]*",
        "",
        "## 1. Crossover budget table",
        "",
        crossover_table(agg, args.winner_scheme, args.winner_budget),
        "",
        "## 2. d_2 profile per regime  (bold = matches or beats winner)",
        "",
        e_profile(agg, args.winner_scheme, args.winner_budget),
    ]

    text = "\n".join(sections)

    if args.out:
        with open(args.out, "w") as f:
            f.write(text)
        print(f"Written to {args.out}")
    else:
        print(text)


if __name__ == "__main__":
    main()
