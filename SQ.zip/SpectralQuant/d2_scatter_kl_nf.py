"""
d2_scatter_kl_nf.py  —  2D error scatter: KL/(1+KL) vs NF, colored by budget or S
====================================================================================
X axis: log(1+KL)  — log-scaled KL divergence of softmax attention weights (K-path)
Y axis: NF = relMSE/(1+relMSE)  — output noise fraction (T-path)

Separates K-path error (attention concentration) from V-path error (output MSE).
QJL-K acts on X axis; QJL-V acts on Y axis.

Usage:
    python d2_scatter_kl_nf.py sq_full_final.csv \
        --regime unit_sphere --scheme TQ-QKQV \
        --out scatter_kl_nf_unit_TQ-QKQV.png

    python d2_scatter_kl_nf.py sq_full_final.csv \
        --regime unit_sphere --scheme TQ-QKQV \
        --color_by S --budget 3 \
        --out scatter_kl_nf_unit_TQ-QKQV_b3_byS.png
"""

import argparse
import pathlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BUDGET_COLORS = {
    2: "#e41a1c",
    3: "#ff7f00",
    4: "#cccc00",
    5: "#4daf4a",
    6: "#377eb8",
    7: "#984ea3",
}

ap = argparse.ArgumentParser()
ap.add_argument("csv")
ap.add_argument("--regime",   required=True)
ap.add_argument("--scheme",   required=True)
ap.add_argument("--color_by", default="budget", choices=["budget", "S"])
ap.add_argument("--budget",   type=int, default=None,
                help="Filter to single budget (use with --color_by S)")
ap.add_argument("--out",      default="scatter_kl_nf.png")
ap.add_argument("--dpi",      type=int, default=180)
ap.add_argument("--alpha",    type=float, default=0.45)
ap.add_argument("--size",     type=float, default=10)
args = ap.parse_args()

df = pd.read_csv(args.csv)
df.columns = [c.strip() for c in df.columns]

sub = df[(df["regime"] == args.regime) & (df["scheme"] == args.scheme)].copy()
if args.budget is not None:
    sub = sub[sub["budget"] == args.budget]
if sub.empty:
    print(f"No data for regime={args.regime} scheme={args.scheme} budget={args.budget}")
    exit(1)

# drop rows where KL is NaN (some regimes/schemes don't compute it)
sub = sub.dropna(subset=["KL", "relMSE"])
if sub.empty:
    print("No valid KL/relMSE rows after dropping NaN.")
    exit(1)

sub["KL_norm"] = np.log1p(sub["KL"])        # log(1+KL), natural scale, unbounded
sub["NF"]      = sub["relMSE"] / (1.0 + sub["relMSE"])

fig, ax = plt.subplots(figsize=(6.5, 5.5))

if args.color_by == "budget":
    budgets = sorted(sub["budget"].unique())
    for b in budgets:
        rows = sub[sub["budget"] == b]
        color = BUDGET_COLORS.get(b, "gray")
        ax.scatter(rows["KL_norm"], rows["NF"],
                   c=color, s=args.size, alpha=args.alpha, zorder=2)
        mx, my = rows["KL_norm"].median(), rows["NF"].median()
        ax.scatter(mx, my, c=color, s=90, marker="D",
                   edgecolors="black", linewidths=0.7, zorder=4)
        ax.annotate(f"$b={b}$", (mx, my),
                    textcoords="offset points", xytext=(5, 3),
                    fontsize=7.5, color=color, fontweight="bold")
    handles = [plt.scatter([], [], c=BUDGET_COLORS.get(b,"gray"), s=30, label=f"$b={b}$")
               for b in budgets]
    ax.legend(handles=handles, title="budget", fontsize=8, title_fontsize=8,
              loc="upper right", framealpha=0.92, edgecolor="lightgray")
    title_suffix = ""

else:  # color by S
    S_values = sorted(sub["S"].unique())
    try:
        cmap = matplotlib.colormaps["plasma"]
    except AttributeError:
        import matplotlib.cm as cm
        cmap = cm.get_cmap("plasma")
    colors = {s: cmap((i + 1) / (len(S_values) + 2)) for i, s in enumerate(S_values)}

    for s in S_values:
        rows = sub[sub["S"] == s]
        color = colors[s]
        ax.scatter(rows["KL_norm"], rows["NF"],
                   c=[color], s=args.size, alpha=args.alpha, zorder=2)
        mx, my = rows["KL_norm"].median(), rows["NF"].median()
        ax.scatter(mx, my, c=[color], s=90, marker="D",
                   edgecolors="black", linewidths=0.7, zorder=4)
        ax.annotate(f"$S={s}$", (mx, my),
                    textcoords="offset points", xytext=(5, 3),
                    fontsize=7.5, color=color, fontweight="bold")
    handles = [plt.scatter([], [], c=[colors[s]], s=30, label=f"$S={s}$")
               for s in S_values]
    ax.legend(handles=handles, title="seq len $S$", fontsize=8, title_fontsize=8,
              loc="upper right", framealpha=0.92, edgecolor="lightgray")
    title_suffix = f"  [b={args.budget}]"

# iso-lines at 45 degrees (KL_norm = NF, equal K and V path contribution)
lim = max(sub["KL_norm"].max(), sub["NF"].max()) * 1.05
ax.plot([0, lim], [0, lim], color="lightgray", lw=0.8, ls=":", zorder=0)
ax.annotate("K=V path", (lim*0.6, lim*0.6),
            fontsize=6, color="gray", rotation=45, ha="center")

ax.set_xlabel(r"$\log(1+\mathrm{KL})$  (attention divergence, K-path)", fontsize=11)
ax.set_ylabel(r"$\mathrm{NF} = \mathrm{relMSE}/(1+\mathrm{relMSE})$  (output noise, T-path)", fontsize=11)
ax.set_title(f"{args.regime} / {args.scheme}{title_suffix}", fontsize=11, fontweight="bold")
ax.set_xlim(0, None); ax.set_ylim(0, None)
ax.grid(True, alpha=0.2, lw=0.6)
ax.spines[["top", "right"]].set_visible(False)

out = pathlib.Path(args.out)
out.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(out, dpi=args.dpi, bbox_inches="tight")
print(f"Saved -> {out}")
plt.close(fig)
