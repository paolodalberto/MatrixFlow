# Iso-storage quality comparison
*Source: sq_full_final.csv | all S and Nq*
*Reference: TQ-QKQV at b=4*
*For each SQ scheme: use highest budget b where vram(SQ,b) ≤ vram(reference)*
*d_2 = sqrt(AS^2 + NF^2),  AS = 1-cosine,  NF = relMSE/(1+relMSE)  [budget-independent]*

## 1. Compact comparison (best SQ per regime)

### Iso-storage comparison  (reference: TQ-QKQV at b=4)

| regime | ref vram | ref E | best SQ | b_iso | SQ vram | SQ E | verdict |
|--------|----------|-------|---------|-------|---------|------|---------|
| unit_sphere | 73728B | 1.043 | SQ-waterfill-qjlKV | b=2† | 86016B | 0.986 | **beats** (-0.057) |
| lowrank_aligned | 73728B | 0.869 | SQ-uniform-qjlKV | b=7 | 61440B | 0.167 | **beats** (-0.702) |
| lowrank | 73728B | 0.847 | SQ-uniform-qjlKV | b=7 | 61440B | 0.410 | **beats** (-0.437) |
| fattail | 73728B | 0.336 | SQ-uniform-qjlKV | b=2† | 86016B | 0.505 | behind (+0.169) |
| lowrank_steep | 73728B | 0.593 | SQ-uniform-qjlKV | b=7 | 56320B | 0.670 | behind (+0.077) |
| lowrank_misalign | 73728B | 0.890 | SQ-uniform-qjlKV | b=7 | 57344B | 0.409 | **beats** (-0.481) |

† SQ exceeds reference storage even at minimum budget (b=2).
verdict delta tolerance = 0.014
d_2 = sqrt(AS^2 + NF^2),  AS = 1-cosine,  NF = relMSE/(1+relMSE).

## 2. All SQ schemes at iso-storage

### unit_sphere  —  reference: TQ-QKQV b=4  vram=73728B  d_2=1.043  cosine=0.395  relMSE=5.6367

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=7 | 65536B | 0.245 | 33.3158 | 0.755 | 0.971 | 1.230 | behind (+0.187) |
| SQ-waterfill | b=7 | 65536B | 0.245 | 33.3158 | 0.755 | 0.971 | 1.230 | behind (+0.187) |
| SQ-uniform-qjlK | b=2† | 75776B | 0.243 | 30.1540 | 0.757 | 0.968 | 1.229 | behind (+0.186) |
| SQ-uniform-qjlV | b=2† | 75776B | 0.406 | 4.1113 | 0.594 | 0.804 | 1.000 | **beats** (-0.043) |
| SQ-uniform-qjlKV | b=2† | 86016B | 0.406 | 4.1106 | 0.594 | 0.804 | 1.000 | **beats** (-0.043) |
| SQ-waterfill-qjlK | b=2† | 75776B | 0.246 | 28.7051 | 0.754 | 0.966 | 1.226 | behind (+0.183) |
| SQ-waterfill-qjlV | b=2† | 75776B | 0.418 | 3.9131 | 0.582 | 0.796 | 0.986 | **beats** (-0.056) |
| SQ-waterfill-qjlKV | b=2† | 86016B | 0.418 | 3.9115 | 0.582 | 0.796 | 0.986 | **beats** (-0.057) |

### lowrank_aligned  —  reference: TQ-QKQV b=4  vram=73728B  d_2=0.869  cosine=0.567  relMSE=3.0493

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=7 | 40960B | 0.649 | 1.1780 | 0.351 | 0.541 | 0.645 | **beats** (-0.224) |
| SQ-waterfill | b=7 | 40960B | 0.649 | 1.1780 | 0.351 | 0.541 | 0.645 | **beats** (-0.224) |
| SQ-uniform-qjlK | b=7 | 51200B | 0.666 | 1.2210 | 0.334 | 0.550 | 0.644 | **beats** (-0.225) |
| SQ-uniform-qjlV | b=7 | 51200B | 0.919 | 0.1710 | 0.081 | 0.146 | 0.167 | **beats** (-0.702) |
| SQ-uniform-qjlKV | b=7 | 61440B | 0.919 | 0.1705 | 0.081 | 0.146 | 0.167 | **beats** (-0.702) |
| SQ-waterfill-qjlK | b=7 | 51200B | 0.666 | 1.2210 | 0.334 | 0.550 | 0.644 | **beats** (-0.225) |
| SQ-waterfill-qjlV | b=7 | 51200B | 0.919 | 0.1710 | 0.081 | 0.146 | 0.167 | **beats** (-0.702) |
| SQ-waterfill-qjlKV | b=7 | 61440B | 0.919 | 0.1705 | 0.081 | 0.146 | 0.167 | **beats** (-0.702) |

### lowrank  —  reference: TQ-QKQV b=4  vram=73728B  d_2=0.847  cosine=0.575  relMSE=2.7478

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=7 | 40960B | 0.498 | 4.1365 | 0.502 | 0.805 | 0.949 | behind (+0.102) |
| SQ-waterfill | b=7 | 40960B | 0.498 | 4.1365 | 0.502 | 0.805 | 0.949 | behind (+0.102) |
| SQ-uniform-qjlK | b=7 | 51200B | 0.525 | 3.4511 | 0.475 | 0.775 | 0.909 | behind (+0.062) |
| SQ-uniform-qjlV | b=7 | 51200B | 0.791 | 0.6017 | 0.209 | 0.376 | 0.430 | **beats** (-0.417) |
| SQ-uniform-qjlKV | b=7 | 61440B | 0.802 | 0.5607 | 0.198 | 0.359 | 0.410 | **beats** (-0.437) |
| SQ-waterfill-qjlK | b=7 | 51200B | 0.525 | 3.4511 | 0.475 | 0.775 | 0.909 | behind (+0.062) |
| SQ-waterfill-qjlV | b=7 | 51200B | 0.791 | 0.6017 | 0.209 | 0.376 | 0.430 | **beats** (-0.417) |
| SQ-waterfill-qjlKV | b=7 | 61440B | 0.802 | 0.5607 | 0.198 | 0.359 | 0.410 | **beats** (-0.437) |

### fattail  —  reference: TQ-QKQV b=4  vram=73728B  d_2=0.336  cosine=0.813  relMSE=0.3871

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=7 | 65536B | 0.176 | 1.9360 | 0.824 | 0.659 | 1.055 | behind (+0.719) |
| SQ-waterfill | b=7 | 65536B | 0.176 | 1.9360 | 0.824 | 0.659 | 1.055 | behind (+0.719) |
| SQ-uniform-qjlK | b=2† | 75776B | 0.399 | 1.4967 | 0.601 | 0.599 | 0.849 | behind (+0.513) |
| SQ-uniform-qjlV | b=2† | 75776B | 0.306 | 1.0580 | 0.694 | 0.514 | 0.863 | behind (+0.527) |
| SQ-uniform-qjlKV | b=2† | 86016B | 0.636 | 0.5383 | 0.364 | 0.350 | 0.505 | behind (+0.169) |
| SQ-waterfill-qjlK | b=2† | 75776B | 0.279 | 4.4690 | 0.721 | 0.817 | 1.090 | behind (+0.754) |
| SQ-waterfill-qjlV | b=2† | 75776B | 0.248 | 1.4762 | 0.752 | 0.596 | 0.959 | behind (+0.623) |
| SQ-waterfill-qjlKV | b=2† | 86016B | 0.514 | 1.1618 | 0.486 | 0.537 | 0.724 | behind (+0.388) |

### lowrank_steep  —  reference: TQ-QKQV b=4  vram=73728B  d_2=0.593  cosine=0.637  relMSE=0.8820

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=7 | 35840B | 0.332 | 5.4332 | 0.668 | 0.845 | 1.077 | behind (+0.484) |
| SQ-waterfill | b=7 | 35840B | 0.332 | 5.4143 | 0.668 | 0.844 | 1.077 | behind (+0.484) |
| SQ-uniform-qjlK | b=7 | 46080B | 0.346 | 5.0240 | 0.654 | 0.834 | 1.060 | behind (+0.467) |
| SQ-uniform-qjlV | b=7 | 46080B | 0.512 | 1.0465 | 0.488 | 0.511 | 0.707 | behind (+0.114) |
| SQ-uniform-qjlKV | b=7 | 56320B | 0.540 | 0.9473 | 0.460 | 0.486 | 0.670 | behind (+0.077) |
| SQ-waterfill-qjlK | b=7 | 46080B | 0.346 | 5.0436 | 0.654 | 0.835 | 1.060 | behind (+0.468) |
| SQ-waterfill-qjlV | b=7 | 46080B | 0.512 | 1.0465 | 0.488 | 0.511 | 0.707 | behind (+0.114) |
| SQ-waterfill-qjlKV | b=7 | 56320B | 0.540 | 0.9473 | 0.460 | 0.486 | 0.670 | behind (+0.077) |

### lowrank_misalign  —  reference: TQ-QKQV b=4  vram=73728B  d_2=0.890  cosine=0.531  relMSE=3.1060

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=7 | 36864B | 0.083 | 1.0242 | 0.917 | 0.506 | 1.047 | behind (+0.158) |
| SQ-waterfill | b=7 | 36864B | 0.083 | 1.0242 | 0.917 | 0.506 | 1.047 | behind (+0.158) |
| SQ-uniform-qjlK | b=7 | 47104B | 0.059 | 1.1343 | 0.941 | 0.531 | 1.081 | behind (+0.191) |
| SQ-uniform-qjlV | b=7 | 47104B | 0.705 | 0.4902 | 0.295 | 0.329 | 0.442 | **beats** (-0.448) |
| SQ-uniform-qjlKV | b=7 | 57344B | 0.721 | 0.4279 | 0.279 | 0.300 | 0.409 | **beats** (-0.481) |
| SQ-waterfill-qjlK | b=7 | 47104B | 0.059 | 1.1343 | 0.941 | 0.531 | 1.081 | behind (+0.191) |
| SQ-waterfill-qjlV | b=7 | 47104B | 0.705 | 0.4902 | 0.295 | 0.329 | 0.442 | **beats** (-0.448) |
| SQ-waterfill-qjlKV | b=7 | 57344B | 0.721 | 0.4279 | 0.279 | 0.300 | 0.409 | **beats** (-0.481) |
