# Iso-storage quality comparison
*Source: sq_d256_t200.csv | all S and Nq*
*Reference: TQ-QKQV at b=3*
*For each SQ scheme: use highest budget b where vram(SQ,b) ≤ vram(reference)*
*d_2 = sqrt(AS^2 + NF^2),  AS = 1-cosine,  NF = relMSE/(1+relMSE)  [budget-independent]*

## 1. Compact comparison (best SQ per regime)

### Iso-storage comparison  (reference: TQ-QKQV at b=3)

| regime | ref vram | ref E | best SQ | b_iso | SQ vram | SQ E | verdict |
|--------|----------|-------|---------|-------|---------|------|---------|
| unit_sphere | 106496B | 0.066 | SQ-waterfill-qjlKV | b=2† | 135168B | 0.065 | ties (-0.001) |
| lowrank_aligned | 106496B | 0.086 | SQ-uniform-qjlV | b=7 | 93184B | 0.009 | **beats** (-0.077) |
| lowrank | 106496B | 0.188 | SQ-uniform-qjlK | b=7 | 92160B | 0.012 | **beats** (-0.176) |
| fattail | 106496B | 0.230 | SQ-waterfill-qjlKV | b=2† | 135168B | 0.366 | behind (+0.137) |
| lowrank_steep | 106496B | 0.448 | SQ-uniform-qjlKV | b=7 | 105472B | 0.102 | **beats** (-0.345) |
| lowrank_misalign | 106496B | 0.257 | SQ-uniform-qjlKV | b=7 | 106496B | 0.501 | behind (+0.243) |

† SQ exceeds reference storage even at minimum budget (b=2).
verdict delta tolerance = 0.014
d_2 = sqrt(AS^2 + NF^2),  AS = 1-cosine,  NF = relMSE/(1+relMSE).

## 2. All SQ schemes at iso-storage

### unit_sphere  —  reference: TQ-QKQV b=3  vram=106496B  d_2=0.066  cosine=0.971  relMSE=0.0629

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=7 | 98304B | 0.945 | 0.1088 | 0.055 | 0.098 | 0.112 | behind (+0.047) |
| SQ-waterfill | b=7 | 98304B | 0.945 | 0.1088 | 0.055 | 0.098 | 0.112 | behind (+0.047) |
| SQ-uniform-qjlK | b=2† | 116736B | 0.942 | 0.1135 | 0.058 | 0.102 | 0.117 | behind (+0.051) |
| SQ-uniform-qjlV | b=2† | 116736B | 0.968 | 0.0650 | 0.032 | 0.061 | 0.069 | ties (+0.003) |
| SQ-uniform-qjlKV | b=2† | 135168B | 0.969 | 0.0649 | 0.031 | 0.061 | 0.069 | ties (+0.003) |
| SQ-waterfill-qjlK | b=2† | 116736B | 0.945 | 0.1084 | 0.055 | 0.098 | 0.112 | behind (+0.046) |
| SQ-waterfill-qjlV | b=2† | 116736B | 0.970 | 0.0616 | 0.030 | 0.058 | 0.065 | ties (-0.001) |
| SQ-waterfill-qjlKV | b=2† | 135168B | 0.970 | 0.0614 | 0.030 | 0.058 | 0.065 | ties (-0.001) |

### lowrank_aligned  —  reference: TQ-QKQV b=3  vram=106496B  d_2=0.086  cosine=0.961  relMSE=0.0827

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=7 | 74752B | 0.987 | 0.0257 | 0.013 | 0.025 | 0.028 | **beats** (-0.058) |
| SQ-waterfill | b=7 | 74752B | 0.986 | 0.0286 | 0.014 | 0.028 | 0.031 | **beats** (-0.054) |
| SQ-uniform-qjlK | b=7 | 93184B | 0.987 | 0.0261 | 0.013 | 0.025 | 0.029 | **beats** (-0.057) |
| SQ-uniform-qjlV | b=7 | 93184B | 0.996 | 0.0081 | 0.004 | 0.008 | 0.009 | **beats** (-0.077) |
| SQ-uniform-qjlKV | b=2† | 111616B | 0.920 | 0.1864 | 0.080 | 0.157 | 0.176 | behind (+0.090) |
| SQ-waterfill-qjlK | b=7 | 93184B | 0.987 | 0.0249 | 0.013 | 0.024 | 0.027 | **beats** (-0.058) |
| SQ-waterfill-qjlV | b=7 | 93184B | 0.996 | 0.0085 | 0.004 | 0.008 | 0.009 | **beats** (-0.076) |
| SQ-waterfill-qjlKV | b=2† | 111616B | 0.967 | 0.0647 | 0.033 | 0.061 | 0.069 | **beats** (-0.017) |

### lowrank  —  reference: TQ-QKQV b=3  vram=106496B  d_2=0.188  cosine=0.915  relMSE=0.2008

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=7 | 73728B | 0.993 | 0.0175 | 0.007 | 0.017 | 0.018 | **beats** (-0.169) |
| SQ-waterfill | b=7 | 73728B | 0.993 | 0.0175 | 0.007 | 0.017 | 0.018 | **beats** (-0.169) |
| SQ-uniform-qjlK | b=7 | 92160B | 0.995 | 0.0111 | 0.005 | 0.011 | 0.012 | **beats** (-0.176) |
| SQ-uniform-qjlV | b=7 | 92160B | 0.991 | 0.0264 | 0.009 | 0.026 | 0.027 | **beats** (-0.160) |
| SQ-uniform-qjlKV | b=2† | 110592B | 0.764 | 0.8427 | 0.236 | 0.457 | 0.514 | behind (+0.327) |
| SQ-waterfill-qjlK | b=7 | 92160B | 0.995 | 0.0111 | 0.005 | 0.011 | 0.012 | **beats** (-0.176) |
| SQ-waterfill-qjlV | b=7 | 92160B | 0.991 | 0.0264 | 0.009 | 0.026 | 0.027 | **beats** (-0.160) |
| SQ-waterfill-qjlKV | b=2† | 110592B | 0.908 | 0.2257 | 0.092 | 0.184 | 0.206 | behind (+0.018) |

### fattail  —  reference: TQ-QKQV b=3  vram=106496B  d_2=0.230  cosine=0.890  relMSE=0.2531

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=7 | 98304B | 0.433 | 0.9295 | 0.567 | 0.482 | 0.744 | behind (+0.514) |
| SQ-waterfill | b=7 | 98304B | 0.433 | 0.9295 | 0.567 | 0.482 | 0.744 | behind (+0.514) |
| SQ-uniform-qjlK | b=2† | 116736B | 0.772 | 0.4531 | 0.228 | 0.312 | 0.386 | behind (+0.156) |
| SQ-uniform-qjlV | b=2† | 116736B | 0.446 | 0.9261 | 0.554 | 0.481 | 0.733 | behind (+0.504) |
| SQ-uniform-qjlKV | b=2† | 135168B | 0.836 | 0.5112 | 0.164 | 0.338 | 0.376 | behind (+0.146) |
| SQ-waterfill-qjlK | b=2† | 116736B | 0.776 | 0.4319 | 0.224 | 0.302 | 0.376 | behind (+0.146) |
| SQ-waterfill-qjlV | b=2† | 116736B | 0.460 | 0.9188 | 0.540 | 0.479 | 0.721 | behind (+0.492) |
| SQ-waterfill-qjlKV | b=2† | 135168B | 0.838 | 0.4898 | 0.162 | 0.329 | 0.366 | behind (+0.137) |

### lowrank_steep  —  reference: TQ-QKQV b=3  vram=106496B  d_2=0.448  cosine=0.788  relMSE=0.6502

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=7 | 68608B | 0.893 | 0.1532 | 0.107 | 0.133 | 0.171 | **beats** (-0.277) |
| SQ-waterfill | b=7 | 68608B | 0.893 | 0.1532 | 0.107 | 0.133 | 0.171 | **beats** (-0.277) |
| SQ-uniform-qjlK | b=7 | 87040B | 0.901 | 0.1337 | 0.099 | 0.118 | 0.154 | **beats** (-0.294) |
| SQ-uniform-qjlV | b=7 | 87040B | 0.927 | 0.1414 | 0.073 | 0.124 | 0.144 | **beats** (-0.304) |
| SQ-uniform-qjlKV | b=7 | 105472B | 0.946 | 0.0951 | 0.054 | 0.087 | 0.102 | **beats** (-0.345) |
| SQ-waterfill-qjlK | b=7 | 87040B | 0.901 | 0.1337 | 0.099 | 0.118 | 0.154 | **beats** (-0.294) |
| SQ-waterfill-qjlV | b=7 | 87040B | 0.927 | 0.1414 | 0.073 | 0.124 | 0.144 | **beats** (-0.304) |
| SQ-waterfill-qjlKV | b=7 | 105472B | 0.946 | 0.0951 | 0.054 | 0.087 | 0.102 | **beats** (-0.345) |

### lowrank_misalign  —  reference: TQ-QKQV b=3  vram=106496B  d_2=0.257  cosine=0.869  relMSE=0.2847

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=7 | 69632B | 0.114 | 0.9869 | 0.886 | 0.497 | 1.016 | behind (+0.759) |
| SQ-waterfill | b=7 | 69632B | 0.114 | 0.9869 | 0.886 | 0.497 | 1.016 | behind (+0.759) |
| SQ-uniform-qjlK | b=7 | 88064B | 0.114 | 0.9866 | 0.886 | 0.497 | 1.016 | behind (+0.759) |
| SQ-uniform-qjlV | b=7 | 88064B | 0.699 | 0.7395 | 0.301 | 0.425 | 0.521 | behind (+0.264) |
| SQ-uniform-qjlKV | b=7 | 106496B | 0.725 | 0.7183 | 0.275 | 0.418 | 0.501 | behind (+0.243) |
| SQ-waterfill-qjlK | b=7 | 88064B | 0.114 | 0.9866 | 0.886 | 0.497 | 1.016 | behind (+0.759) |
| SQ-waterfill-qjlV | b=7 | 88064B | 0.699 | 0.7395 | 0.301 | 0.425 | 0.521 | behind (+0.264) |
| SQ-waterfill-qjlKV | b=7 | 106496B | 0.725 | 0.7183 | 0.275 | 0.418 | 0.501 | behind (+0.243) |
