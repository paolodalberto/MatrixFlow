"""
d2_dim_scaling.py  —  d_2 vs budget for SQ-uniform on lowrank, across d=64/128/256
====================================================================================
Shows how the tail-floor plateau worsens as d grows (more tail dims, same 2-bit floor).

Usage:
    python d2_dim_scaling.py \
        --d64  sq_d64.csv \
        --d128 sq_full_final.csv \
        --d256 sq_d256.csv \
        --out  d2_dim_scaling.png
"""

import argparse
import pathlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ap = argparse.ArgumentParser()
ap.add_argument("--d64",     required=True)
ap.add_argument("--d128",    required=True)
ap.add_argument("--d256",    required=True)
ap.add_argument("--out",     default="d2_dim_scaling.png")
ap.add_argument("--dpi",     type=int, default=180)
ap.add_argument("--metric",   default="d2", choices=["d2", "d6"],
                help="d2 = budget-independent, d6 = Shannon-normalised")
ap.add_argument("--schemes", nargs="+",
                default=["TQ-QKQV", "TQ-KV"],
                help="Schemes to plot (one panel per scheme)")
ap.add_argument("--regimes", nargs="+",
                default=["lowrank", "unit_sphere"],
                help="Regimes to plot (one row per regime, or single regime for all)")
args = ap.parse_args()

CONFIGS = [
    (args.d64,  64,  "#4477AA"),
    (args.d128, 128, "#EE6677"),
    (args.d256, 256, "#228833"),
]

# Build panels: (regime, scheme, title) for each combination
if len(args.regimes) == 1:
    # Single regime — one panel per scheme
    PANELS = [(args.regimes[0], s, f"{args.regimes[0]} / {s}") for s in args.schemes]
else:
    # Multiple regimes — pair each regime with each scheme
    PANELS = [(r, s, f"{r} / {s}") for r in args.regimes for s in args.schemes]

n_panels = len(PANELS)
fig, axes = plt.subplots(1, n_panels, figsize=(4.5 * n_panels, 4.0), sharey=False)
if n_panels == 1:
    axes = [axes]
fig.subplots_adjust(wspace=0.38)

for ax, (regime, scheme, title) in zip(axes, PANELS):
    for csv, d, color in CONFIGS:
        df = pd.read_csv(csv)
        df.columns = [c.strip() for c in df.columns]

        if args.metric == "d2":
            df["AS"]   = 1.0 - df["cosine"]
            df["NF"]   = df["relMSE"] / (1.0 + df["relMSE"])
            df["score"] = np.sqrt(df["AS"]**2 + df["NF"]**2)
        else:  # d6
            for col in ["snr_err_K","dir_err_K","snr_err_V","dir_err_V","snr_err","dir_err"]:
                if col not in df.columns:
                    # map legacy names
                    if col == "snr_err":   df[col] = df.get("snr_err_T",   np.nan)
                    if col == "dir_err":   df[col] = 1.0 - df.get("cosine", np.nan)
            df["score"] = np.sqrt(
                df["snr_err_K"]**2 + df["dir_err_K"]**2 +
                df["snr_err_V"]**2 + df["dir_err_V"]**2 +
                df["snr_err"]**2  + df["dir_err"]**2)

        sub = df[(df["regime"] == regime) & (df["scheme"] == scheme)]
        if sub.empty:
            continue
        budgets = sorted(sub["budget"].unique())
        medians = [sub[sub["budget"] == b]["score"].median() for b in budgets]
        ax.plot(budgets, medians,
                color=color, marker="o", markersize=5,
                lw=2.0, label=f"$d={d}$")

    ax.set_title(title, fontsize=10, fontweight="bold", pad=4)
    ax.set_xlabel(r"bit budget $b$", fontsize=10)
    ylabel = r"$d_2$" if args.metric == "d2" else r"$d_6$"
    ax.set_ylabel(ylabel, fontsize=11)
    ax.set_ylim(0, None)
    budgets_all = [2,3,4,5,6,7]
    ax.set_xticks(budgets_all)
    ax.grid(True, alpha=0.28, lw=0.7)
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(fontsize=9, frameon=True, framealpha=0.92, edgecolor="lightgray")

out = pathlib.Path(args.out)
out.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(out, dpi=args.dpi, bbox_inches="tight")
print(f"Saved -> {out}")
plt.close(fig)
