"""
iso_storage_quality.py  — iso-storage quality comparison
=========================================================
Reference: TQ-QKQV at budget=3 (configurable).

For each regime and each SQ scheme:
  - Find the highest budget b where vram_B(SQ, b) <= vram_B(winner)
    (SQ uses at most the same storage as the reference)
  - If all SQ budgets exceed the reference, use b=2 and flag it as over-budget
  - Compare d_2(SQ, b_iso) vs d_2(winner)

Quality metric (both components in [0,1], d_2 in [0, sqrt(2)]):
    AS  = 1 - cosine                 direction error
    NF  = relMSE / (1 + relMSE)     scale error
    d_2 = sqrt(AS^2 + NF^2)         budget-independent quality distance

Verdict:
    beats   : d_2(SQ) < d_2(winner) - DELTA
    ties    : |d_2(SQ) - d_2(winner)| <= DELTA
    behind  : d_2(SQ) > d_2(winner) + DELTA

Usage:
    python iso_storage_quality.py sq_full.csv
    python iso_storage_quality.py sq_full.csv --winner_budget 4 --out iso_storage.md
    python iso_storage_quality.py sq_full.csv --s 256 --nq 64 --out iso_storage_s256.md
"""

import sys
import argparse
import pandas as pd
import numpy as np

WINNER_SCHEME = "TQ-QKQV"
WINNER_BUDGET = 3
VERDICT_DELTA = 0.014     # d_2 within this of winner = "ties"  (≈ 0.02/sqrt(2))

SQ_SCHEMES = [
    "SQ-uniform",        "SQ-waterfill",
    "SQ-uniform-qjlK",   "SQ-uniform-qjlV",   "SQ-uniform-qjlKV",
    "SQ-waterfill-qjlK", "SQ-waterfill-qjlV", "SQ-waterfill-qjlKV",
]

REGIME_ORDER = [
    "unit_sphere", "lowrank_aligned", "lowrank",
    "fattail", "lowrank_steep", "lowrank_misalign",
]


# ---------------------------------------------------------------------------
# Metric
# ---------------------------------------------------------------------------

def snr_err(relMSE):
    return relMSE / (1.0 + relMSE)

def quality_d2(cosine, relMSE):
    AS = 1.0 - cosine
    NF = snr_err(relMSE)
    return np.sqrt(AS**2 + NF**2)

def verdict(d2_sq, d2_win, delta=VERDICT_DELTA):
    diff = d2_sq - d2_win
    if diff < -delta:
        return f"**beats** ({diff:+.3f})"
    elif diff <= delta:
        return f"ties ({diff:+.3f})"
    else:
        return f"behind ({diff:+.3f})"


# ---------------------------------------------------------------------------
# Load and aggregate
# ---------------------------------------------------------------------------

def load(path, s_filter, nq_filter):
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    if s_filter  is not None: df = df[df["S"]  == s_filter]
    if nq_filter is not None: df = df[df["Nq"] == nq_filter]
    if df.empty:
        sys.exit(f"No rows after filtering S={s_filter} Nq={nq_filter}.")
    return df


def summarise(df):
    agg = (df.groupby(["regime", "scheme", "budget"])
             .agg(
                 med_cosine = ("cosine",  "median"),
                 med_relMSE = ("relMSE",  "median"),
                 med_vram   = ("vram_B",  "median"),
             )
             .reset_index())
    agg["d_2"] = quality_d2(agg["med_cosine"], agg["med_relMSE"])
    return agg


# ---------------------------------------------------------------------------
# Iso-storage budget finder
# ---------------------------------------------------------------------------

def iso_storage_budget(reg_sq, ref_vram, budgets):
    """
    Return the highest budget b where median vram_B(SQ) <= ref_vram.
    If none qualifies (SQ is over-budget even at b=2), return the lowest b
    and flag it as over-budget.
    """
    best_b    = None
    over_flag = False
    for b in budgets:
        bsub = reg_sq[reg_sq["budget"] == b]
        if bsub.empty:
            continue
        if bsub.iloc[0]["med_vram"] <= ref_vram:
            best_b = b          # keep updating — want the highest qualifying b
    if best_b is None:
        # All budgets exceed ref_vram — use lowest
        best_b    = budgets[0]
        over_flag = True
    return best_b, over_flag


# ---------------------------------------------------------------------------
# Output 1: compact comparison table (best SQ per regime at iso-storage)
# ---------------------------------------------------------------------------

def compact_table(agg, winner_scheme, winner_budget, budgets):
    regimes = [r for r in REGIME_ORDER if r in agg["regime"].values]

    lines = [
        f"### Iso-storage comparison  (reference: {winner_scheme} at b={winner_budget})",
        "",
        "| regime | ref vram | ref E | best SQ | b_iso | SQ vram | SQ E | verdict |",
        "|--------|----------|-------|---------|-------|---------|------|---------|",
    ]

    for reg in regimes:
        w = agg[(agg["regime"] == reg) &
                (agg["scheme"] == winner_scheme) &
                (agg["budget"] == winner_budget)]
        if w.empty:
            lines.append(f"| {reg} | -- | -- | -- | -- | -- | -- | -- |")
            continue

        wr       = w.iloc[0]
        d2_win   = wr["d_2"]
        ref_vram = wr["med_vram"]

        reg_sq = agg[(agg["regime"] == reg) & agg["scheme"].isin(SQ_SCHEMES)]

        # Find best SQ scheme at iso-storage budget
        best_scheme = None
        best_d2     = np.inf
        best_b      = None
        best_vram   = None
        best_over   = False

        for sch in SQ_SCHEMES:
            sch_sub = reg_sq[reg_sq["scheme"] == sch]
            if sch_sub.empty:
                continue
            b_iso, over = iso_storage_budget(sch_sub, ref_vram, budgets)
            cell = sch_sub[sch_sub["budget"] == b_iso]
            if cell.empty:
                continue
            d2_sq = cell.iloc[0]["d_2"]
            if d2_sq < best_d2:
                best_d2     = d2_sq
                best_scheme = sch
                best_b      = b_iso
                best_vram   = cell.iloc[0]["med_vram"]
                best_over   = over

        if best_scheme is None:
            lines.append(f"| {reg} | {ref_vram:.0f} | {d2_win:.3f} | -- | -- | -- | -- | -- |")
            continue

        over_tag = "†" if best_over else ""
        vd       = verdict(best_d2, d2_win)

        lines.append(
            f"| {reg} | {ref_vram:.0f}B | {d2_win:.3f} | {best_scheme} | "
            f"b={best_b}{over_tag} | {best_vram:.0f}B | {best_d2:.3f} | {vd} |"
        )

    lines += [
        "",
        "† SQ exceeds reference storage even at minimum budget (b=2).",
        "verdict delta tolerance = " + str(VERDICT_DELTA),
        "d_2 = sqrt(AS^2 + NF^2),  AS = 1-cosine,  NF = relMSE/(1+relMSE).",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Output 2: full SQ scheme grid at iso-storage per regime
# ---------------------------------------------------------------------------

def full_grid(agg, winner_scheme, winner_budget, budgets):
    regimes = [r for r in REGIME_ORDER if r in agg["regime"].values]
    blocks  = []

    for reg in regimes:
        w = agg[(agg["regime"] == reg) &
                (agg["scheme"] == winner_scheme) &
                (agg["budget"] == winner_budget)]
        if w.empty:
            continue

        wr       = w.iloc[0]
        d2_win   = wr["d_2"]
        ref_vram = wr["med_vram"]
        cos_win  = wr["med_cosine"]
        mse_win  = wr["med_relMSE"]

        reg_sq = agg[(agg["regime"] == reg) & agg["scheme"].isin(SQ_SCHEMES)]

        hdr = (f"### {reg}  —  reference: {winner_scheme} b={winner_budget}  "
               f"vram={ref_vram:.0f}B  d_2={d2_win:.3f}  "
               f"cosine={cos_win:.3f}  relMSE={mse_win:.4f}")
        lines = [
            hdr, "",
            "| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |",
            "|--------|-------|------|--------|--------|----|----|-----|---------|",
        ]

        for sch in SQ_SCHEMES:
            sch_sub = reg_sq[reg_sq["scheme"] == sch]
            if sch_sub.empty:
                continue
            b_iso, over = iso_storage_budget(sch_sub, ref_vram, budgets)
            cell = sch_sub[sch_sub["budget"] == b_iso]
            if cell.empty:
                continue
            row      = cell.iloc[0]
            d2_sq    = row["d_2"]
            over_tag = "†" if over else ""
            vd       = verdict(d2_sq, d2_win)
            lines.append(
                f"| {sch} | b={b_iso}{over_tag} | {row['med_vram']:.0f}B "
                f"| {row['med_cosine']:.3f} | {row['med_relMSE']:.4f} "
                f"| {1.0-row['med_cosine']:.3f} | {snr_err(row['med_relMSE']):.3f} "
                f"| {d2_sq:.3f} | {vd} |"
            )

        lines += [""]
        blocks.append("\n".join(lines))

    return "\n".join(blocks)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    global VERDICT_DELTA
    ap = argparse.ArgumentParser(
        description="Iso-storage quality: compare SQ vs winner at equal vram cost")
    ap.add_argument("csv",                    help="Sweep CSV (sq_full.csv)")
    ap.add_argument("--winner_scheme", default=WINNER_SCHEME)
    ap.add_argument("--winner_budget", type=int, default=WINNER_BUDGET)
    ap.add_argument("--delta", type=float, default=VERDICT_DELTA,
                    help=f"Tie tolerance in E (default {VERDICT_DELTA})")
    ap.add_argument("--s",   type=int, default=None, help="Filter to single S")
    ap.add_argument("--nq",  type=int, default=None, help="Filter to single Nq")
    ap.add_argument("--out", default=None, help="Write markdown to file")
    args = ap.parse_args()

    VERDICT_DELTA = args.delta

    df      = load(args.csv, args.s, args.nq)
    agg     = summarise(df)
    budgets = sorted(agg["budget"].unique())

    scope = ""
    if args.s  is not None: scope += f" S={args.s}"
    if args.nq is not None: scope += f" Nq={args.nq}"
    if not scope:            scope  = " all S and Nq"

    sections = [
        "# Iso-storage quality comparison",
        f"*Source: {args.csv} |{scope}*",
        f"*Reference: {args.winner_scheme} at b={args.winner_budget}*",
        "*For each SQ scheme: use highest budget b where vram(SQ,b) ≤ vram(reference)*",
        "*d_2 = sqrt(AS^2 + NF^2),  AS = 1-cosine,  NF = relMSE/(1+relMSE)  [budget-independent]*",
        "",
        "## 1. Compact comparison (best SQ per regime)",
        "",
        compact_table(agg, args.winner_scheme, args.winner_budget, budgets),
        "",
        "## 2. All SQ schemes at iso-storage",
        "",
        full_grid(agg, args.winner_scheme, args.winner_budget, budgets),
    ]

    text = "\n".join(sections)

    if args.out:
        with open(args.out, "w") as f:
            f.write(text)
        print(f"Written to {args.out}")
    else:
        print(text)


if __name__ == "__main__":
    main()
