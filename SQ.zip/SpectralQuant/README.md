# SpectralQuant / TurboQuant

Comparing KV-cache quantization strategies for transformer attention.
Implements TurboQuant (randomized WHT + Beta codebook) and SpectralQuant
(calibrated eigenbasis + water-filled bit allocation). Two implementations:
a CPU prototype in Python and a GPU sweep in HIP/C++.

---

## GPU Sweep: `sweep_hip.hip`

The paper results come from a full GPU sweep over all schemes, regimes, and
budgets. The HIP/C++ implementation runs on AMD GPUs (tested on MI100).

### Compile

```bash
hipcc -O3 -o sweep_hip sweep_hip.hip -lrocblas
```

Requires ROCm and rocBLAS. Head dimension `D=128` is a compile-time constant
(defined in `pquant_common.h`); recompile to change.

### Run

```bash
./sweep_hip [--trials N] [--seed S] [--regime R] [--budget B]
```

Defaults: 100 trials, seed 42, all 6 regimes, budgets 2–7.
Output is CSV to stdout with columns for cosine, relMSE, timing, and VRAM.

Example — 200 trials on a single regime:

```bash
./sweep_hip --trials 200 --regime lowrank_aligned > lowrank_aligned.csv
```

### Architecture

**CPU encode, GPU decode.** For each trial the host draws a synthetic KV
tensor, encodes it (eigenbasis rotation + quantization), transfers compressed
codes to the device, then launches GPU kernels to decode and compute attention.

Each trial executes 6 GPU passes:

| Pass | Description |
|---|---|
| FP32 reference | Unquantized attention in fp32 |
| FP32 quantized | Quantized decode + attention in fp32 |
| K-isolation | Quantize K only (V exact) — isolates K error |
| V-isolation | Quantize V only (K exact) — isolates V error |
| FP16 reference | Unquantized timing pass in fp16 |
| FP16 quantized | Quantized timing pass in fp16 |

Attention is computed with rocBLAS GEMM (`rocblas_sgemm` / `rocblas_hgemm`).

### Schemes

13 scheme variants as `enum SchemeKind` covering all combinations of:

| Axis | Options |
|---|---|
| Basis | Plain (no WHT), TurboQuant WHT, SpectralQuant eigenbasis |
| QJL | none, QJL-K, QJL-V, QJL-KV |
| Bit allocation | uniform, water-fill |

Relevant decode kernels:

| Kernel | Role |
|---|---|
| `decode_wht_fp32/fp16` | TurboQuant decode — inverse WHT + denorm |
| `decode_plain_fp32/fp16` | Baseline plain decode — no WHT |
| `decode_qjl_fp32/fp16` | TurboQuant + QJL residual correction |
| `sq_decode_fp32/fp16` | SpectralQuant decode — inverse eigenbasis rotate |
| `sq_decode_qjl_fp32/fp16` | SpectralQuant + QJL correction (in token space) |
| `softmax_fp32/fp16` | Online softmax for attention output |

GPU memory for all trials is allocated once in `alloc_device_buffers()` and
reused across trials.

### Regimes

Six synthetic data regimes: `unit_sphere`, `lowrank`, `lowrank_aligned`,
`lowrank_steep`, `lowrank_misalign`, `fattail`. See paper for definitions.

---

## CPU Prototype Files

| File | Purpose |
|---|---|
| `turbo_proto.py` | TurboQuant codec + regime registry + standalone runner |
| `spectralquant_proto.py` | SpectralQuant codec (calibrate, water-fill, Lloyd-Max, QJL) |
| `synth_kv.py` | Synthetic KV generators (lowrank, student-t, misaligned, two-population) |
| `run_comparison.py` | Head-to-head TQ vs SQ at fixed (n\_tokens, n\_queries) |
| `run_sweep.py` | Full sweep: all regimes × budgets × n\_tokens × n\_queries + timing |
| `run_ladder.py` | SpectralQuant-only sweep over all regimes |
| `plot_results.py` | Plots from sweep CSV: rate-distortion, scaling, throughput, Pareto |
| `pquant_6d/snr_metrics_6d.py` | 6D error metric vector used by both codecs |

---

## Quantization Schemes

### TurboQuant (data-oblivious)

Pipeline per token vector `v`:
1. **Normalize** — `v̂ = v / ‖v‖`, store norm as FP32 side-channel
2. **Randomize** — `r = WHT(v̂ ⊙ s) / √d` where `s ∈ {±1}^d` fixed random signs; each coordinate of `r` follows `Beta((d-1)/2, (d-1)/2)` on `[-1,1]`
3. **Quantize** — shared Lloyd-Max codebook fitted analytically to Beta
4. **QJL** (optional) — 1-bit sketch of MSE residual via a second WHT
5. **Decode** — dequantize → add QJL estimate → inverse WHT → denormalize

Codebook is fitted **offline** to the analytical Beta distribution (50 000 samples, 500 Lloyd-Max iterations). No calibration data needed at runtime.

**Five scheme variants** at nominal budget `b` bits/dim:

| Scheme | K encoding | V encoding | Total bits K | Total bits V |
|---|---|---|---|---|
| `Plain-KV` | b-bit MSE, **no WHT** | b-bit MSE, no WHT | b·d | b·d |
| `TQ-KV` | b-bit MSE + WHT | b-bit MSE + WHT | b·d | b·d |
| `TQ-QKV` | (b−1)-bit MSE + 1-bit QJL + WHT | b-bit MSE + WHT | b·d | b·d |
| `TQ-KQV` | b-bit MSE + WHT | (b−1)-bit MSE + 1-bit QJL + WHT | b·d | b·d |
| `TQ-QKQV` | (b−1)-bit MSE + 1-bit QJL + WHT | (b−1)-bit MSE + 1-bit QJL + WHT | b·d | b·d |

> **`Plain-KV`** is a baseline reproducing the HIP `encode_plain` scheme (no WHT). It fails on aligned low-rank data, demonstrating that WHT is the core mechanism.

### SpectralQuant (data-aware)

Pipeline:
1. **Calibrate** — `Σ_K = K_cal^T K_cal / N` → `eigh` → eigenvectors `U`, eigenvalues `σ`; participation ratio `d_eff = (Σσ)²/Σσ²`
2. **Water-fill** — greedy integer bit allocation over `d_eff` semantic dims
3. **Rotate** — `K_rot = K @ U_eff` (semantic subspace); tail dims `d_eff..d` get `b_tail=2` bits
4. **Per-dim Lloyd-Max** — empirical codebook per semantic dimension (fitted on calibration projections)
5. **Selective QJL** (optional) — 1-bit sketch on K or V residuals
6. **Decode** — inverse rotate back to `d_h` space

**Five scheme variants:**

| Scheme | QJL on K | QJL on V |
|---|---|---|
| `SQ-uniform` | No | No |
| `SQ-waterfill` | No | No |
| `SQ-wf-qjl-K` | Yes | No |
| `SQ-wf-qjl-V` | No | Yes |
| `SQ-wf-qjl-KV` | Yes | Yes |

> **Total bits** for SQ: `n_bits_K · d_eff + b_tail · (d − d_eff)`. At `d=128`, `d_eff=8`, `b_tail=2` this is `8b + 240` — much less than TQ's `128b` for `b ≥ 3`.

---

## Synthetic Regimes

| Regime | Description | d\_eff | WHT helps? | Water-fill helps? |
|---|---|---|---|---|
| `random` | Uniform on unit sphere | ~128 | No (already Beta) | No |
| `lowrank_aligned` | Rank-8 in **first 8 dims** (no random rotation) | ~8 | **Yes** (critical) | No (equal λ) |
| `lowrank_r4` | Rank-4, uniform λ, random subspace | 4 | No (random U pre-rotates) | No |
| `lowrank_r4_exp` | Rank-4, exponential λ decay, random subspace | <4 | No | **Yes** |
| `lowrank_r8_exp` | Rank-8, exponential λ decay, random subspace | ~4 | No | **Yes** |
| `lowrank_r16` | Rank-16, uniform λ, random subspace | 16 | No | Marginal |
| `fattail_nu3` | Student-t(3) marginals | 4 | No | No (codebook mismatch) |
| `fattail_nu15` | Student-t(1.5) — undefined variance | 4 | No | No (catastrophic) |
| `misalign_0` | K and V same subspace | 4 | No | No |
| `misalign_90` | K and V orthogonal subspaces | 4 | No | No (V floor) |
| `twopop` | Two-population mixture (d\_eff=4 vs 12) | mixed | No | Marginal |

> **`lowrank_aligned` is the correct test of WHT**: `Plain-KV` is catastrophic here (SM KL 1400× worse at b=5); `TQ-KV` is correct. All other `lowrank_*` regimes use a random orthogonal subspace `U` that pre-rotates the signal into the Beta regime, making WHT redundant.

---

## Key Findings

1. **WHT is essential only for aligned (non-randomly-rotated) low-rank data.** For random-subspace low-rank data, the random `U` already achieves what WHT does.

2. **`Plain-KV` with Beta codebook on aligned low-rank data is catastrophic and non-monotone** — more bits makes T relMSE *worse* at b=5 because sharper attention concentrates on badly reconstructed tokens.

3. **QJL on K is harmful** for structured data (worsens SM KL). QJL on V is beneficial at high budget (b≥4), stabilizing the b=4/5 attention-amplification bump.

4. **The b=4/5 V-amplification bump**: Better K → sharper attention → V errors amplified → T relMSE spikes. `TQ-KQV` (QJL on V) makes T monotone in b.

5. **SpectralQuant's advantage is bit efficiency, not peak quality.** At matched total bits (b=2, 256 bits), TQ-KV ≥ SQ on all regimes. SQ wins when bits are matched correctly (SQ b=5 uses only 268 bits vs TQ b=2 at 256 bits, but T 1-cos improves 3×).

6. **TurboQuant codebook quality advantage**: analytical Beta codebook (500 iter, 50K samples) vs SQ empirical codebook (50 iter, 512 samples). SQ overfits if iterations are increased — early stopping is implicit regularization.

7. **For random (isotropic) data, SpectralQuant fails badly** (T relMSE 3-4× worse than TQ-KV at b=2). TurboQuant's data-oblivious design is optimal here.

---

## Metrics

| Column | Definition |
|---|---|
| `ptrelMSE_K` | Mean per-token `‖K−K̂‖²/‖K‖²` |
| `ptrelMSE_V` | Mean per-token `‖V−V̂‖²/‖V‖²` |
| `kl_sm` | KL(softmax(QK^T/√d) ‖ softmax(QK̂^T/√d)) — K-path only |
| `relMSE` | Mean per-query `‖T−T̂‖²/‖T‖²` where T=softmax(QK̂^T/√d)V̂ |
| `cosine` / `dirT` | Mean per-query cosine similarity / `1-cosine` of T vs T̂ |
| `total_bits_K` | Actual bits per K vector (accounts for d\_eff in SQ) |
| `t_enc_K_ms` | Wall-clock encode time for all K tokens (ms) |
| `tok_per_s_K` | K encode throughput (tokens/second) |

---

## Quick Start

```bash
# Head-to-head comparison on two regimes
python run_comparison.py --regime lowrank_aligned random --quiet

# Full sweep (all regimes, all token counts, with timing)
python run_sweep.py --regime lowrank_aligned random lowrank_r8_exp \
    --n_tokens 1024 4096 16384 --n_queries 64 256 --quiet

# Generate all plots from sweep output
python plot_results.py --csv sweep_results/sweep_all.csv --out_dir plots

# TurboQuant-only run (faster)
python turbo_proto.py --regime lowrank_aligned random --budget 2 3 4 5 --quiet
```

---

## Budget Comparison Note

TurboQuant and SpectralQuant use `budget` (bits/dim) as their nominal parameter,
but spend bits differently:

| Method | Total bits per K vector at budget b |
|---|---|
| TurboQuant | `b × d_h = 128b` |
| SpectralQuant | `b × d_eff + 2 × (d_h − d_eff)` |

The **only fair comparison point** for most regimes is `b=2` (256 bits for both).
At `b=3`, TurboQuant spends 384 bits vs SpectralQuant's ~264 bits (for `d_eff=8`).
Rate-distortion plots (`plot_results.py`) use `total_bits_K` on the x-axis for
a correct comparison.
