"""
cell_variance.py  —  variance of quality metrics within each (scheme, regime, budget, S) cell
==============================================================================================
Shows how much trial-to-trial variation exists after controlling for S and budget.
If concentration of measure is dominant, std should be tiny relative to the mean.

Usage:
    python cell_variance.py sq_full_final.csv \
        --regime unit_sphere --scheme TQ-QKQV TQ-KV \
        --out variance_unit_TQ.csv
"""

import argparse
import pathlib
import numpy as np
import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument("csv")
ap.add_argument("--regime",  nargs="+", default=None)
ap.add_argument("--scheme",  nargs="+", default=None)
ap.add_argument("--out",     default="cell_variance.csv")
args = ap.parse_args()

df = pd.read_csv(args.csv)
df.columns = [c.strip() for c in df.columns]

if args.regime:
    df = df[df["regime"].isin(args.regime)]
if args.scheme:
    df = df[df["scheme"].isin(args.scheme)]

cos = df["cosine"].clip(-1.0, 1.0)
df["sin_theta"] = np.sqrt(np.maximum(0.0, 1.0 - cos**2))
df["NF"]        = df["relMSE"] / (1.0 + df["relMSE"])
df["d_2"]       = np.sqrt(df["sin_theta"]**2 + df["NF"]**2)

group = ["scheme", "regime", "budget", "S"]
agg = df.groupby(group).agg(
    n          = ("d_2",       "count"),
    d2_mean    = ("d_2",       "mean"),
    d2_std     = ("d_2",       "std"),
    d2_cv      = ("d_2",       lambda x: x.std() / x.mean() if x.mean() > 0 else np.nan),
    sin_mean   = ("sin_theta", "mean"),
    sin_std    = ("sin_theta", "std"),
    NF_mean    = ("NF",        "mean"),
    NF_std     = ("NF",        "std"),
).reset_index()

agg = agg.sort_values(["scheme", "regime", "budget", "S"])

out = pathlib.Path(args.out)
agg.to_csv(out, index=False, float_format="%.6f")
print(f"Saved -> {out}")
print()

# summary: mean CV across all cells per scheme
print("Mean coefficient of variation (std/mean) of d_2 per scheme:")
print(agg.groupby("scheme")["d2_cv"].mean().sort_values().to_string())
print()
print("Max std of d_2 per scheme:")
print(agg.groupby("scheme")["d2_std"].max().sort_values().to_string())
print()
print("Sample cells (sorted by d2_std descending):")
print(agg.nlargest(20, "d2_std")[
    ["scheme","regime","budget","S","n","d2_mean","d2_std","d2_cv"]
].to_string(index=False))
