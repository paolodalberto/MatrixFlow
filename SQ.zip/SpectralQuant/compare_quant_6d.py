"""
compare_quant_6d.py — pairwise scheme comparison: d_2 curves + 6D scatter
==========================================================================
Usage:
    python compare_quant_6d.py sq_full.csv \\
        --scheme_a SQ-uniform-qjlV --scheme_b SQ-uniform \\
        --budget 2 3 4 5 6 7 --regime unit_sphere --outdir cmp/

Output:
    d2_curve.png         — D_2(budget) curves for both schemes (budget-independent)
    d6_compare_B<n>.png  — 6D Shannon-normalised scatter per budget
    stdout               — d_2 table, D_2 distance, energy distances

Metrics
-------
d_2(regime, scheme, budget) — budget-INDEPENDENT quality distance:
    AS  = 1 − cosine                   Absolute Sine  (direction error)
    NF  = relMSE / (1 + relMSE)        Noise Fraction (scale error)
    d_2 = sqrt(AS² + NF²)             in [0, sqrt(2)],  0 = perfect

D_2 = [d_2(b=2), ..., d_2(b=7)]   — quality profile vector across budgets
||D_2(A) − D_2(B)||                — scheme similarity across all budgets

d_6 — Shannon-normalised 6D distance (budget-relative, for per-budget diagnosis)

Scatter encoding:
    shape  ●  K cache   (snr_err_K,  dir_err_K)
    shape  ▲  V cache   (snr_err_V,  dir_err_V)
    shape  ■  T output  (snr_err,    dir_err)
    color  red    scheme_a
    color  green  scheme_b
    size   ∝ log(S)
"""

import sys
import argparse
import pathlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.lines
import matplotlib.patches
from scipy import stats

from snr_metrics_6d import (
    add_snr_err, energy_distance, energy_distance_6d,
    SNR_ERR_LM, SCALAR_LOSS, DIM_NAMES
)

# ── arguments ─────────────────────────────────────────────────────────────────
parser = argparse.ArgumentParser()
parser.add_argument("csv")
parser.add_argument("--budget",   required=True, nargs="+", type=int)
parser.add_argument("--scheme_a", default="KQV")
parser.add_argument("--scheme_b", default="KV")
parser.add_argument("--regime",   default=None,
                    help="filter to one regime (e.g. unit_sphere); default: all")
parser.add_argument("--origin",   choices=["shannon", "lloyd"], default="shannon")
parser.add_argument("--n_perm",   type=int, default=999,
                    help="number of permutations for energy distance p-value")
parser.add_argument("--show",     action="store_true")
parser.add_argument("--outdir",   default=".",
                    help="directory for output PNGs (default: current dir)")
args = parser.parse_args()
pathlib.Path(args.outdir).mkdir(parents=True, exist_ok=True)

# ── x-axis selection ──────────────────────────────────────────────────────────
lm = (args.origin == "lloyd")

def x_col(component):
    """Return the snr_err column name for a given component."""
    base = {"K": "snr_err_K", "V": "snr_err_V", "T": "snr_err"}[component]
    return base + ("_lm" if lm else "")

def d_col(component):
    return {"K": "d_K", "V": "d_V", "T": "d_T"}[component] + ("_lm" if lm else "")

x_label = (
    "snr_err_lm  =  1 − SNR/SNR_lloyd-max   [Lloyd-Max origin]"
    if lm else
    "snr_err  =  1 − SNR/SNR_shannon   [scale error]"
)

# ── permutation test for energy distance ─────────────────────────────────────
def _6d_array(df, lm=False):
    """Extract the 6D error matrix from a DataFrame."""
    suf  = "_lm" if lm else ""
    cols = [f"snr_err_K{suf}", "dir_err_K",
            f"snr_err_V{suf}", "dir_err_V",
            f"snr_err{suf}",   "dir_err"]
    return df[cols].values


def permutation_pvalue(X, Y, n_perm=999, seed=0):
    """
    Permutation p-value for the energy distance (two-sample test).

    H0: X and Y are drawn from the same distribution  →  E = 0.
    p  = (# permutations where E_perm >= E_obs  +  1) / (n_perm + 1)

    The +1 / (n_perm+1) correction (Phipson & Smyth 2010) keeps p > 0
    and controls type-I error even at small n_perm.
    """
    rng   = np.random.default_rng(seed)
    n     = len(X)
    pool  = np.concatenate([X, Y], axis=0)
    E_obs = energy_distance(X, Y)
    count = 0
    for _ in range(n_perm):
        perm = rng.permutation(len(pool))
        if energy_distance(pool[perm[:n]], pool[perm[n:]]) >= E_obs:
            count += 1
    return (count + 1) / (n_perm + 1)


# ── load ──────────────────────────────────────────────────────────────────────
df_raw = add_snr_err(pd.read_csv(args.csv))
df_raw.columns = [c.strip() for c in df_raw.columns]

# regime filter
if args.regime:
    df_raw = df_raw[df_raw["regime"] == args.regime]
    if df_raw.empty:
        sys.exit(f"ERROR: no rows for regime='{args.regime}'")
    mode = args.regime
else:
    mode = pathlib.Path(args.csv).stem.replace("metrics_", "")

# ── d_2 (budget-independent) ──────────────────────────────────────────────────
df_raw["AS"]  = 1.0 - df_raw["cosine"]
df_raw["NF"]  = df_raw["relMSE"] / (1.0 + df_raw["relMSE"])
df_raw["d_2"] = np.sqrt(df_raw["AS"]**2 + df_raw["NF"]**2)

# ── colours / markers ─────────────────────────────────────────────────────────
# Two schemes, three components.
# Scheme colour: orange family for turbo, green family for plain.
# Component shape: ● K, ▲ V, ■ T

SCHEME_COLOR = {
    args.scheme_a: "#D65F5F",   # turbo — red/orange
    args.scheme_b: "#4DAF4A",   # plain — green
}
COMPONENT = {
    "K": dict(marker="o",  y_col="dir_err_K", label="K cache"),
    "V": dict(marker="^",  y_col="dir_err_V", label="V cache"),
    "T": dict(marker="s",  y_col="dir_err",   label="T output"),
}

SEQ_LENS = sorted(df_raw["S"].unique())
S_MIN, S_MAX = min(SEQ_LENS), max(SEQ_LENS)

def point_size(s):
    """Map sequence length to marker area (px²)."""
    t = np.log(s / S_MIN) / max(np.log(S_MAX / S_MIN), 1e-6)
    return 18 + 90 * t

# ── per-budget loop ───────────────────────────────────────────────────────────
for n in sorted(args.budget):
    sub = df_raw[df_raw["budget"] == n]
    if sub.empty:
        print(f"WARNING: no rows for budget={n}", file=sys.stderr)
        continue

    da = sub[sub["scheme"] == args.scheme_a]
    db = sub[sub["scheme"] == args.scheme_b]

    if da.empty or db.empty:
        print(f"WARNING: budget={n} missing one scheme", file=sys.stderr)
        continue

    # ── NaN/inf guard ─────────────────────────────────────────────────────────
    _guard_cols = ["snr_err_K", "dir_err_K", "snr_err_V", "dir_err_V",
                   "snr_err",   "dir_err",
                   "snr_err_K_lm", "snr_err_V_lm", "snr_err_lm", "d_6",
                   "AS", "NF", "d_2"]
    # optional columns present only in older per-regime CSVs
    for _opt in ["KL", "topk5"]:
        if _opt in sub.columns:
            _guard_cols.append(_opt)

    def _drop_bad(df, label):
        mask = df[_guard_cols].replace([np.inf, -np.inf], np.nan).isna().any(axis=1)
        n_bad = mask.sum()
        if n_bad:
            print(f"  WARNING: budget={n} {label}: dropping {n_bad}/{len(df)} "
                  f"NaN/inf rows", file=sys.stderr)
        return df[~mask]

    da = _drop_bad(da, args.scheme_a)
    db = _drop_bad(db, args.scheme_b)

    if da.empty or db.empty:
        print(f"WARNING: budget={n} all rows dropped after NaN filter", file=sys.stderr)
        continue

    # ── energy distance + permutation p-values ────────────────────────────────
    Xa, Ya       = _6d_array(da, lm=False), _6d_array(db, lm=False)
    Xa_lm, Ya_lm = _6d_array(da, lm=True),  _6d_array(db, lm=True)

    ed    = energy_distance(Xa,    Ya)
    ed_lm = energy_distance(Xa_lm, Ya_lm)

    p_perm    = permutation_pvalue(Xa,    Ya,    n_perm=args.n_perm)
    p_perm_lm = permutation_pvalue(Xa_lm, Ya_lm, n_perm=args.n_perm)

    # ── d_6 stats ─────────────────────────────────────────────────────────────
    d6_a = da["d_6"].values
    d6_b = db["d_6"].values
    mw   = stats.mannwhitneyu(d6_a, d6_b, alternative="two-sided")
    r_mw = 1.0 - 2.0 * mw.statistic / (len(d6_a) * len(d6_b))

    print(f"\n── budget={n}  {args.scheme_a} vs {args.scheme_b} ──────────────────")
    print(f"  energy_dist_6d        = {ed:.4f}   p_perm={p_perm:.4f}")
    print(f"  energy_dist_6d_lm     = {ed_lm:.4f}   p_perm={p_perm_lm:.4f}")
    print(f"  d_6  median {args.scheme_a}={np.median(d6_a):.4f}  "
          f"median {args.scheme_b}={np.median(d6_b):.4f}")
    print(f"  MW   p={mw.pvalue:.2e}  r={r_mw:+.3f}")

    # per-dimension medians
    print(f"  {'dim':<12} {args.scheme_a:>8} {args.scheme_b:>8}")
    for dim in DIM_NAMES:
        if dim in da.columns and dim in db.columns:
            print(f"  {dim:<12} {da[dim].median():>8.4f} {db[dim].median():>8.4f}")

    # d_2 (budget-independent)
    d2_a = da["d_2"].values
    d2_b = db["d_2"].values
    mw_d2 = stats.mannwhitneyu(d2_a, d2_b, alternative="two-sided")
    r_d2  = 1.0 - 2.0 * mw_d2.statistic / (len(d2_a) * len(d2_b))
    print(f"  d_2      median {args.scheme_a}={np.median(d2_a):.4f}  "
          f"median {args.scheme_b}={np.median(d2_b):.4f}  "
          f"MW p={mw_d2.pvalue:.2e}  r={r_d2:+.3f}")
    print(f"           AS  {args.scheme_a}={da['AS'].median():.4f}  "
          f"{args.scheme_b}={db['AS'].median():.4f}   "
          f"NF  {args.scheme_a}={da['NF'].median():.4f}  "
          f"{args.scheme_b}={db['NF'].median():.4f}")

    if "KL" in da.columns and "KL" in db.columns:
        kl_a, kl_b = da["KL"].values, db["KL"].values
        mw_kl = stats.mannwhitneyu(kl_a, kl_b, alternative="two-sided")
        r_kl  = 1.0 - 2.0 * mw_kl.statistic / (len(kl_a) * len(kl_b))
        print(f"  KL       median {args.scheme_a}={np.median(kl_a):.4f}  "
              f"median {args.scheme_b}={np.median(kl_b):.4f}  "
              f"MW p={mw_kl.pvalue:.2e}  r={r_kl:+.3f}")

    if "topk5" in da.columns and "topk5" in db.columns:
        tk_a, tk_b = 1.0 - da["topk5"].values, 1.0 - db["topk5"].values
        mw_tk = stats.mannwhitneyu(tk_a, tk_b, alternative="two-sided")
        r_tk  = 1.0 - 2.0 * mw_tk.statistic / (len(tk_a) * len(tk_b))
        print(f"  1-topk5  median {args.scheme_a}={np.median(tk_a):.4f}  "
              f"median {args.scheme_b}={np.median(tk_b):.4f}  "
              f"MW p={mw_tk.pvalue:.2e}  r={r_tk:+.3f}")

    # ── figure ────────────────────────────────────────────────────────────────
    fig, ax = plt.subplots(figsize=(8, 7))

    origin_tag = "Lloyd-Max-normalised" if lm else "Shannon-normalised"
    fig.suptitle(
        f"6D error geometry [{origin_tag}] — budget={n}   "
        f"{args.scheme_a} vs {args.scheme_b}\n"
        f"mode: {mode}   "
        f"E_dist={ed:.4f} (p={p_perm:.4f})   "
        f"E_dist_lm={ed_lm:.4f} (p={p_perm_lm:.4f})\n"
        f"shape: ● K   ▲ V   ■ T          "
        f"colour: orange={args.scheme_a}   green={args.scheme_b}",
        fontsize=9)

    # quarter-circle contours
    theta = np.linspace(0, np.pi / 2, 300)
    for r, ls, lbl in [(0.25, "--", "d=0.25"), (0.5, ":", "d=0.5"), (0.82, "-.", "d≈0.82")]:
        ax.plot(r * np.cos(theta), r * np.sin(theta),
                color="gray", lw=0.8, ls=ls, alpha=0.5)
        ax.text(r * np.cos(np.radians(12)), r * np.sin(np.radians(12)),
                lbl, fontsize=6, color="gray", alpha=0.7, ha="left")

    # Lloyd-Max reference line on x-axis
    if lm:
        ax.axvline(0.0, color="steelblue", lw=0.9, ls=":", alpha=0.55)
        ax.text(0.01, 0.97, "Lloyd-Max\n(origin)",
                fontsize=7, color="steelblue", va="top", ha="left",
                transform=ax.get_xaxis_transform())
    else:
        ax.axvline(SNR_ERR_LM, color="steelblue", lw=0.9, ls=":", alpha=0.55)
        ax.text(SNR_ERR_LM + 0.01, 0.97,
                f"Lloyd-Max\n≈{SNR_ERR_LM:.2f}",
                fontsize=7, color="steelblue", va="top", ha="left",
                transform=ax.get_xaxis_transform())

    # scatter: all six (scheme × component) clouds
    for scheme, df_s in [(args.scheme_a, da), (args.scheme_b, db)]:
        base_color = SCHEME_COLOR[scheme]
        for comp, cspec in COMPONENT.items():
            xvals = df_s[x_col(comp)].values
            yvals = df_s[cspec["y_col"]].values
            sizes = [point_size(s) for s in df_s["S"].values]
            ax.scatter(xvals, yvals,
                       c=base_color, s=sizes,
                       marker=cspec["marker"],
                       alpha=0.65, edgecolors="none", zorder=3)

    ax.set_xlabel(x_label, fontsize=10)
    ax.set_ylabel("direction error  (1 − cosine — lower is better)", fontsize=10)
    ax.set_xlim(0, 1.05)
    ax.set_ylim(0, 1.05)
    ax.grid(True, alpha=0.3)

    origin_label = "Lloyd-Max" if lm else "Shannon-optimal"
    ax.text(0.02, 0.02, origin_label, transform=ax.transAxes,
            va="bottom", ha="left", fontsize=9, color="seagreen", fontweight="bold")

    # ── legend ────────────────────────────────────────────────────────────────
    legend_handles = [
        # schemes
        matplotlib.lines.Line2D([0],[0], marker="o", color=SCHEME_COLOR[args.scheme_a],
                                 ls="none", markersize=8,
                                 label=f"{args.scheme_a}"),
        matplotlib.lines.Line2D([0],[0], marker="o", color=SCHEME_COLOR[args.scheme_b],
                                 ls="none", markersize=8,
                                 label=f"{args.scheme_b}"),
        # components
        matplotlib.lines.Line2D([0],[0], marker="o",  color="gray",
                                 ls="none", markersize=8, label="● K cache"),
        matplotlib.lines.Line2D([0],[0], marker="^",  color="gray",
                                 ls="none", markersize=8, label="▲ V cache"),
        matplotlib.lines.Line2D([0],[0], marker="s",  color="gray",
                                 ls="none", markersize=8, label="■ T output"),
        # size
        matplotlib.lines.Line2D([0],[0], marker="o", color="gray",
                                 ls="none", markersize=4,
                                 label=f"size ∝ log(S)  [{S_MIN}–{S_MAX}]"),
    ]
    ax.legend(handles=legend_handles, fontsize=8,
              loc="upper left", bbox_to_anchor=(0.0, 0.92))

    plt.tight_layout()
    out_png = str(pathlib.Path(args.outdir) / f"{mode}_compare6d_B{n}.png")
    fig.savefig(out_png, dpi=150, bbox_inches="tight")
    print(f"  → {out_png}")
    if args.show:
        plt.show()
    plt.close(fig)

# ── D_2 curve: budget-independent quality profile ─────────────────────────────
budgets = sorted(args.budget)

def _d2_profile(scheme):
    vals = []
    for b in budgets:
        rows = df_raw[(df_raw["budget"] == b) & (df_raw["scheme"] == scheme)]
        vals.append(rows["d_2"].median() if not rows.empty else np.nan)
    return np.array(vals)

d2_a_vec = _d2_profile(args.scheme_a)
d2_b_vec = _d2_profile(args.scheme_b)
D2_dist  = np.linalg.norm(d2_a_vec - d2_b_vec)

print(f"\n── D_2 profile  ({args.scheme_a} vs {args.scheme_b}) ──────────────────")
print(f"  {'b':>3}  {args.scheme_a:>24}  {args.scheme_b:>24}   delta")
for b, va, vb in zip(budgets, d2_a_vec, d2_b_vec):
    delta = va - vb
    winner = "<" if delta < 0 else ">" if delta > 0 else "="
    print(f"  {b:>3}  {va:>24.4f}  {vb:>24.4f}   {delta:+.4f} {winner}")
print(f"  ||D_2(A) − D_2(B)|| = {D2_dist:.4f}")

# plot D_2 curves
fig2, ax2 = plt.subplots(figsize=(8, 5))
ax2.plot(budgets, d2_a_vec, "o-", color="#D65F5F", lw=2, label=args.scheme_a)
ax2.plot(budgets, d2_b_vec, "s--", color="#4DAF4A", lw=2, label=args.scheme_b)
ax2.set_xlabel("budget (bits per cache)", fontsize=11)
ax2.set_ylabel(r"$d_2$ = $\sqrt{AS^2 + NF^2}$  (lower = better)", fontsize=11)
ax2.set_title(
    f"D_2 quality profile — {mode}\n"
    f"{args.scheme_a} vs {args.scheme_b}\n"
    f"AS = 1−cosine   NF = relMSE/(1+relMSE)   ||D_2(A)−D_2(B)|| = {D2_dist:.4f}",
    fontsize=9)
ax2.set_xticks(budgets)
ax2.set_ylim(0, min(1.5, max(np.nanmax(d2_a_vec), np.nanmax(d2_b_vec)) * 1.15))
ax2.grid(True, alpha=0.3)
ax2.legend(fontsize=10)
plt.tight_layout()
out_d2 = str(pathlib.Path(args.outdir) / f"{mode}_d2_curve.png")
fig2.savefig(out_d2, dpi=150, bbox_inches="tight")
print(f"  → {out_d2}")
if args.show:
    plt.show()
plt.close(fig2)
