# Iso-storage quality comparison
*Source: sq_full_final.csv | all S and Nq*
*Reference: TQ-QKQV at b=3*
*For each SQ scheme: use highest budget b where vram(SQ,b) ≤ vram(reference)*
*d_2 = sqrt(AS^2 + NF^2),  AS = 1-cosine,  NF = relMSE/(1+relMSE)  [budget-independent]*

## 1. Compact comparison (best SQ per regime)

### Iso-storage comparison  (reference: TQ-QKQV at b=3)

| regime | ref vram | ref E | best SQ | b_iso | SQ vram | SQ E | verdict |
|--------|----------|-------|---------|-------|---------|------|---------|
| unit_sphere | 57344B | 1.129 | SQ-waterfill-qjlKV | b=2† | 86016B | 0.986 | **beats** (-0.143) |
| lowrank_aligned | 57344B | 0.946 | SQ-uniform-qjlV | b=7 | 51200B | 0.167 | **beats** (-0.779) |
| lowrank | 57344B | 0.988 | SQ-uniform-qjlKV | b=2† | 61440B | 0.394 | **beats** (-0.594) |
| fattail | 57344B | 0.473 | SQ-uniform-qjlKV | b=2† | 86016B | 0.505 | behind (+0.032) |
| lowrank_steep | 57344B | 0.854 | SQ-uniform-qjlKV | b=7 | 56320B | 0.670 | **beats** (-0.184) |
| lowrank_misalign | 57344B | 1.052 | SQ-uniform-qjlKV | b=7 | 57344B | 0.409 | **beats** (-0.642) |

† SQ exceeds reference storage even at minimum budget (b=2).
verdict delta tolerance = 0.014
d_2 = sqrt(AS^2 + NF^2),  AS = 1-cosine,  NF = relMSE/(1+relMSE).

## 2. All SQ schemes at iso-storage

### unit_sphere  —  reference: TQ-QKQV b=3  vram=57344B  d_2=1.129  cosine=0.330  relMSE=9.9950

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=2† | 65536B | 0.246 | 28.7068 | 0.754 | 0.966 | 1.226 | behind (+0.097) |
| SQ-waterfill | b=2† | 65536B | 0.246 | 28.7068 | 0.754 | 0.966 | 1.226 | behind (+0.097) |
| SQ-uniform-qjlK | b=2† | 75776B | 0.243 | 30.1540 | 0.757 | 0.968 | 1.229 | behind (+0.100) |
| SQ-uniform-qjlV | b=2† | 75776B | 0.406 | 4.1113 | 0.594 | 0.804 | 1.000 | **beats** (-0.129) |
| SQ-uniform-qjlKV | b=2† | 86016B | 0.406 | 4.1106 | 0.594 | 0.804 | 1.000 | **beats** (-0.129) |
| SQ-waterfill-qjlK | b=2† | 75776B | 0.246 | 28.7051 | 0.754 | 0.966 | 1.226 | behind (+0.096) |
| SQ-waterfill-qjlV | b=2† | 75776B | 0.418 | 3.9131 | 0.582 | 0.796 | 0.986 | **beats** (-0.143) |
| SQ-waterfill-qjlKV | b=2† | 86016B | 0.418 | 3.9115 | 0.582 | 0.796 | 0.986 | **beats** (-0.143) |

### lowrank_aligned  —  reference: TQ-QKQV b=3  vram=57344B  d_2=0.946  cosine=0.540  relMSE=4.7614

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=7 | 40960B | 0.649 | 1.1780 | 0.351 | 0.541 | 0.645 | **beats** (-0.301) |
| SQ-waterfill | b=7 | 40960B | 0.649 | 1.1780 | 0.351 | 0.541 | 0.645 | **beats** (-0.301) |
| SQ-uniform-qjlK | b=7 | 51200B | 0.666 | 1.2210 | 0.334 | 0.550 | 0.644 | **beats** (-0.302) |
| SQ-uniform-qjlV | b=7 | 51200B | 0.919 | 0.1710 | 0.081 | 0.146 | 0.167 | **beats** (-0.779) |
| SQ-uniform-qjlKV | b=2† | 61440B | 0.851 | 0.2943 | 0.149 | 0.227 | 0.272 | **beats** (-0.674) |
| SQ-waterfill-qjlK | b=7 | 51200B | 0.666 | 1.2210 | 0.334 | 0.550 | 0.644 | **beats** (-0.302) |
| SQ-waterfill-qjlV | b=7 | 51200B | 0.919 | 0.1710 | 0.081 | 0.146 | 0.167 | **beats** (-0.779) |
| SQ-waterfill-qjlKV | b=2† | 61440B | 0.335 | 4.2386 | 0.665 | 0.809 | 1.047 | behind (+0.102) |

### lowrank  —  reference: TQ-QKQV b=3  vram=57344B  d_2=0.988  cosine=0.471  relMSE=5.0486

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=7 | 40960B | 0.498 | 4.1365 | 0.502 | 0.805 | 0.949 | **beats** (-0.039) |
| SQ-waterfill | b=7 | 40960B | 0.498 | 4.1365 | 0.502 | 0.805 | 0.949 | **beats** (-0.039) |
| SQ-uniform-qjlK | b=7 | 51200B | 0.525 | 3.4511 | 0.475 | 0.775 | 0.909 | **beats** (-0.079) |
| SQ-uniform-qjlV | b=7 | 51200B | 0.791 | 0.6017 | 0.209 | 0.376 | 0.430 | **beats** (-0.558) |
| SQ-uniform-qjlKV | b=2† | 61440B | 0.754 | 0.4444 | 0.246 | 0.308 | 0.394 | **beats** (-0.594) |
| SQ-waterfill-qjlK | b=7 | 51200B | 0.525 | 3.4511 | 0.475 | 0.775 | 0.909 | **beats** (-0.079) |
| SQ-waterfill-qjlV | b=7 | 51200B | 0.791 | 0.6017 | 0.209 | 0.376 | 0.430 | **beats** (-0.558) |
| SQ-waterfill-qjlKV | b=2† | 61440B | 0.557 | 2.2855 | 0.443 | 0.696 | 0.825 | **beats** (-0.164) |

### fattail  —  reference: TQ-QKQV b=3  vram=57344B  d_2=0.473  cosine=0.737  relMSE=0.6490

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=2† | 65536B | 0.090 | 4.0562 | 0.910 | 0.802 | 1.213 | behind (+0.740) |
| SQ-waterfill | b=2† | 65536B | 0.090 | 4.0562 | 0.910 | 0.802 | 1.213 | behind (+0.740) |
| SQ-uniform-qjlK | b=2† | 75776B | 0.399 | 1.4967 | 0.601 | 0.599 | 0.849 | behind (+0.375) |
| SQ-uniform-qjlV | b=2† | 75776B | 0.306 | 1.0580 | 0.694 | 0.514 | 0.863 | behind (+0.390) |
| SQ-uniform-qjlKV | b=2† | 86016B | 0.636 | 0.5383 | 0.364 | 0.350 | 0.505 | behind (+0.032) |
| SQ-waterfill-qjlK | b=2† | 75776B | 0.279 | 4.4690 | 0.721 | 0.817 | 1.090 | behind (+0.617) |
| SQ-waterfill-qjlV | b=2† | 75776B | 0.248 | 1.4762 | 0.752 | 0.596 | 0.959 | behind (+0.486) |
| SQ-waterfill-qjlKV | b=2† | 86016B | 0.514 | 1.1618 | 0.486 | 0.537 | 0.724 | behind (+0.251) |

### lowrank_steep  —  reference: TQ-QKQV b=3  vram=57344B  d_2=0.854  cosine=0.496  relMSE=2.2160

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=7 | 35840B | 0.332 | 5.4332 | 0.668 | 0.845 | 1.077 | behind (+0.223) |
| SQ-waterfill | b=7 | 35840B | 0.332 | 5.4143 | 0.668 | 0.844 | 1.077 | behind (+0.223) |
| SQ-uniform-qjlK | b=7 | 46080B | 0.346 | 5.0240 | 0.654 | 0.834 | 1.060 | behind (+0.206) |
| SQ-uniform-qjlV | b=7 | 46080B | 0.512 | 1.0465 | 0.488 | 0.511 | 0.707 | **beats** (-0.147) |
| SQ-uniform-qjlKV | b=7 | 56320B | 0.540 | 0.9473 | 0.460 | 0.486 | 0.670 | **beats** (-0.184) |
| SQ-waterfill-qjlK | b=7 | 46080B | 0.346 | 5.0436 | 0.654 | 0.835 | 1.060 | behind (+0.207) |
| SQ-waterfill-qjlV | b=7 | 46080B | 0.512 | 1.0465 | 0.488 | 0.511 | 0.707 | **beats** (-0.147) |
| SQ-waterfill-qjlKV | b=7 | 56320B | 0.540 | 0.9473 | 0.460 | 0.486 | 0.670 | **beats** (-0.184) |

### lowrank_misalign  —  reference: TQ-QKQV b=3  vram=57344B  d_2=1.052  cosine=0.414  relMSE=6.8926

| scheme | b_iso | vram | cosine | relMSE | AS | NF | d_2 | verdict |
|--------|-------|------|--------|--------|----|----|-----|---------|
| SQ-uniform | b=7 | 36864B | 0.083 | 1.0242 | 0.917 | 0.506 | 1.047 | ties (-0.004) |
| SQ-waterfill | b=7 | 36864B | 0.083 | 1.0242 | 0.917 | 0.506 | 1.047 | ties (-0.004) |
| SQ-uniform-qjlK | b=7 | 47104B | 0.059 | 1.1343 | 0.941 | 0.531 | 1.081 | behind (+0.029) |
| SQ-uniform-qjlV | b=7 | 47104B | 0.705 | 0.4902 | 0.295 | 0.329 | 0.442 | **beats** (-0.609) |
| SQ-uniform-qjlKV | b=7 | 57344B | 0.721 | 0.4279 | 0.279 | 0.300 | 0.409 | **beats** (-0.642) |
| SQ-waterfill-qjlK | b=7 | 47104B | 0.059 | 1.1343 | 0.941 | 0.531 | 1.081 | behind (+0.029) |
| SQ-waterfill-qjlV | b=7 | 47104B | 0.705 | 0.4902 | 0.295 | 0.329 | 0.442 | **beats** (-0.609) |
| SQ-waterfill-qjlKV | b=7 | 57344B | 0.721 | 0.4279 | 0.279 | 0.300 | 0.409 | **beats** (-0.642) |
