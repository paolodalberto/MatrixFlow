"""
d2_stratified_S.py  —  D_2 profiles stratified by sequence length S
=====================================================================
For each S value in the CSV, plots median d_2 vs budget as a separate line.
Reveals whether the non-monotone bump is driven by short or long sequences.

Usage:
    python d2_stratified_S.py sq_full_final.csv --out d2_by_S.png
    python d2_stratified_S.py sq_d64.csv --out d2_by_S_d64.png
"""

import argparse
import pathlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.cm as cm

ap = argparse.ArgumentParser()
ap.add_argument("csv")
ap.add_argument("--out", default="d2_by_S.png")
ap.add_argument("--dpi", type=int, default=180)
args = ap.parse_args()

# ── load ──────────────────────────────────────────────────────────────────────
df = pd.read_csv(args.csv)
df.columns = [c.strip() for c in df.columns]
df["AS"]  = 1.0 - df["cosine"]
df["NF"]  = df["relMSE"] / (1.0 + df["relMSE"])
df["d_2"] = np.sqrt(df["AS"]**2 + df["NF"]**2)

budgets  = sorted(df["budget"].unique())
S_values = sorted(df["S"].unique())

# ── panels: (regime, scheme) pairs that show a bump ──────────────────────────
PANELS = [
    ("unit_sphere", "TQ-QKQV",          "unit\_sphere — TQ-QKQV  (Lloyd-Max floor bump)"),
    ("lowrank",     "SQ-uniform",        "lowrank — SQ-uniform  (attention sharpening bump)"),
    ("lowrank",     "TQ-QKQV",           "lowrank — TQ-QKQV  (reference: monotone?)"),
    ("lowrank",     "SQ-uniform-qjlKV",  "lowrank — SQ-QKQV  (QJL corrected)"),
]

# ── colour map: one colour per S, light→dark as S grows ──────────────────────
cmap   = cm.get_cmap("plasma", len(S_values) + 2)
colors = {s: cmap(i + 1) for i, s in enumerate(S_values)}

# ── figure ────────────────────────────────────────────────────────────────────
nrows = len(PANELS)
fig, axes = plt.subplots(nrows, 1, figsize=(7, 3.2 * nrows + 0.5),
                         sharex=True, squeeze=False)
axes = [ax[0] for ax in axes]
fig.subplots_adjust(hspace=0.55)

for ax, (regime, scheme, title) in zip(axes, PANELS):
    sub = df[(df["regime"] == regime) & (df["scheme"] == scheme)]
    if sub.empty:
        ax.set_title(f"{title}  [NO DATA]", fontsize=9)
        continue

    for s in S_values:
        rows = sub[sub["S"] == s]
        if rows.empty:
            continue
        medians = [rows[rows["budget"] == b]["d_2"].median() for b in budgets]
        ax.plot(budgets, medians,
                color=colors[s], marker="o", markersize=5,
                lw=1.8, label=f"S={s}")

    ax.set_title(title.replace("\_", "_"), fontsize=10, fontweight="bold", pad=3)
    ax.set_ylabel(r"$d_2$", fontsize=10)
    ax.set_ylim(0, None)
    ax.set_xticks(budgets)
    ax.grid(True, alpha=0.28, lw=0.7)
    ax.spines[["top", "right"]].set_visible(False)
    ax.axhline(np.sqrt(2), color="lightgray", lw=0.8, ls="--", zorder=0)

# ── shared legend on first panel ──────────────────────────────────────────────
axes[0].legend(title="seq len S", fontsize=8, title_fontsize=8,
               loc="upper right", ncol=2,
               frameon=True, framealpha=0.92, edgecolor="lightgray")

axes[-1].set_xlabel("bit budget  $b$", fontsize=11)

# ── title with CSV name ───────────────────────────────────────────────────────
fig.suptitle(f"D₂ profiles stratified by sequence length S\n"
             f"source: {pathlib.Path(args.csv).name}",
             fontsize=10, y=1.002)

out = pathlib.Path(args.out)
out.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(out, dpi=args.dpi, bbox_inches="tight")
print(f"Saved → {out}")
plt.close(fig)
