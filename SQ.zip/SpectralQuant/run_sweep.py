"""
run_sweep.py — comprehensive CPU sweep over all regimes, token counts, and budgets
===================================================================================

Sweeps:
  regimes   : all defined in turbo_proto.REGIMES
  budgets   : 2 3 4 5  (bits/dim nominal)
  n_tokens  : 1024  4096  16384
  n_queries : 64  256

Per row in output CSV:
  quality   : ptrelMSE_K/V, ptcosine_K/V, kl_sm, relMSE, cosine (T)
  bits      : total_bits_K, total_bits_V  (actual bits per vector)
  timing    : t_calib_ms, t_enc_K_ms, t_enc_V_ms, t_attn_ms  (wall-clock ms)
  throughput: tok_per_s_K, tok_per_s_V  (tokens/second for encode)

Usage
-----
    python run_sweep.py                              # full sweep (~hours)
    python run_sweep.py --regime random lowrank_aligned --n_tokens 1024 4096
    python run_sweep.py --budget 2 3 --quiet
    python run_sweep.py --timing_reps 3              # repeat timing runs
"""

from __future__ import annotations
import argparse
import os
import sys
import time

import numpy as np
import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
sys.path.insert(0, os.path.join(_HERE, "pquant_6d"))

from turbo_proto import (
    TurboQuantCodec, solve_lloyd_max_beta, REGIMES, _CODEBOOK_CACHE,
)
from spectralquant_proto import (
    calibrate, run_experiment as _sq_run,
    cosine_sim, rel_mse, attention_output, kl_softmax,
    beta_diagnostic, SpectralQuantCodec, water_fill, water_fill_uniform,
)
from snr_metrics_6d import add_snr_err

D_H    = 128
B_TAIL = 2
RNG_SEED = 42


# ── timing helper ──────────────────────────────────────────────────────────────

def _timed(fn, reps=1):
    """Run fn() `reps` times; return (result_of_last_call, mean_wall_ms)."""
    result = None
    t0 = time.perf_counter()
    for _ in range(reps):
        result = fn()
    elapsed = (time.perf_counter() - t0) / reps * 1000.0   # ms
    return result, elapsed


# ── TurboQuant sweep ───────────────────────────────────────────────────────────

def _tq_schemes(b):
    return [
        ("Plain-KV", b,     b,     False, False, False),
        ("TQ-KV",    b,     b,     False, False, True),
        ("TQ-QKV",   b - 1, b,     True,  False, True),
        ("TQ-KQV",   b,     b - 1, False, True,  True),
        ("TQ-QKQV",  b - 1, b - 1, True,  True,  True),
    ]


def run_tq_sweep(K, V, Q, K_cal, budgets, timing_reps, verbose):
    d_h = K.shape[1]
    n_tokens = K.shape[0]
    n_queries = Q.shape[0]
    rows = []

    for b in budgets:
        shared_seed = int(
            np.random.default_rng(RNG_SEED + b * 997).integers(1 << 31)
        )

        # pre-solve codebooks (cached globally)
        for n_bits in {b, b - 1} - {0}:
            solve_lloyd_max_beta(d_h, n_bits)

        for scheme_name, b_mse_K, b_mse_V, use_qjl_K, use_qjl_V, use_wht in _tq_schemes(b):
            if b_mse_K < 1 or b_mse_V < 1:
                continue

            codec = TurboQuantCodec(
                d_h, b_mse_K, b_mse_V,
                use_qjl_K=use_qjl_K, use_qjl_V=use_qjl_V,
                use_wht=use_wht,
                rng=np.random.default_rng(shared_seed),
            )
            codec.centroids_K, codec.boundaries_K = _CODEBOOK_CACHE[(d_h, b_mse_K)]
            codec.centroids_V, codec.boundaries_V = _CODEBOOK_CACHE[(d_h, b_mse_V)]

            K_hat, t_enc_K = _timed(
                lambda: codec.encode_decode(K, is_key=True)[0], reps=timing_reps
            )
            V_hat, t_enc_V = _timed(
                lambda: codec.encode_decode(V, is_key=False)[0], reps=timing_reps
            )
            T_ref = attention_output(Q, K,     V,     d_h)
            T_hat, t_attn = _timed(
                lambda: attention_output(Q, K_hat, V_hat, d_h), reps=timing_reps
            )

            n_bits_K = float(b_mse_K + int(use_qjl_K))
            n_bits_V = float(b_mse_V + int(use_qjl_V))

            row = dict(
                framework      = "TurboQuant",
                scheme         = scheme_name,
                budget         = b,
                n_tokens       = n_tokens,
                n_queries      = n_queries,
                n_bits_K       = n_bits_K,
                n_bits_V       = n_bits_V,
                total_bits_K   = n_bits_K * d_h,
                total_bits_V   = n_bits_V * d_h,
                has_qjl_K      = int(use_qjl_K),
                has_qjl_V      = int(use_qjl_V),
                t_calib_ms     = 0.0,           # TQ: codebook is offline/cached
                t_enc_K_ms     = t_enc_K,
                t_enc_V_ms     = t_enc_V,
                t_attn_ms      = t_attn,
                tok_per_s_K    = n_tokens / (t_enc_K / 1000.0),
                tok_per_s_V    = n_tokens / (t_enc_V / 1000.0),
                relMSE         = rel_mse(T_ref, T_hat),
                cosine         = cosine_sim(T_ref, T_hat),
                ptrelMSE_K     = rel_mse(K, K_hat),
                ptrelMSE_V     = rel_mse(V, V_hat),
                ptcosine_K     = cosine_sim(K, K_hat),
                ptcosine_V     = cosine_sim(V, V_hat),
                kl_sm          = kl_softmax(Q, K, K_hat, d_h),
            )
            rows.append(row)

            if verbose:
                print(f"  {scheme_name:<14} b={b}  "
                      f"K={t_enc_K:.1f}ms  V={t_enc_V:.1f}ms  "
                      f"attn={t_attn:.1f}ms  "
                      f"T-relMSE={row['relMSE']:.4f}")

    return pd.DataFrame(rows)


# ── SpectralQuant sweep ────────────────────────────────────────────────────────

def run_sq_sweep(K, V, Q, K_cal, budgets, timing_reps, verbose):
    """
    Wraps spectralquant_proto.run_experiment and adds timing columns.
    Calibration cost is measured once (shared across budgets/schemes).
    Encode timing is approximated from total experiment wall-time.
    """
    d_h    = K.shape[1]
    n_tokens = K.shape[0]
    n_queries = Q.shape[0]

    # Calibration timing
    _, t_calib = _timed(lambda: calibrate(K_cal), reps=timing_reps)
    calib = calibrate(K_cal)
    d_eff = calib["d_eff"]

    # Run full SQ experiment (quality only — internal timing would need refactor)
    df = _sq_run(K, V, Q, K_cal, budgets=budgets, b_tail=B_TAIL, verbose=verbose)

    # Time a representative encode (waterfill at median budget)
    b_mid = budgets[len(budgets) // 2]
    wf_mid = water_fill(calib["sig_eff"], b_mid * d_eff, min_bits=B_TAIL)
    codec_ref = SpectralQuantCodec(
        calib, wf_mid, b_tail=B_TAIL,
        rng=np.random.default_rng(RNG_SEED),
    )
    codec_ref.fit_codebooks(K_cal)
    _, t_enc_K_ref = _timed(
        lambda: codec_ref.encode_decode(K, is_key=True), reps=timing_reps
    )
    _, t_enc_V_ref = _timed(
        lambda: codec_ref.encode_decode(V, is_key=False), reps=timing_reps
    )

    T_ref = attention_output(Q, K, V, d_h)
    _, t_attn_ref = _timed(
        lambda: attention_output(Q, K, V, d_h), reps=timing_reps
    )

    df["framework"]    = "SpectralQuant"
    df["n_tokens"]     = n_tokens
    df["n_queries"]    = n_queries
    df["t_calib_ms"]   = t_calib
    df["t_enc_K_ms"]   = t_enc_K_ref      # approximate (same for all schemes)
    df["t_enc_V_ms"]   = t_enc_V_ref
    df["t_attn_ms"]    = t_attn_ref
    df["tok_per_s_K"]  = n_tokens / (t_enc_K_ref / 1000.0)
    df["tok_per_s_V"]  = n_tokens / (t_enc_V_ref / 1000.0)
    df["total_bits_K"] = df["n_bits_K"] * d_eff + B_TAIL * (d_h - d_eff)
    df["total_bits_V"] = df["n_bits_V"] * d_eff + B_TAIL * (d_h - d_eff)

    return df


# ── per-regime runner ──────────────────────────────────────────────────────────

def run_regime(name, fn, budgets, n_tokens, n_queries, n_cal, seed,
               timing_reps, verbose):
    print(f"\n{'='*68}")
    print(f"Regime: {name}  n_tokens={n_tokens}  n_queries={n_queries}")
    print(f"{'='*68}")

    K, V, Q_full, K_cal = fn(n_tokens, D_H, n_cal, seed)

    # Subsample queries to n_queries
    rng = np.random.default_rng(seed + 1)
    if Q_full.shape[0] >= n_queries:
        idx = rng.choice(Q_full.shape[0], n_queries, replace=False)
        Q = Q_full[idx]
    else:
        Q = Q_full

    calib = calibrate(K_cal)
    diag  = beta_diagnostic(K_cal, calib)
    print(f"  d_eff={calib['d_eff']}  "
          f"BetaKS={diag['ks_stat']:.3f}  KL={diag['kl_div']:.4f}")

    print("\n[TurboQuant]")
    df_tq = run_tq_sweep(K, V, Q, K_cal, budgets, timing_reps, verbose)
    df_tq["regime"] = name
    df_tq["d_eff"]  = calib["d_eff"]

    print("\n[SpectralQuant]")
    df_sq = run_sq_sweep(K, V, Q, K_cal, budgets, timing_reps, verbose)
    df_sq["regime"] = name
    df_sq["d_eff"]  = calib["d_eff"]

    return pd.concat([df_tq, df_sq], ignore_index=True)


# ── main ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Full TQ vs SQ sweep with timing")
    parser.add_argument("--regime",       nargs="+", default=list(REGIMES.keys()),
                        choices=list(REGIMES.keys()))
    parser.add_argument("--budget",       type=int,   nargs="+", default=[2, 3, 4, 5])
    parser.add_argument("--n_tokens",     type=int,   nargs="+", default=[1024, 4096, 16384])
    parser.add_argument("--n_queries",    type=int,   nargs="+", default=[64, 256])
    parser.add_argument("--n_cal",        type=int,   default=512)
    parser.add_argument("--seed",         type=int,   default=42)
    parser.add_argument("--timing_reps",  type=int,   default=3,
                        help="Repeat encode/decode this many times and average for timing")
    parser.add_argument("--out_dir",      default="sweep_results")
    parser.add_argument("--quiet",        action="store_true")
    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    all_dfs = []

    for name in args.regime:
        fn = REGIMES[name]
        for n_tok in args.n_tokens:
            for n_q in args.n_queries:
                df = run_regime(
                    name, fn,
                    budgets    = args.budget,
                    n_tokens   = n_tok,
                    n_queries  = n_q,
                    n_cal      = args.n_cal,
                    seed       = args.seed,
                    timing_reps= args.timing_reps,
                    verbose    = not args.quiet,
                )
                all_dfs.append(df)

    all_df = pd.concat(all_dfs, ignore_index=True)

    # add 1-cos columns
    all_df["dirT"] = 1 - all_df["cosine"]
    all_df["dirK"] = 1 - all_df["ptcosine_K"]
    all_df["dirV"] = 1 - all_df["ptcosine_V"]

    out = os.path.join(args.out_dir, "sweep_all.csv")
    all_df.to_csv(out, index=False)
    print(f"\nSaved: {out}  ({len(all_df)} rows)")

    # Quick summary table
    key_schemes = ["TQ-KV", "TQ-KQV", "SQ-uniform", "SQ-waterfill", "SQ-wf-qjl-V"]
    sub = all_df[all_df["scheme"].isin(key_schemes)]
    g = sub.groupby(["regime", "framework", "scheme", "budget", "n_tokens"])
    print("\n=== T 1-cos  (lower is better) ===")
    print(g["dirT"].mean().unstack(["budget", "n_tokens"]).to_string())


if __name__ == "__main__":
    main()
