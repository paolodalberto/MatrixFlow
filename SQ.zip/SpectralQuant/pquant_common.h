/*
 * pquant_common.h — shared CPU helpers for TurboQuant + SpectralQuant sweep
 * ===========================================================================
 *
 * Extracted from pquant_hip_metrics.hip and extended with:
 *   - kl_softmax_cpu        : SM KL divergence on K path only
 *   - topk_overlap_cpu      : top-5 recall between reference and quantized softmax
 *   - participation_ratio   : d_eff = (Σλ)² / Σλ² from eigenvalues
 *   - water_fill            : greedy integer bit allocation across d_eff dimensions
 *   - lloyd_max_1d_empirical: empirical Lloyd-Max for SQ per-dim codebooks
 *
 * Include once from sweep_hip.hip.
 * Requires: <vector>, <cmath>, <algorithm>, <numeric>, <cstring>, <cstdio>
 */
#pragma once

#include <vector>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <numeric>
#include <cassert>

static constexpr int D           = 128;
static constexpr int QJL_BYTES   = D / 8;   // 16 bytes per token for 1-bit QJL

// ═══════════════════════════════════════════════════════════════════════════
//  WHT + Lloyd-Max (TurboQuant)
// ═══════════════════════════════════════════════════════════════════════════

static void wht_rows_cpu(float* A, int N, int d) {
    for (int row = 0; row < N; ++row) {
        float* x = A + row * d;
        for (int h = 1; h < d; h <<= 1)
            for (int i = 0; i < d; i += h * 2)
                for (int j = i; j < i + h; ++j) {
                    float u = x[j], v = x[j + h];
                    x[j] = u + v; x[j + h] = u - v;
                }
        float inv = 1.f / sqrtf((float)d);
        for (int i = 0; i < d; ++i) x[i] *= inv;
    }
}

/* Analytical Beta Lloyd-Max codebook — 500 iterations, numerical integration.
 * PDF and centroid integrals use double precision to avoid float32 underflow
 * at large d (e.g. d=256: a=127.5, ((1±t)/2)^126.5 underflows in float32).
 * Final bnd/lvl are stored as float32 for GPU decode. */
static void solve_lloyd_max(int d, int n_bits,
                             std::vector<float>& bnd,
                             std::vector<float>& lvl) {
    const int    K  = 1 << n_bits;
    const double a  = (d - 1) / 2.0;
    const int    NI = 4000;
    const double dt = 2.0 / NI;

    auto beta_pdf = [&](double t) -> double {
        if (t <= -1.0 || t >= 1.0) return 0.0;
        return pow((1.0 + t) * .5, a - 1.0) * pow((1.0 - t) * .5, a - 1.0);
    };
    double Z = 0;
    for (int i = 0; i < NI; ++i) Z += beta_pdf(-1.0 + (i + .5) * dt) * dt;
    auto pdf = [&](double t) { return beta_pdf(t) / Z; };

    // working vectors in double; downcast to float at the end
    std::vector<double> dlvl(K), dbnd(K + 1);
    for (int k = 0; k < K; ++k) dlvl[k] = -1.0 + (2.0 * k + 1.0) / K;

    for (int iter = 0; iter < 500; ++iter) {
        dbnd[0] = -1.0; dbnd[K] = 1.0;
        for (int k = 1; k < K; ++k) dbnd[k] = (dlvl[k - 1] + dlvl[k]) * .5;
        std::vector<double> nl(K); double maxd = 0;
        for (int k = 0; k < K; ++k) {
            double lo = dbnd[k], hi = dbnd[k + 1];
            int M = std::max(2, (int)((hi - lo) / dt * 2));
            double dtt = (hi - lo) / M, num = 0, den = 0;
            for (int i = 0; i < M; ++i) {
                double t = lo + (i + .5) * dtt, p = pdf(t);
                num += t * p * dtt; den += p * dtt;
            }
            nl[k] = (den < 1e-24) ? (lo + hi) * .5 : num / den;
            maxd = std::max(maxd, fabs(nl[k] - dlvl[k]));
        }
        dlvl = nl;
        if (maxd < 1e-12) break;
    }
    dbnd[0] = -1.0; dbnd[K] = 1.0;
    for (int k = 1; k < K; ++k) dbnd[k] = (dlvl[k - 1] + dlvl[k]) * .5;

    // downcast to float32 for GPU upload
    lvl.resize(K); bnd.resize(K + 1);
    for (int k = 0; k < K;     ++k) lvl[k] = (float)dlvl[k];
    for (int k = 0; k <= K;    ++k) bnd[k] = (float)dbnd[k];
}

static int quantise_scalar(float x, const std::vector<float>& bnd) {
    int K = (int)bnd.size() - 1;
    if (x <= bnd[1])     return 0;
    if (x >= bnd[K - 1]) return K - 1;
    int lo = 0, hi = K - 1;
    while (lo < hi) {
        int m = (lo + hi) / 2;
        if (x < bnd[m + 1]) hi = m; else lo = m + 1;
    }
    return lo;
}

// ═══════════════════════════════════════════════════════════════════════════
//  Encoding structs
// ═══════════════════════════════════════════════════════════════════════════

struct EncodedMSE {
    std::vector<float> norms;
    std::vector<int>   idx;
};

struct EncodedQJL {
    std::vector<float> norms, r_norms;
    std::vector<float> qjl_bits;
    std::vector<int>   idx;
};

// ─── TurboQuant encoders ────────────────────────────────────────────────────

static EncodedMSE encode_mse(const std::vector<float>& M, int N,
                              const std::vector<float>& s,
                              const std::vector<float>& bnd,
                              const std::vector<float>& lvl) {
    EncodedMSE enc; enc.norms.resize(N); enc.idx.resize(N * D);
    std::vector<float> tmp(D);
    for (int i = 0; i < N; ++i) {
        float n2 = 0;
        for (int j = 0; j < D; ++j) n2 += M[i*D+j] * M[i*D+j];
        float norm = sqrtf(n2); enc.norms[i] = norm;
        for (int j = 0; j < D; ++j) tmp[j] = (M[i*D+j] / norm) * s[j];
        wht_rows_cpu(tmp.data(), 1, D);
        for (int j = 0; j < D; ++j) enc.idx[i*D+j] = quantise_scalar(tmp[j], bnd);
    }
    return enc;
}

static EncodedQJL encode_mse_qjl(const std::vector<float>& M, int N,
                                   const std::vector<float>& s,
                                   const std::vector<float>& S2,
                                   const std::vector<float>& bnd,
                                   const std::vector<float>& lvl) {
    EncodedQJL enc;
    enc.norms.resize(N); enc.idx.resize(N * D);
    enc.r_norms.resize(N); enc.qjl_bits.resize(N * D);
    std::vector<float> tmp(D), res(D);
    for (int i = 0; i < N; ++i) {
        float n2 = 0;
        for (int j = 0; j < D; ++j) n2 += M[i*D+j] * M[i*D+j];
        float norm = sqrtf(n2); enc.norms[i] = norm;
        for (int j = 0; j < D; ++j) tmp[j] = (M[i*D+j] / norm) * s[j];
        wht_rows_cpu(tmp.data(), 1, D);
        for (int j = 0; j < D; ++j) enc.idx[i*D+j] = quantise_scalar(tmp[j], bnd);
        float rn2 = 0;
        for (int j = 0; j < D; ++j) {
            float r = tmp[j] - lvl[enc.idx[i*D+j]];
            rn2 += r * r;
            res[j] = r * S2[j];
        }
        enc.r_norms[i] = sqrtf(rn2);
        wht_rows_cpu(res.data(), 1, D);
        for (int j = 0; j < D; ++j)
            enc.qjl_bits[i*D+j] = (res[j] >= 0.f) ? 1.f : -1.f;
    }
    return enc;
}

/* Plain scalar MSE — no WHT (Plain-KV baseline) */
static EncodedMSE encode_plain(const std::vector<float>& M, int N,
                                const std::vector<float>& bnd,
                                const std::vector<float>& lvl) {
    EncodedMSE enc; enc.norms.resize(N); enc.idx.resize(N * D);
    for (int i = 0; i < N; ++i) {
        float n2 = 0;
        for (int j = 0; j < D; ++j) n2 += M[i*D+j] * M[i*D+j];
        float norm = sqrtf(n2) + 1e-30f; enc.norms[i] = norm;
        for (int j = 0; j < D; ++j)
            enc.idx[i*D+j] = quantise_scalar(M[i*D+j] / norm, bnd);
    }
    return enc;
}

// ─── TurboQuant decoders ────────────────────────────────────────────────────

static std::vector<float> dequant_mse(const EncodedMSE& enc,
                                       const std::vector<float>& s,
                                       const std::vector<float>& lvl, int N) {
    std::vector<float> out(N * D);
    std::vector<float> tmp(D);
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < D; ++j) tmp[j] = lvl[enc.idx[i*D+j]];
        wht_rows_cpu(tmp.data(), 1, D);
        for (int j = 0; j < D; ++j) out[i*D+j] = enc.norms[i] * tmp[j] * s[j];
    }
    return out;
}

static std::vector<float> dequant_mse_qjl(const EncodedQJL& enc,
                                            const std::vector<float>& s,
                                            const std::vector<float>& S2,
                                            const std::vector<float>& lvl, int N) {
    std::vector<float> out(N * D);
    std::vector<float> x(D), r(D);
    const float scale = sqrtf(3.14159265f / 2.f) / sqrtf((float)D);  // sqrt(pi/2) / sqrt(d)
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < D; ++j) x[j] = lvl[enc.idx[i*D+j]];
        for (int j = 0; j < D; ++j) r[j] = enc.qjl_bits[i*D+j];
        wht_rows_cpu(r.data(), 1, D);
        for (int j = 0; j < D; ++j)
            x[j] += scale * enc.r_norms[i] * S2[j] * r[j];
        wht_rows_cpu(x.data(), 1, D);
        for (int j = 0; j < D; ++j) out[i*D+j] = enc.norms[i] * x[j] * s[j];
    }
    return out;
}

static std::vector<float> dequant_plain(const EncodedMSE& enc,
                                         const std::vector<float>& lvl, int N) {
    std::vector<float> out(N * D);
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < D; ++j)
            out[i*D+j] = enc.norms[i] * lvl[enc.idx[i*D+j]];
    return out;
}

// ═══════════════════════════════════════════════════════════════════════════
//  SpectralQuant CPU helpers
// ═══════════════════════════════════════════════════════════════════════════

/*
 * Participation ratio: d_eff = (Σλ)² / Σλ²
 * λ = eigenvalues (non-negative, any order)
 */
static int participation_ratio(const std::vector<float>& eigvals) {
    double sum1 = 0, sum2 = 0;
    for (float v : eigvals) {
        double d = (double)v;
        sum1 += d; sum2 += d * d;
    }
    if (sum2 < 1e-30) return 1;
    int d_eff = (int)std::round(sum1 * sum1 / sum2);
    return std::max(1, std::min(d_eff, (int)eigvals.size()));
}

/*
 * Participation ratio from the D×D sample covariance matrix C directly.
 *   PR = trace(C)² / ||C||_F²  = (Σ λᵢ)² / (Σ λᵢ²)
 * Both numerator and denominator are computable from C without eigendecomposition:
 *   trace(C) = Σ C[j,j]
 *   ||C||_F² = Σ_{jk} C[j,k]²
 * For a rank-r signal with no noise the zero eigenvalues don't contribute,
 * so PR ≈ r (or more precisely, (Σ_{i≤r} λᵢ)² / Σ_{i≤r} λᵢ²).
 * This avoids Jacobi, which distributes float32 numerical error into phantom
 * small-but-non-zero diagonal entries that inflate PR dramatically.
 */
static int covariance_d_eff(const std::vector<float>& C, int D) {
    double tr = 0.0, frob2 = 0.0;
    for (int j = 0; j < D; ++j) {
        tr += C[j*D+j];
        for (int k = 0; k < D; ++k)
            frob2 += (double)C[j*D+k] * C[j*D+k];
    }
    if (frob2 < 1e-30) return 1;
    int pr = (int)std::round(tr * tr / frob2);
    return std::max(1, std::min(pr, D));
}

/*
 * Greedy water-filling with integer bits.
 * Allocates `total_bits` integer bits across `n` bins with variance `var[i]`.
 * Each bin gets at least `min_bits`. Returns per-bin bit count.
 *
 * Algorithm: start at min_bits everywhere; greedily assign one extra bit
 * to the bin that gives the largest proportional MSE reduction (≈ halving
 * distortion each bit for Gaussian, proxy here: highest var * 4^{-b}).
 */
static std::vector<int> water_fill(const std::vector<float>& var, int total_bits,
                                    int min_bits = 2) {
    int n = (int)var.size();
    std::vector<int> bits(n, min_bits);
    int remaining = total_bits - min_bits * n;
    // proxy distortion for bin i at b bits: var[i] * 4^{-b}
    auto distortion = [&](int i) {
        return (double)var[i] * std::pow(4.0, -(double)bits[i]);
    };
    for (int step = 0; step < remaining && step < 1000000; ++step) {
        int best = 0;
        double best_d = distortion(0);
        for (int i = 1; i < n; ++i) {
            double d = distortion(i);
            if (d > best_d) { best_d = d; best = i; }
        }
        bits[best]++;
    }
    return bits;
}

/*
 * Empirical Lloyd-Max codebook for a single scalar dimension.
 * samples: calibration projections onto this eigenvector (length n_cal).
 * n_bits:  bits for this dimension.
 * Returns pair {boundaries (K+1), levels (K)}.
 */
static void lloyd_max_1d_empirical(const std::vector<float>& samples, int n_bits,
                                    std::vector<float>& bnd,
                                    std::vector<float>& lvl,
                                    int max_iter = 50) {
    int K = 1 << n_bits;
    int n = (int)samples.size();
    // init levels: K quantiles
    std::vector<float> sorted = samples;
    std::sort(sorted.begin(), sorted.end());
    lvl.resize(K);
    for (int k = 0; k < K; ++k) {
        int qi = (int)((k + 0.5f) / K * n);
        qi = std::max(0, std::min(qi, n - 1));
        lvl[k] = sorted[qi];
    }
    bnd.resize(K + 1);
    bnd[0] = sorted.front() - 1e-6f;
    bnd[K] = sorted.back()  + 1e-6f;

    for (int iter = 0; iter < max_iter; ++iter) {
        // boundaries = midpoints
        for (int k = 1; k < K; ++k) bnd[k] = (lvl[k-1] + lvl[k]) * 0.5f;
        // centroids from samples
        std::vector<float> sums(K, 0.f);
        std::vector<int>   cnts(K, 0);
        for (float x : samples) {
            // binary search for bin
            int lo = 0, hi = K - 1;
            while (lo < hi) {
                int m = (lo + hi) / 2;
                if (x < bnd[m + 1]) hi = m; else lo = m + 1;
            }
            sums[lo] += x; cnts[lo]++;
        }
        float maxd = 0;
        for (int k = 0; k < K; ++k) {
            float new_lvl = (cnts[k] > 0) ? sums[k] / cnts[k] : lvl[k];
            maxd = std::max(maxd, fabsf(new_lvl - lvl[k]));
            lvl[k] = new_lvl;
        }
        if (maxd < 1e-7f) break;
    }
    bnd[0] = sorted.front() - 1e-6f; bnd[K] = sorted.back() + 1e-6f;
    for (int k = 1; k < K; ++k) bnd[k] = (lvl[k-1] + lvl[k]) * 0.5f;
}

// ═══════════════════════════════════════════════════════════════════════════
//  SpectralQuant calibration result
// ═══════════════════════════════════════════════════════════════════════════

/* Per-dimension codebook for SQ (one entry per semantic dim + tail dims) */
struct SQCodebook {
    int          d_eff;
    int          b_tail;
    // eigenvectors U: d × d_eff (column-major: U[j * d_eff + k] = U_{j,k})
    std::vector<float> U;        // d × d_eff
    std::vector<float> eigvals;  // d_eff eigenvalues (descending)
    // per semantic-dim codebooks
    std::vector<std::vector<float>> bnd_sem; // [d_eff] each size (K+1)
    std::vector<std::vector<float>> lvl_sem; // [d_eff] each size K
    // shared tail codebook (b_tail bits)
    std::vector<float> bnd_tail;
    std::vector<float> lvl_tail;
    // bit allocation per semantic dim
    std::vector<int> bits_sem;   // length d_eff
    // calibration projections retained for reallocation (n_cal × d_eff, row-major)
    std::vector<float> proj_cal;
    int n_cal = 0;
};

/*
 * Thin SVD / covariance eigendecomposition (CPU, Jacobi iteration).
 * Computes top d_eff eigenvectors of K_cal^T K_cal / N.
 *
 * For D=128 and n_cal≤512 this is fast enough on CPU (single call at startup).
 * We use power iteration with Gram-Schmidt for simplicity — sufficient for
 * prototype purposes. For production, call rocsolver_ssyevd.
 *
 * K_cal: n_cal × D row-major
 * d_eff:  number of eigenvectors to extract
 * U_out: D × d_eff column-major output (eigenvectors as columns)
 * λ_out: d_eff eigenvalues (descending)
 */
/*
 * Block power iteration (subspace iteration) for top-d_eff eigenvectors of
 * C = K_cal^T K_cal / n_cal.
 *
 * Replaces sequential deflation, which fails for degenerate eigenspaces
 * (e.g., lowrank_aligned with 8 equal eigenvalues ≈ 1/8). In that case,
 * sequential deflation produces garbage eigenvectors in the noise subspace
 * because each power iteration can converge to the same direction as the
 * previous one before Gram-Schmidt removes it.
 *
 * Block iteration evolves all d_eff columns of Z simultaneously:
 *   Z ← K_cal^T (K_cal Z)   [apply C to each column]
 *   Z ← QR(Z)               [orthonormalize — stabilizes degenerate subspace]
 * After convergence the columns of Z span the top-d_eff eigenspace correctly
 * regardless of eigenvalue multiplicity.
 *
 * Gram-Schmidt QR is used (simple, sufficient for d_eff ≤ 32 and D=128).
 */
static void pca_cpu(const std::vector<float>& K_cal, int n_cal, int d_h,
                    int d_eff,
                    std::vector<float>& U_out, std::vector<float>& lam_out,
                    std::mt19937& rng_ref) {
    U_out.assign(d_h * d_eff, 0.f);
    lam_out.assign(d_eff, 0.f);
    std::normal_distribution<float> gauss(0.f, 1.f);

    // Z: d_h × d_eff, column-major (Z[j + k*d_h] = Z_{j,k})
    std::vector<float> Z(d_h * d_eff);
    for (auto& v : Z) v = gauss(rng_ref);

    // Initial QR to get orthonormal columns
    auto qr_inplace = [&]() {
        for (int k = 0; k < d_eff; ++k) {
            float* zk = Z.data() + k * d_h;
            // orthogonalize column k against previous columns
            for (int p = 0; p < k; ++p) {
                const float* zp = Z.data() + p * d_h;
                float dot = 0.f;
                for (int j = 0; j < d_h; ++j) dot += zk[j] * zp[j];
                for (int j = 0; j < d_h; ++j) zk[j] -= dot * zp[j];
            }
            float n2 = 0.f;
            for (int j = 0; j < d_h; ++j) n2 += zk[j] * zk[j];
            float inv = 1.f / sqrtf(n2 + 1e-30f);
            for (int j = 0; j < d_h; ++j) zk[j] *= inv;
        }
    };
    qr_inplace();

    // Block power iteration: Z ← QR(C Z) for 300 iterations
    std::vector<float> W(n_cal * d_eff);  // W = K_cal Z  (n_cal × d_eff)
    std::vector<float> Z2(d_h * d_eff);  // Z2 = K_cal^T W  (d_h × d_eff)
    for (int iter = 0; iter < 300; ++iter) {
        // W = K_cal * Z  (n_cal × d_eff)
        for (int i = 0; i < n_cal; ++i)
            for (int k = 0; k < d_eff; ++k) {
                float s = 0.f;
                const float* ki = K_cal.data() + i * d_h;
                const float* zk = Z.data() + k * d_h;
                for (int j = 0; j < d_h; ++j) s += ki[j] * zk[j];
                W[i * d_eff + k] = s;
            }
        // Z2 = K_cal^T * W  (d_h × d_eff)
        std::fill(Z2.begin(), Z2.end(), 0.f);
        for (int i = 0; i < n_cal; ++i)
            for (int k = 0; k < d_eff; ++k) {
                float w = W[i * d_eff + k];
                float* z2k = Z2.data() + k * d_h;
                const float* ki = K_cal.data() + i * d_h;
                for (int j = 0; j < d_h; ++j) z2k[j] += ki[j] * w;
            }
        // convergence check before QR (max column-wise angle change)
        float maxd = 0.f;
        for (int k = 0; k < d_eff; ++k) {
            const float* z2k = Z2.data() + k * d_h;
            float n2 = 0.f;
            for (int j = 0; j < d_h; ++j) n2 += z2k[j] * z2k[j];
            float inv = 1.f / sqrtf(n2 + 1e-30f);
            const float* zk = Z.data() + k * d_h;
            float dot = 0.f;
            for (int j = 0; j < d_h; ++j) dot += zk[j] * z2k[j] * inv;
            maxd = std::max(maxd, 1.f - fabsf(dot));
        }
        Z = Z2;
        qr_inplace();
        if (maxd < 1e-6f) break;
    }

    // Extract eigenvalues: λ_k = ||K_cal z_k||² / n_cal
    for (int k = 0; k < d_eff; ++k) {
        const float* zk = Z.data() + k * d_h;
        float lam = 0.f;
        for (int i = 0; i < n_cal; ++i) {
            float s = 0.f;
            const float* ki = K_cal.data() + i * d_h;
            for (int j = 0; j < d_h; ++j) s += ki[j] * zk[j];
            lam += s * s;
        }
        lam_out[k] = lam / n_cal;
        float* up = U_out.data() + k * d_h;
        for (int j = 0; j < d_h; ++j) up[j] = zk[j];
    }

    // Sort by eigenvalue descending (block iteration may not sort automatically
    // when eigenvalues are nearly equal)
    std::vector<int> order(d_eff);
    std::iota(order.begin(), order.end(), 0);
    std::sort(order.begin(), order.end(),
              [&](int a, int b){ return lam_out[a] > lam_out[b]; });
    std::vector<float> U_sorted(d_h * d_eff);
    std::vector<float> lam_sorted(d_eff);
    for (int k = 0; k < d_eff; ++k) {
        lam_sorted[k] = lam_out[order[k]];
        const float* src = U_out.data() + order[k] * d_h;
        float* dst = U_sorted.data() + k * d_h;
        for (int j = 0; j < d_h; ++j) dst[j] = src[j];
    }
    U_out  = U_sorted;
    lam_out = lam_sorted;
}

/*
 * Full SQ calibration:
 *   1. PCA to get d_eff eigenvectors
 *   2. Water-fill bit allocation
 *   3. Per-dim empirical Lloyd-Max codebooks (50 iterations)
 *   4. Tail codebook (b_tail bits, Beta analytical)
 */
static SQCodebook sq_calibrate(const std::vector<float>& K_cal, int n_cal, int d_h,
                                int budget, int b_tail, bool use_waterfill,
                                std::mt19937& rng_ref) {
    SQCodebook cb;
    cb.b_tail = b_tail;

    // PCA
    // Step 1: build full D×D sample covariance C = K_cal^T K_cal / n_cal
    // and compute participation ratio as trace(C)²/||C||_F² — no eigendecomposition
    // needed, avoids Jacobi phantom eigenvalue artefacts in float32.
    std::vector<float> C_cov((size_t)d_h * d_h, 0.f);
    {
        for (int i = 0; i < n_cal; ++i) {
            const float* ki = K_cal.data() + i * d_h;
            for (int j = 0; j < d_h; ++j)
                for (int k = j; k < d_h; ++k)
                    C_cov[j*d_h+k] += ki[j] * ki[k];
        }
        float inv_n = 1.f / n_cal;
        for (int j = 0; j < d_h; ++j) {
            C_cov[j*d_h+j] *= inv_n;
            for (int k = j+1; k < d_h; ++k)
                C_cov[k*d_h+j] = C_cov[j*d_h+k] *= inv_n;
        }
        int pr = covariance_d_eff(C_cov, d_h);
        cb.d_eff = std::max(1, std::min(pr, std::min(n_cal, d_h)));
    }

    // Step 2: block power iteration for top d_eff eigenvectors.
    // Cap at 32 for cost; unit_sphere d_eff=128 is fine as 32 (SQ adds no value there).
    std::vector<float> U_raw, lam_raw;
    int search_k = std::min(cb.d_eff, 32);
    cb.d_eff = search_k;
    pca_cpu(K_cal, n_cal, d_h, search_k, U_raw, lam_raw, rng_ref);
    fprintf(stderr, "[SQ-calib] d_eff=%d (full-spectrum PR)  lam[0]=%.4f lam[1]=%.4f lam[d_eff-1]=%.4f\n",
            cb.d_eff, lam_raw[0], lam_raw.size()>1?lam_raw[1]:0.f,
            lam_raw.size()>=(size_t)cb.d_eff ? lam_raw[cb.d_eff-1] : lam_raw.back());

    // Store top d_eff eigenvectors (column-major: U[j*d_eff + k] = U_{j,k})
    // U_raw is stored as k*d_h + j = U_{j,k} (column k at offset k*d_h)
    cb.U.resize(d_h * cb.d_eff);
    for (int k = 0; k < cb.d_eff; ++k)
        for (int j = 0; j < d_h; ++j)
            cb.U[j * cb.d_eff + k] = U_raw[k * d_h + j];

    cb.eigvals.assign(lam_raw.begin(), lam_raw.begin() + cb.d_eff);

    // Bit allocation
    int total_sem_bits = budget * cb.d_eff;
    if (use_waterfill) {
        cb.bits_sem = water_fill(cb.eigvals, total_sem_bits, b_tail);
    } else {
        cb.bits_sem.assign(cb.d_eff, budget);
    }

    // Project calibration data onto semantic dims and retain for reallocation
    // proj[i, k] = K_cal[i, :] · U[:, k]
    cb.n_cal = n_cal;
    cb.proj_cal.assign(n_cal * cb.d_eff, 0.f);
    for (int i = 0; i < n_cal; ++i)
        for (int k = 0; k < cb.d_eff; ++k)
            for (int j = 0; j < d_h; ++j)
                cb.proj_cal[i * cb.d_eff + k] += K_cal[i*d_h+j] * cb.U[j*cb.d_eff+k];

    // Per-dim Lloyd-Max codebooks
    cb.bnd_sem.resize(cb.d_eff);
    cb.lvl_sem.resize(cb.d_eff);
    for (int k = 0; k < cb.d_eff; ++k) {
        std::vector<float> col(n_cal);
        for (int i = 0; i < n_cal; ++i) col[i] = cb.proj_cal[i * cb.d_eff + k];
        lloyd_max_1d_empirical(col, cb.bits_sem[k], cb.bnd_sem[k], cb.lvl_sem[k]);
    }

    // Tail codebook: empirical Lloyd-Max from actual tail residuals.
    {
        std::vector<float> tail_samples;
        tail_samples.reserve((size_t)n_cal * d_h);
        for (int i = 0; i < n_cal; ++i) {
            for (int j = 0; j < d_h; ++j) {
                float sem = 0.f;
                for (int k = 0; k < cb.d_eff; ++k)
                    sem += cb.proj_cal[i * cb.d_eff + k] * cb.U[j * cb.d_eff + k];
                tail_samples.push_back(K_cal[i*d_h+j] - sem);
            }
        }
        lloyd_max_1d_empirical(tail_samples, b_tail, cb.bnd_tail, cb.lvl_tail);
    }

    return cb;
}

/*
 * Reallocate bits on an existing calibration, reusing eigenvectors and projections.
 * Only bits_sem and per-dim codebooks change; U, eigvals, tail codebook are shared.
 */
static SQCodebook sq_reallocate(const SQCodebook& base, int budget, bool use_waterfill) {
    SQCodebook cb = base;  // copies U, eigvals, proj_cal, tail codebook
    int total_sem_bits = budget * cb.d_eff;
    if (use_waterfill)
        cb.bits_sem = water_fill(cb.eigvals, total_sem_bits, cb.b_tail);
    else
        cb.bits_sem.assign(cb.d_eff, budget);

    cb.bnd_sem.resize(cb.d_eff);
    cb.lvl_sem.resize(cb.d_eff);
    for (int k = 0; k < cb.d_eff; ++k) {
        std::vector<float> col(cb.n_cal);
        for (int i = 0; i < cb.n_cal; ++i) col[i] = cb.proj_cal[i * cb.d_eff + k];
        lloyd_max_1d_empirical(col, cb.bits_sem[k], cb.bnd_sem[k], cb.lvl_sem[k]);
    }
    return cb;
}

// ─── SQ encode / decode ─────────────────────────────────────────────────────

/*
 * Compact GPU encoding for SpectralQuant.
 *
 * sem_pack  : N × d_eff bytes — one uint8 per semantic dim per token
 *             (supports up to 8 bits per semantic dim)
 * tail_pack : N × tail_bpt bytes — b_tail bits per dim, packed via UNPACK_BITS
 *             (same layout as TQ plain packing)
 */
struct SQGpuEncoding {
    std::vector<uint8_t> sem_pack;
    std::vector<uint8_t> tail_pack;
    int tail_bpt = 0;
};

/*
 * Produce the compact GPU encoding for N tokens X (N × d_h row-major).
 * This runs on CPU at token-arrival time (corresponds to encode_mse / encode_plain
 * in the TQ path). The GPU decode kernel reconstructs K_hat/V_hat from this.
 */
static SQGpuEncoding sq_encode_gpu(const std::vector<float>& X, int N,
                                    const SQCodebook& cb, int d_h) {
    int d_eff   = cb.d_eff;
    int b_tail  = cb.b_tail;
    int tail_bpt = (d_h * b_tail + 7) / 8;

    SQGpuEncoding ge;
    ge.sem_pack.resize(N * d_eff);
    ge.tail_pack.resize(N * tail_bpt, 0);
    ge.tail_bpt = tail_bpt;

    for (int i = 0; i < N; ++i) {
        const float* xi = X.data() + i * d_h;

        // Project onto semantic dims
        float proj[32] = {};  // d_eff ≤ 32
        for (int k = 0; k < d_eff; ++k)
            for (int j = 0; j < d_h; ++j)
                proj[k] += xi[j] * cb.U[j * d_eff + k];

        // Quantize semantic dims → one byte each
        float proj_hat[32] = {};
        for (int k = 0; k < d_eff; ++k) {
            int idx = quantise_scalar(proj[k], cb.bnd_sem[k]);
            ge.sem_pack[i * d_eff + k] = (uint8_t)idx;
            proj_hat[k] = cb.lvl_sem[k][idx];
        }

        // Compute tail residual and quantize with b_tail bits
        uint8_t* tp = ge.tail_pack.data() + i * tail_bpt;
        int tail_mask = (1 << b_tail) - 1;
        for (int j = 0; j < d_h; ++j) {
            float sem = 0.f;
            for (int k = 0; k < d_eff; ++k) sem += proj_hat[k] * cb.U[j * d_eff + k];
            float tail_val = xi[j] - sem;
            int idx = quantise_scalar(tail_val, cb.bnd_tail);
            idx &= tail_mask;
            int bit_off = j * b_tail;
            int byte_off = bit_off >> 3, bit_shift = bit_off & 7;
            tp[byte_off] |= (uint8_t)(idx << bit_shift);
            if (bit_shift + b_tail > 8)
                tp[byte_off + 1] |= (uint8_t)(idx >> (8 - bit_shift));
        }
    }
    return ge;
}

/*
 * SpectralQuant encode-decode roundtrip (CPU reference, for per-token metrics).
 * X:   N × d_h row-major input
 * cb:  calibrated codebook
 * Returns X_hat: N × d_h reconstructed
 */
static std::vector<float> sq_roundtrip(const std::vector<float>& X, int N,
                                        const SQCodebook& cb, int d_h) {
    int d_eff = cb.d_eff;
    std::vector<float> out(N * d_h, 0.f);

    for (int i = 0; i < N; ++i) {
        const float* xi = X.data() + i * d_h;

        // Project onto semantic dims
        std::vector<float> proj(d_eff, 0.f);
        for (int k = 0; k < d_eff; ++k)
            for (int j = 0; j < d_h; ++j)
                proj[k] += xi[j] * cb.U[j * d_eff + k];

        // Project onto tail dims (residual in tail subspace)
        // tail_vec = xi - U * proj  (d_h vector)
        std::vector<float> tail(d_h);
        for (int j = 0; j < d_h; ++j) {
            float sem = 0.f;
            for (int k = 0; k < d_eff; ++k) sem += proj[k] * cb.U[j * d_eff + k];
            tail[j] = xi[j] - sem;
        }

        // Quantize semantic dims
        std::vector<float> proj_hat(d_eff);
        for (int k = 0; k < d_eff; ++k) {
            int idx = quantise_scalar(proj[k], cb.bnd_sem[k]);
            proj_hat[k] = cb.lvl_sem[k][idx];
        }

        // Quantize tail with shared empirical b_tail codebook
        std::vector<float> tail_hat(d_h);
        for (int j = 0; j < d_h; ++j) {
            int idx = quantise_scalar(tail[j], cb.bnd_tail);
            tail_hat[j] = cb.lvl_tail[idx];
        }

        // Reconstruct: x_hat = U * proj_hat + tail_hat
        float* oi = out.data() + i * d_h;
        for (int j = 0; j < d_h; ++j) {
            float sem_hat = 0.f;
            for (int k = 0; k < d_eff; ++k) sem_hat += proj_hat[k] * cb.U[j * d_eff + k];
            oi[j] = sem_hat + tail_hat[j];
        }
    }
    return out;
}

// ═══════════════════════════════════════════════════════════════════════════
//  Accuracy metrics (CPU, on float arrays)
// ═══════════════════════════════════════════════════════════════════════════

static float per_token_relmse(const std::vector<float>& orig,
                               const std::vector<float>& hat, int N) {
    float tot = 0.f;
    for (int i = 0; i < N; ++i) {
        float num = 0.f, den = 0.f;
        for (int j = 0; j < D; ++j) {
            float d = orig[i*D+j] - hat[i*D+j];
            num += d * d; den += orig[i*D+j] * orig[i*D+j];
        }
        tot += num / (den + 1e-30f);
    }
    return tot / N;
}

static float cosine_sim_cpu(const float* a, const float* b, int N) {
    double sum = 0;
    for (int i = 0; i < N; ++i) {
        double dot = 0, na = 0, nb = 0;
        for (int j = 0; j < D; ++j) {
            dot += a[i*D+j] * b[i*D+j];
            na  += a[i*D+j] * a[i*D+j];
            nb  += b[i*D+j] * b[i*D+j];
        }
        sum += dot / (sqrt(na) * sqrt(nb) + 1e-30);
    }
    return (float)(sum / N);
}

static float rel_mse_flat(const float* a, const float* b, int n) {
    float num = 0, den = 0;
    for (int i = 0; i < n; ++i) { float d = a[i] - b[i]; num += d*d; den += a[i]*a[i]; }
    return num / (den + 1e-30f);
}

/*
 * KL(softmax(QK^T/√d) || softmax(QK_hat^T/√d)) — K-path metric.
 * Computes attention weights for both K and K_hat on CPU.
 * Q: Nq × d_h, K: N × d_h, K_hat: N × d_h (all row-major)
 */
static float kl_softmax_cpu(const std::vector<float>& Q,
                              const std::vector<float>& K,
                              const std::vector<float>& K_hat,
                              int Nq, int N, int d_h) {
    float inv_sqrt_d = 1.f / sqrtf((float)d_h);
    std::vector<float> W_ref(Nq * N), W_hat(Nq * N);

    // Score matrices
    for (int i = 0; i < Nq; ++i) {
        for (int j = 0; j < N; ++j) {
            float s1 = 0, s2 = 0;
            for (int k = 0; k < d_h; ++k) {
                s1 += Q[i*d_h+k] * K[j*d_h+k];
                s2 += Q[i*d_h+k] * K_hat[j*d_h+k];
            }
            W_ref[i*N+j] = s1 * inv_sqrt_d;
            W_hat[i*N+j] = s2 * inv_sqrt_d;
        }
    }

    // Softmax rows
    auto softmax_rows = [&](std::vector<float>& W, int rows, int cols) {
        for (int i = 0; i < rows; ++i) {
            float mx = *std::max_element(W.begin() + i*cols, W.begin() + (i+1)*cols);
            float sum = 0;
            for (int j = 0; j < cols; ++j) { W[i*cols+j] = expf(W[i*cols+j] - mx); sum += W[i*cols+j]; }
            for (int j = 0; j < cols; ++j) W[i*cols+j] /= sum;
        }
    };
    softmax_rows(W_ref, Nq, N);
    softmax_rows(W_hat, Nq, N);

    // KL divergence
    float kl = 0;
    for (int i = 0; i < Nq; ++i) {
        float row_kl = 0;
        for (int j = 0; j < N; ++j) {
            float p = std::max(W_ref[i*N+j], 1e-12f);
            float q = std::max(W_hat[i*N+j], 1e-12f);
            row_kl += p * logf(p / q);
        }
        kl += row_kl;
    }
    return kl / Nq;
}

/*
 * Top-K recall between reference and quantized softmax distributions.
 * W_ref, W_hat: Nq × N softmax weight matrices (row-major)
 */
static float topk_overlap_cpu(const float* W_ref, const float* W_hat,
                                int Nq, int N, int topk = 5) {
    int k = std::min(topk, N);
    std::vector<int> idx_p(N), idx_q(N);
    double sum = 0.0;
    for (int i = 0; i < Nq; ++i) {
        const float* pi = W_ref + i * N;
        const float* qi = W_hat + i * N;
        std::iota(idx_p.begin(), idx_p.end(), 0);
        std::iota(idx_q.begin(), idx_q.end(), 0);
        std::partial_sort(idx_p.begin(), idx_p.begin() + k, idx_p.end(),
                          [&](int a, int b) { return pi[a] > pi[b]; });
        std::partial_sort(idx_q.begin(), idx_q.begin() + k, idx_q.end(),
                          [&](int a, int b) { return qi[a] > qi[b]; });
        std::unordered_set<int> top_q(idx_q.begin(), idx_q.begin() + k);
        int hits = 0;
        for (int j = 0; j < k; ++j) if (top_q.count(idx_p[j])) ++hits;
        sum += (double)hits / k;
    }
    return (float)(sum / Nq);
}

// ═══════════════════════════════════════════════════════════════════════════
//  Bit-packing helpers (for GPU upload)
// ═══════════════════════════════════════════════════════════════════════════

static int bytes_pt(int n_bits) { return (D * n_bits + 7) / 8; }

static std::vector<uint8_t> pack_idx(const std::vector<int>& idx, int N, int n_bits) {
    int bpt = bytes_pt(n_bits);
    std::vector<uint8_t> out(N * bpt, 0);
    for (int i = 0; i < N; ++i) {
        uint8_t* p = out.data() + i * bpt;
        for (int j = 0; j < D; ++j) {
            int bit_off = j * n_bits, byte_off = bit_off >> 3, bit_shift = bit_off & 7;
            uint32_t val = (uint32_t)(idx[i*D+j] & ((1 << n_bits) - 1));
            p[byte_off] |= (uint8_t)(val << bit_shift);
            if (bit_shift + n_bits > 8)
                p[byte_off + 1] |= (uint8_t)(val >> (8 - bit_shift));
        }
    }
    return out;
}

static std::vector<uint8_t> pack_bits(const std::vector<float>& signs, int N) {
    std::vector<uint8_t> out(N * QJL_BYTES, 0);
    for (int i = 0; i < N; ++i) {
        uint8_t* p = out.data() + i * QJL_BYTES;
        for (int j = 0; j < D; ++j)
            if (signs[i*D+j] > 0.f) p[j >> 3] |= (uint8_t)(1 << (j & 7));
    }
    return out;
}

// ═══════════════════════════════════════════════════════════════════════════
//  GPU encoding state (for upload)
// ═══════════════════════════════════════════════════════════════════════════

struct GpuEncoding {
    std::vector<uint8_t> pk_K, pk_V;
    std::vector<uint8_t> pk_qjl_K, pk_qjl_V;
    std::vector<float>   norms_K, norms_V;
    std::vector<float>   r_norms_K, r_norms_V;
};

// ═══════════════════════════════════════════════════════════════════════════
//  Data generators
// ═══════════════════════════════════════════════════════════════════════════

struct KVData {
    std::vector<float> K, V, Q, K_cal;
    int N, Nq, N_cal, d_h;
};

/* Unit sphere — TurboQuant's home territory */
static KVData make_unit_sphere(int N, int d_h, int N_cal, int Nq, std::mt19937& rng) {
    std::normal_distribution<float> gauss(0.f, 1.f);
    auto sphere = [&](int n) {
        std::vector<float> X(n * d_h);
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < d_h; ++j) X[i*d_h+j] = gauss(rng);
            float n2 = 0;
            for (int j = 0; j < d_h; ++j) n2 += X[i*d_h+j] * X[i*d_h+j];
            float inv = 1.f / sqrtf(n2 + 1e-30f);
            for (int j = 0; j < d_h; ++j) X[i*d_h+j] *= inv;
        }
        return X;
    };
    KVData kv;
    kv.N = N; kv.Nq = Nq; kv.N_cal = N_cal; kv.d_h = d_h;
    kv.K     = sphere(N);
    kv.V     = sphere(N);
    kv.Q     = sphere(Nq);
    kv.K_cal = sphere(N_cal);
    return kv;
}

/* Low-rank aligned — signal in FIRST `rank` standard basis directions.
   Hard case for Plain-KV: active coords std ≈ 1/√rank >> Beta std ≈ 1/√d. */
static KVData make_lowrank_aligned(int N, int d_h, int N_cal, int Nq,
                                    int rank, float sigma_noise, std::mt19937& rng) {
    std::normal_distribution<float> gauss(0.f, 1.f);
    auto make = [&](int n) {
        std::vector<float> X(n * d_h, 0.f);
        for (int i = 0; i < n; ++i)
            for (int k = 0; k < rank; ++k)
                X[i*d_h+k] = gauss(rng);
        if (sigma_noise > 0.f)
            for (int i = 0; i < n * d_h; ++i)
                X[i] += sigma_noise * gauss(rng);
        return X;
    };
    KVData kv;
    kv.N = N; kv.Nq = Nq; kv.N_cal = N_cal; kv.d_h = d_h;
    kv.K     = make(N);
    kv.V     = make(N);
    kv.Q     = make(Nq);
    kv.K_cal = make(N_cal);
    return kv;
}

/* Low-rank with random orthogonal subspace (from pquant_hip_metrics.hip) */
static KVData make_lowrank(int N, int d_h, int N_cal, int Nq,
                             int rank, std::mt19937& rng) {
    std::normal_distribution<float> gauss(0.f, 1.f);
    std::vector<float> A(d_h * rank);
    for (auto& v : A) v = gauss(rng);
    float inv_r = 1.f / sqrtf((float)rank);
    auto make = [&](int n) {
        std::vector<float> Z(n * rank), X(n * d_h, 0.f);
        for (auto& v : Z) v = gauss(rng);
        for (int i = 0; i < n; ++i)
            for (int j = 0; j < d_h; ++j)
                for (int k = 0; k < rank; ++k)
                    X[i*d_h+j] += Z[i*rank+k] * A[j*rank+k] * inv_r;
        return X;
    };
    KVData kv;
    kv.N = N; kv.Nq = Nq; kv.N_cal = N_cal; kv.d_h = d_h;
    kv.K     = make(N);
    kv.V     = make(N);
    kv.Q     = make(Nq);
    kv.K_cal = make(N_cal);
    return kv;
}

/*
 * Low-rank with exponential eigenvalue decay — designed to trigger water-fill.
 * rank=4, scale[k] = base^{(rank-1-k)/(rank-1)} so scale[0]=base, scale[rank-1]=1.
 * At base=8: variance ratios 64:8:1 across dims → λ_max/λ_min ≈ 512 for rank=4,
 * which forces water_fill to allocate [b+2, b+1, b, b-1] or similar.
 * Random mixing matrix A (d_h × rank) so subspace is not axis-aligned.
 */
static KVData make_lowrank_steep(int N, int d_h, int N_cal, int Nq,
                                  int rank, float base, std::mt19937& rng) {
    std::normal_distribution<float> gauss(0.f, 1.f);
    std::vector<float> A(d_h * rank);
    for (auto& v : A) v = gauss(rng);
    // Scale columns: column k gets scale = base^{(rank-1-k)/(rank-1)}
    std::vector<float> col_scale(rank);
    for (int k = 0; k < rank; ++k)
        col_scale[k] = powf(base, (float)(rank - 1 - k) / (float)(rank - 1));
    for (int k = 0; k < rank; ++k)
        for (int j = 0; j < d_h; ++j)
            A[j * rank + k] *= col_scale[k] / sqrtf((float)rank);

    auto make = [&](int n) {
        std::vector<float> Z(n * rank), X(n * d_h, 0.f);
        for (auto& v : Z) v = gauss(rng);
        for (int i = 0; i < n; ++i)
            for (int j = 0; j < d_h; ++j)
                for (int k = 0; k < rank; ++k)
                    X[i*d_h+j] += Z[i*rank+k] * A[j*rank+k];
        return X;
    };
    KVData kv;
    kv.N = N; kv.Nq = Nq; kv.N_cal = N_cal; kv.d_h = d_h;
    kv.K     = make(N);
    kv.V     = make(N);
    kv.Q     = make(Nq);
    kv.K_cal = make(N_cal);
    return kv;
}

/*
 * Low-rank misaligned — K and V live in DIFFERENT random rank-4 subspaces.
 * SQ calibrates on K_cal (same subspace as K). V is generated from a
 * separate mixing matrix B, so SQ's eigenbasis is wrong for V.
 * Tests the hidden SQ assumption that K and V share principal directions.
 */
static KVData make_lowrank_misalign(int N, int d_h, int N_cal, int Nq,
                                     int rank, std::mt19937& rng) {
    std::normal_distribution<float> gauss(0.f, 1.f);
    std::vector<float> A(d_h * rank), B(d_h * rank);
    for (auto& v : A) v = gauss(rng);
    for (auto& v : B) v = gauss(rng);
    float inv_r = 1.f / sqrtf((float)rank);

    auto make_from = [&](const std::vector<float>& M, int n) {
        std::vector<float> Z(n * rank), X(n * d_h, 0.f);
        for (auto& v : Z) v = gauss(rng);
        for (int i = 0; i < n; ++i)
            for (int j = 0; j < d_h; ++j)
                for (int k = 0; k < rank; ++k)
                    X[i*d_h+j] += Z[i*rank+k] * M[j*rank+k] * inv_r;
        return X;
    };
    KVData kv;
    kv.N = N; kv.Nq = Nq; kv.N_cal = N_cal; kv.d_h = d_h;
    kv.K     = make_from(A, N);
    kv.V     = make_from(B, N);     // different subspace from K
    kv.Q     = make_from(A, Nq);   // Q aligns with K
    kv.K_cal = make_from(A, N_cal); // calibration matches K subspace
    return kv;
}

/* Fat-tail (Student-t) from pquant_hip_metrics.hip */
/*
 * Extreme water-filling trigger regime.
 *
 * Design: rank=3 with col_scales = [sqrt(7), 1, 1].
 *   - One dominant direction (scale sqrt(7)) and two equal directions (scale 1).
 *   - Eigenvalue ratio within semantic dims: 7/1 = 7 > 4 threshold  → water-fill fires.
 *   - Participation ratio: PR = (7+1+1)^2 / (49+1+1) ≈ 1.59 → d_eff = 2.
 *
 * Why rank=2 with steep decay fails: for a 2-eigenvalue system, d_eff ≥ 2
 * requires λ_ratio ≤ 3.73 but water-filling requires λ_ratio > 4.  These
 * conditions are mutually exclusive.  Three components resolve the tension:
 * the two equal dims keep d_eff = 2 while the dominant/secondary ratio exceeds 4.
 *
 * A1 and A2 are fully satisfied (K and V share the same subspace, Gaussian marginals).
 * Only A3 is under test.
 */
static KVData make_lowrank_extreme(int N, int d_h, int N_cal, int Nq,
                                    std::mt19937& rng) {
    const int rank = 3;
    const float col_scales[3] = {sqrtf(7.0f), 1.0f, 1.0f};
    std::normal_distribution<float> gauss(0.f, 1.f);
    std::vector<float> A(d_h * rank);
    for (auto& v : A) v = gauss(rng);
    for (int k = 0; k < rank; ++k)
        for (int j = 0; j < d_h; ++j)
            A[j * rank + k] *= col_scales[k] / sqrtf((float)rank);

    auto make = [&](int n) {
        std::vector<float> Z(n * rank), X(n * d_h, 0.f);
        for (auto& v : Z) v = gauss(rng);
        for (int i = 0; i < n; ++i)
            for (int j = 0; j < d_h; ++j)
                for (int k = 0; k < rank; ++k)
                    X[i*d_h+j] += Z[i*rank+k] * A[j*rank+k];
        return X;
    };
    KVData kv;
    kv.N = N; kv.Nq = Nq; kv.N_cal = N_cal; kv.d_h = d_h;
    kv.K     = make(N);
    kv.V     = make(N);
    kv.Q     = make(Nq);
    kv.K_cal = make(N_cal);
    return kv;
}

static KVData make_fattail(int N, int d_h, int N_cal, int Nq,
                             float nu, std::mt19937& rng) {
    std::normal_distribution<float> gauss(0.f, 1.f);
    std::chi_squared_distribution<float> chi2(nu);
    auto make = [&](int n) {
        std::vector<float> X(n * d_h);
        for (int i = 0; i < n * d_h; ++i) {
            float c = sqrtf(chi2(rng) / nu);
            X[i] = gauss(rng) / (c + 1e-6f);
        }
        return X;
    };
    KVData kv;
    kv.N = N; kv.Nq = Nq; kv.N_cal = N_cal; kv.d_h = d_h;
    kv.K     = make(N);
    kv.V     = make(N);
    kv.Q     = make(Nq);
    kv.K_cal = make(N_cal);
    return kv;
}
