"""
compare_qjl_variants.py — TQ-QKV (RHT) vs TQ-FKV (Full) Python comparison
===========================================================================
Runs both QJL-K variants on identical K, V, Q data and compares:
  - ptcosine_K (K reconstruction quality — identical, both use same MSE)
  - topk5, KL, cosine (attention output quality — variant-dependent)

Both variants are unbiased estimators of <q, k>. The question is which
has lower variance and better top-k accuracy in practice.

Usage:
    python compare_qjl_variants.py --regime unit_sphere fattail --budget 2 3 4
"""

import argparse
import sys
import pathlib
import numpy as np
import pandas as pd

HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE.parent))

from python.codecs.tq_codec import (tq_solve_codebook, tq_roundtrip,
                                     tq_encode_qjl_score, tq_attention_score)
from python.codecs.qjl import make_sign_vector, make_sign_matrix

ap = argparse.ArgumentParser()
ap.add_argument("--regime",  nargs="+", default=["unit_sphere", "lowrank", "fattail"])
ap.add_argument("--budget",  nargs="+", type=int, default=[2, 3, 4])
ap.add_argument("--S",       type=int, default=256)
ap.add_argument("--Nq",      type=int, default=32)
ap.add_argument("--trials",  type=int, default=200)
ap.add_argument("--d",       type=int, default=128)
ap.add_argument("--seed",    type=int, default=42)
args = ap.parse_args()

D    = args.d
RNG  = np.random.default_rng(args.seed)

# ── data generators ───────────────────────────────────────────────────────────

def make_unit_sphere(S, rng):
    X = rng.standard_normal((S, D))
    return X / np.linalg.norm(X, axis=1, keepdims=True)

def make_lowrank(S, rng, rank=8):
    A = rng.standard_normal((D, rank)) / np.sqrt(rank)
    return rng.standard_normal((S, rank)) @ A.T

def make_fattail(S, rng, nu=3.0):
    normal = rng.standard_normal((S, D))
    chi2   = rng.chisquare(nu, size=(S, D))
    return normal / np.sqrt(chi2 / nu + 1e-6)

REGIME_FN = {
    "unit_sphere": make_unit_sphere,
    "lowrank":     make_lowrank,
    "fattail":     make_fattail,
}

# ── attention helpers ─────────────────────────────────────────────────────────

def softmax(X):
    X = X - X.max(axis=-1, keepdims=True)
    E = np.exp(X); return E / E.sum(axis=-1, keepdims=True)

def attention(Q, K, V):
    W = softmax(Q @ K.T / np.sqrt(D))
    return W @ V, W

def cosine_mean(A, B):
    n = np.linalg.norm(A, axis=1) * np.linalg.norm(B, axis=1) + 1e-12
    return float(np.mean(np.sum(A * B, axis=1) / n))

def rel_mse(A, B):
    return float(np.sum((A-B)**2) / (np.sum(A**2) + 1e-30))

def topk_recall(W_ref, W_hat, k=5):
    k = min(k, W_ref.shape[1])
    top_ref = np.argsort(W_ref, axis=1)[:, -k:]
    top_hat = np.argsort(W_hat, axis=1)[:, -k:]
    return float(np.mean([
        len(np.intersect1d(top_ref[i], top_hat[i])) / k
        for i in range(len(W_ref))]))

def kl_div(P, Q_):
    P = np.clip(P, 1e-12, None); Q_ = np.clip(Q_, 1e-12, None)
    return float(np.mean(np.sum(P * np.log(P / Q_), axis=1)))

# ── sweep ─────────────────────────────────────────────────────────────────────

print(f"{'regime':<16} {'budget':>6} {'variant':<8} "
      f"{'topk5':>8} {'KL':>10} {'cosine':>8} {'relMSE':>8}")
print("-" * 70)

rows = []

for regime in args.regime:
    if regime not in REGIME_FN:
        print(f"Unknown regime: {regime}"); continue
    fn = REGIME_FN[regime]

    K = fn(args.S, RNG)
    V = fn(args.S, RNG)

    # Signs drawn once per (regime) — same for both variants
    S2_K   = make_sign_vector(D, RNG)          # d-vector — RHT
    S_mat_K = make_sign_matrix(D, RNG)         # d×d     — Full

    trial_rng = np.random.default_rng(args.seed ^ 0xBEEF1234)

    for budget in args.budget:
        nK = budget - 1   # MSE bits (1 bit for QJL)
        if nK < 1: continue

        cb_K = tq_solve_codebook(D, nK)
        cb_V = tq_solve_codebook(D, budget)

        V_hat = tq_roundtrip(V, cb_V, use_qjl=False)

        # Encode K with both variants — same MSE reconstruction
        enc_rht  = tq_encode_qjl_score(K, cb_K, S2_K)    # RHT
        enc_full = tq_encode_qjl_score(K, cb_K, S_mat_K)  # Full

        # ptcosine_K — identical for both (same MSE)
        from python.codecs.tq_codec import tq_encode, tq_decode
        K_hat = enc_rht.x_hat_mse
        ptcos_K = float(np.mean(
            np.sum(K * K_hat, axis=1) /
            (np.linalg.norm(K, axis=1) * np.linalg.norm(K_hat, axis=1) + 1e-12)))

        # Trial loop — same Q for both variants
        sums = {v: {"topk5": 0., "KL": 0., "cosine": 0., "relMSE": 0.}
                for v in ["RHT", "Full", "MSE"]}

        for _ in range(args.trials):
            Q = trial_rng.standard_normal((args.Nq, D))
            T_ref, W_ref = attention(Q, K, V)

            for variant, enc, S in [("RHT",  enc_rht,  S2_K),
                                     ("Full", enc_full, S_mat_K)]:
                scores = tq_attention_score(Q, enc, S) / np.sqrt(D)
                W_hat  = softmax(scores)
                T_hat  = W_hat @ V_hat
                sums[variant]["topk5"]  += topk_recall(W_ref, W_hat)
                sums[variant]["KL"]     += kl_div(W_ref, W_hat)
                sums[variant]["cosine"] += cosine_mean(T_ref, T_hat)
                sums[variant]["relMSE"] += rel_mse(T_ref, T_hat)

            # MSE-only baseline (no QJL score correction)
            K_hat_mse = enc_rht.x_hat_mse
            T_mse, W_mse = attention(Q, K_hat_mse, V_hat)
            sums["MSE"]["topk5"]  += topk_recall(W_ref, W_mse)
            sums["MSE"]["KL"]     += kl_div(W_ref, W_mse)
            sums["MSE"]["cosine"] += cosine_mean(T_ref, T_mse)
            sums["MSE"]["relMSE"] += rel_mse(T_ref, T_mse)

        nt = args.trials
        for variant in ["MSE", "RHT", "Full"]:
            s = sums[variant]
            print(f"{regime:<16} {budget:>6} {variant:<8} "
                  f"{s['topk5']/nt:>8.4f} {s['KL']/nt:>10.6f} "
                  f"{s['cosine']/nt:>8.4f} {s['relMSE']/nt:>8.4f}")
            rows.append({"regime": regime, "budget": budget, "variant": variant,
                         "ptcosine_K": ptcos_K,
                         "topk5":  s["topk5"]  / nt,
                         "KL":     s["KL"]      / nt,
                         "cosine": s["cosine"]  / nt,
                         "relMSE": s["relMSE"]  / nt})
        print()

df = pd.DataFrame(rows)
out = "/tmp/qjl_variant_comparison.csv"
df.to_csv(out, index=False)
print(f"Saved: {out}")
