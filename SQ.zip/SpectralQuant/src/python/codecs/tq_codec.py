"""
tq_codec.py — TurboQuant codec (Python reference implementation).
=================================================================
Reference: TurboQuant (Zandieh et al. 2024), Algorithm 1 (MSE) + Algorithm 2 (QJL).
Matches turboquant/quantizer.py from the reference implementation.

Pipeline per token vector v:
  1. Normalize: v̂ = v / ||v||, store norm
  2. Rotate:    r = v̂ @ Π.T   where Π is a random orthogonal matrix (WHT approx)
  3. Quantize:  idx = Lloyd-Max(r, codebook)
  4. Decode MSE: v_hat_mse = (centroids[idx] @ Π) * ||v||   (token space)
  5. QJL (opt): residual = v - v_hat_mse   (in token space, not WHT domain)
               sign_bits = sign(residual @ S.T)   S: d×d Rademacher matrix
               correction = sign_bits @ S * sqrt(π/2)/d * ||residual||
               v_hat = v_hat_mse + correction

Key difference from previous implementation:
  - QJL residual is in TOKEN SPACE, not WHT domain
  - S is a full d×d random sign matrix, applied via matmul
  - This matches TurboQuant Algorithm 2 exactly
"""

import numpy as np
from typing import Optional

from .qjl import qjl_encode_batch, qjl_decode_batch, make_sign_matrix, make_sign_vector
from ..common.types import TQCodebook, EncodeResult


def _wht_normalized_batch(X: np.ndarray) -> np.ndarray:
    """Normalized WHT for batch of row vectors. Shape (N, d), d power of 2."""
    X = X.astype(np.float64).copy()
    N, d = X.shape
    h = 1
    while h < d:
        X = X.reshape(N, -1, h * 2)
        left  = X[:, :, :h] + X[:, :, h:]
        right = X[:, :, :h] - X[:, :, h:]
        X = np.concatenate([left, right], axis=2).reshape(N, d)
        h *= 2
    return X / np.sqrt(d)


# ── codebook ──────────────────────────────────────────────────────────────────

def tq_solve_codebook(d: int, n_bits: int,
                      rng: Optional[np.random.Generator] = None) -> TQCodebook:
    """
    Fit analytical Beta Lloyd-Max codebook for TurboQuant.
    Beta((d-1)/2, (d-1)/2) on [-1, 1]. Uses double precision.
    Exploits symmetry: solves positive half, mirrors to get exact symmetric codebook.
    """
    K = 1 << n_bits
    a = (d - 1) / 2.0

    if K == 1:
        centroids  = np.array([0.0])
        boundaries = np.array([-1.0, 1.0])
    elif K == 2:
        # Analytical solution: centroid = E[|Beta|]
        # Solve positive half only
        c_pos = _solve_positive_half(a, K // 2, n_iter=500, tol=1e-12)
        centroids  = np.concatenate([-c_pos[::-1], c_pos])
        boundaries = np.array([-1.0, 0.0, 1.0])
    else:
        c_pos, b_pos = _solve_positive_half_with_boundaries(a, K // 2, n_iter=500, tol=1e-12)
        centroids  = np.concatenate([-c_pos[::-1], c_pos])
        boundaries = np.concatenate([[-1.0], -b_pos[1:-1][::-1], [0.0], b_pos[1:-1], [1.0]])

    if rng is None:
        rng = np.random.default_rng(0)
    wht_signs = rng.choice([-1.0, 1.0], size=d)

    return TQCodebook(d=d, n_bits=n_bits,
                      centroids=centroids.astype(np.float32),
                      boundaries=boundaries.astype(np.float32),
                      wht_signs=wht_signs.astype(np.float32))


def _beta_pdf_log(t: np.ndarray, a: float) -> np.ndarray:
    """Log Beta((a,a)) PDF on [-1,1]. Double precision."""
    out = np.full_like(t, -np.inf)
    mask = (t > -1.0) & (t < 1.0)
    out[mask] = (a - 1.0) * (np.log((1.0 + t[mask]) * 0.5) +
                              np.log((1.0 - t[mask]) * 0.5))
    return out


def _solve_positive_half(a: float, K_half: int,
                          n_iter: int = 500, tol: float = 1e-12):
    """Lloyd-Max on [0,1] for K_half levels (positive half of Beta)."""
    n_samples = 100_000
    rng = np.random.default_rng(0)
    # Beta(a,a) on [0,1] → [-1,1]: sample and take |x|
    raw = rng.beta(a, a, size=n_samples * 2)
    samples = np.abs(2.0 * raw - 1.0)

    probs = np.linspace(0, 100, K_half + 2)[1:-1]
    c = np.percentile(samples, probs)
    b = np.empty(K_half + 1)
    b[0], b[-1] = 0.0, 1.0

    for _ in range(n_iter):
        b[1:-1] = 0.5 * (c[:-1] + c[1:])
        idx = np.searchsorted(b[1:-1], samples)
        new_c = c.copy()
        for k in range(K_half):
            sel = samples[idx == k]
            if len(sel):
                new_c[k] = sel.mean()
        if np.max(np.abs(new_c - c)) < tol:
            c = new_c
            break
        c = new_c
    b[1:-1] = 0.5 * (c[:-1] + c[1:])
    return c


def _solve_positive_half_with_boundaries(a, K_half, n_iter=500, tol=1e-12):
    c = _solve_positive_half(a, K_half, n_iter, tol)
    b = np.empty(K_half + 1)
    b[0], b[-1] = 0.0, 1.0
    b[1:-1] = 0.5 * (c[:-1] + c[1:])
    return c, b


# ── encode / decode ───────────────────────────────────────────────────────────

def tq_encode(X: np.ndarray, cb: TQCodebook,
              use_qjl: bool = False,
              S2: Optional[np.ndarray] = None) -> EncodeResult:
    """
    TurboQuant encode for N tokens.

    Pipeline:
      1. Normalize: x_norm = x / ||x||
      2. Rotate:    y = WHT_norm(x_norm * wht_signs)   — Beta-distributed
      3. Quantize:  idx = Lloyd-Max(y)
      4. QJL (opt): e = y - centroids[idx]             — residual in WHT domain
                    sign_bits = sign(WHT_norm(e * S2))  — sketch of WHT-domain residual
                    r_norm = ||e||

    Parameters
    ----------
    X       : (N, d) token matrix
    cb      : TQCodebook
    use_qjl : if True, encode QJL residual sketch in WHT domain
    S2      : (d,) random sign vector in {-1,+1} (required if use_qjl)
    """
    N, d = X.shape
    norms = np.linalg.norm(X, axis=1, keepdims=True).clip(1e-12)
    X_norm = X / norms                              # (N, d) unit sphere

    # WHT rotate
    Y = _wht_normalized_batch(X_norm * cb.wht_signs[np.newaxis, :])  # (N, d)

    # Quantize in WHT domain
    bnd = cb.boundaries[1:-1]
    pack = np.clip(np.searchsorted(bnd, Y), 0, len(cb.centroids) - 1)

    r_norms   = np.zeros(N, dtype=np.float32)
    sign_bits = np.zeros((N, d), dtype=np.float32)

    if use_qjl:
        assert S2 is not None, "S2 required for QJL"
        # Residual in WHT domain: e = y - centroid
        E = Y - cb.centroids[pack]                  # (N, d)
        r_norms = np.linalg.norm(E, axis=1)         # (N,)
        if S2.ndim == 1:
            # RHT: sign(WHT_norm(e * S2))
            sign_bits = np.sign(_wht_normalized_batch(E * S2[np.newaxis, :]))
        else:
            # FULL: sign(e @ S2.T)
            sign_bits = np.sign(E @ S2.T)           # (N, d)
        sign_bits[sign_bits == 0] = 1.0

    return EncodeResult(
        pack      = pack.astype(np.uint8),
        norms     = norms.squeeze(1).astype(np.float32),
        r_norms   = r_norms.astype(np.float32),
        sign_bits = sign_bits.astype(np.float32),
    )


def tq_decode(enc: EncodeResult, cb: TQCodebook,
              use_qjl: bool = False,
              S2: Optional[np.ndarray] = None) -> np.ndarray:
    """
    TurboQuant decode.

    Pipeline:
      1. Lookup centroids: y_hat = centroids[idx]           — WHT domain
      2. QJL (opt):        r_hat = sqrt(π/2)/d * ||e|| * S2 * WHT_norm(sign_bits)
                           y_corrected = y_hat + r_hat      — correction in WHT domain
      3. Inverse WHT:      x_hat = ||x|| * wht_signs * WHT_norm(y_corrected)
    """
    N = len(enc.norms)

    # Dequantize: look up centroids in WHT domain
    Y_hat = cb.centroids[enc.pack].astype(np.float64)  # (N, d)

    if use_qjl:
        assert S2 is not None
        scale = np.sqrt(np.pi / 2.0) / Y_hat.shape[1]
        if S2.ndim == 1:
            # RHT: correction = scale * r_norm * S2 * WHT_norm(sign_bits)
            R = _wht_normalized_batch(enc.sign_bits)    # (N, d)
            correction = scale * enc.r_norms[:, np.newaxis] * S2[np.newaxis, :] * R
        else:
            # FULL: correction = scale * r_norm * sign_bits @ S2
            correction = scale * enc.r_norms[:, np.newaxis] * (enc.sign_bits @ S2)
        Y_hat = Y_hat + correction

    # Inverse WHT: WHT_norm(y) * wht_signs * norm
    X_hat_norm = _wht_normalized_batch(Y_hat) * cb.wht_signs[np.newaxis, :]
    return X_hat_norm * enc.norms[:, np.newaxis]


def tq_roundtrip(X: np.ndarray, cb: TQCodebook,
                 use_qjl: bool = False,
                 S2: Optional[np.ndarray] = None) -> np.ndarray:
    """Convenience: encode then decode. S2 is d-vector for WHT-based QJL."""
    return tq_decode(tq_encode(X, cb, use_qjl, S2), cb, use_qjl, S2)


# ── asymmetric score estimator (TurboQuant Algorithm 2) ──────────────────────

def tq_encode_qjl_score(X: np.ndarray, cb: TQCodebook,
                         S: np.ndarray) -> 'TQScoreEncodeResult':
    """
    Encode K vectors for asymmetric inner product estimation.
    Residual is in X (token) space — not WHT domain.

    Pipeline:
      1. MSE encode: x_hat_mse = tq_roundtrip(x, cb, use_qjl=False)
      2. Residual in X space: e = x - x_hat_mse
      3. Sketch via qjl_encode_batch(e, S) — S selects variant:
           S.ndim == 1  →  RHT:  sign(WHT_norm(e * S))   O(d log d)
           S.ndim == 2  →  Full: sign(e @ S.T)            O(d²)

    Parameters
    ----------
    X  : (N, d) token matrix (K vectors)
    cb : TQCodebook
    S  : d-vector (RHT variant) or d×d matrix (full projection variant)

    Returns TQScoreEncodeResult with:
      x_hat_mse : (N, d) MSE reconstruction
      sign_bits : (N, d) QJL sign bits
      r_norms   : (N,)   residual norms
    """
    from dataclasses import dataclass

    @dataclass
    class TQScoreEncodeResult:
        x_hat_mse : np.ndarray
        sign_bits : np.ndarray
        r_norms   : np.ndarray

    # MSE reconstruction in token space
    enc = tq_encode(X, cb, use_qjl=False)
    X_hat_mse = tq_decode(enc, cb, use_qjl=False)

    # Residual in X space — use same qjl_encode_batch as V path
    E = X - X_hat_mse
    sign_bits, r_norms = qjl_encode_batch(E, S)

    return TQScoreEncodeResult(
        x_hat_mse = X_hat_mse,
        sign_bits = sign_bits,
        r_norms   = r_norms,
    )


def tq_attention_score(Q: np.ndarray, enc, S: np.ndarray) -> np.ndarray:
    """
    Compute asymmetric attention score estimates E[<q, k>] using QJL.

    score = <q, k_hat_mse> + sqrt(π/2)/d * r_norm * q_sketch @ sign_bits.T

    where q_sketch uses the same variant as encode (RHT or full projection).

    Parameters
    ----------
    Q   : (Nq, d) query matrix
    enc : TQScoreEncodeResult (from tq_encode_qjl_score)
    S   : same S used in encode (d-vector → RHT, d×d → full projection)

    Returns
    -------
    scores : (Nq, N) attention logits  — unbiased estimate of Q @ K.T
    """
    d = Q.shape[1]
    scale = np.sqrt(np.pi / 2.0) / d

    # MSE contribution
    scores_mse = Q @ enc.x_hat_mse.T              # (Nq, N)

    # QJL correction — variant selected by S.ndim:
    #   RHT  (S.ndim==1): q_sketch[q,j] = WHT_norm(Q[q] * S)[j]
    #   Full (S.ndim==2): q_sketch[q,j] = (Q[q] @ S.T)[j]
    # In both cases: scores_qjl[q,k] = scale * r_norms[k] * dot(q_sketch[q], sign_bits[k])
    if S.ndim == 1:
        q_sketch = _wht_normalized_batch(Q * S[np.newaxis, :])   # (Nq, d)
    else:
        q_sketch = Q @ S.T                                  # (Nq, d)

    scores_qjl = q_sketch @ enc.sign_bits.T                # (Nq, N)
    scores_qjl *= scale * enc.r_norms[np.newaxis, :]

    return scores_mse + scores_qjl
