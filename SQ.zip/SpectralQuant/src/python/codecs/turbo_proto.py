"""turbo_proto.py — CPU prototype for TurboQuant KV-cache quantization
=======================================================================

TurboQuant pipeline (per vector):
  1. Normalize : v → v / ||v||, store ||v|| as FP32 side-channel
  2. Randomize : r = WHT(D · v̂)  where D = diag(±1) fixed random signs
                 After this step each coordinate ~ Beta((d-1)/2, (d-1)/2)
  3. Quantize  : shared Lloyd-Max codebook fitted analytically to Beta
  4. QJL       : (optional) 1-bit sketch of MSE residual via a second WHT
  5. Decode    : dequantize → add QJL estimate → inverse WHT → denormalize

Five scheme variants (at nominal budget b bits/dim):
  Plain-KV — scalar MSE b-bit on K and V, NO WHT rotation (HIP baseline)
  TQ-KV    — scalar MSE b-bit on K and V, no QJL
  TQ-QKV   — (b-1)-bit MSE + 1-bit QJL on K; scalar MSE b-bit on V
  TQ-KQV   — scalar MSE b-bit on K; (b-1)-bit MSE + 1-bit QJL on V
  TQ-QKQV  — (b-1)-bit MSE + 1-bit QJL on both K and V

Usage:
    python turbo_proto.py                          # all regimes, b=2..5
    python turbo_proto.py --regime lowrank_r8_exp  # single regime
    python turbo_proto.py --budget 2 3 4 5 --quiet
"""

from __future__ import annotations

import sys
import os
import argparse

import numpy as np
import pandas as pd
from scipy.stats import beta as beta_dist

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
sys.path.insert(0, os.path.join(_HERE, "pquant_6d"))

from snr_metrics_6d import add_snr_err
from spectralquant_proto import (
    cosine_sim, rel_mse, attention_output, kl_softmax,
    calibrate, beta_diagnostic,
)
from synth_kv import gaussian_lowrank, student_rotated, misaligned_kv, two_population

RNG_SEED = 42


# ═══════════════════════════════════════════════════════════════════════════════
# 1.  VECTORIZED FAST WALSH-HADAMARD TRANSFORM
# ═══════════════════════════════════════════════════════════════════════════════

def fwht_batch(X: np.ndarray) -> np.ndarray:
    """Vectorized WHT for a batch of row-vectors. X: (N, d), d must be power of 2."""
    X = np.array(X, dtype=np.float64)
    N, d = X.shape
    w = 1
    while w < d:
        X = X.reshape(N, -1, w * 2)
        left  = X[:, :, :w] + X[:, :, w:]
        right = X[:, :, :w] - X[:, :, w:]
        X = np.concatenate([left, right], axis=2).reshape(N, d)
        w *= 2
    return X


def wht_rotate(X: np.ndarray, signs: np.ndarray) -> np.ndarray:
    """Forward randomized WHT: WHT(X * signs) / sqrt(d)."""
    return fwht_batch(X * signs[np.newaxis, :]) / np.sqrt(X.shape[1])


def wht_rotate_inv(X: np.ndarray, signs: np.ndarray) -> np.ndarray:
    """Inverse randomized WHT: WHT(X) * signs / sqrt(d)."""
    return fwht_batch(X) * signs[np.newaxis, :] / np.sqrt(X.shape[1])


# ═══════════════════════════════════════════════════════════════════════════════
# 2.  LLOYD-MAX FITTED ANALYTICALLY TO Beta((d-1)/2, (d-1)/2) ON [-1, 1]
# ═══════════════════════════════════════════════════════════════════════════════

_CODEBOOK_CACHE: dict = {}   # (d, n_bits) → (centroids, boundaries)


def solve_lloyd_max_beta(
    d: int,
    n_bits: int,
    n_samples: int = 50_000,
    max_iter: int = 500,
    tol: float = 1e-7,
) -> tuple:
    """
    Lloyd-Max scalar quantizer for Beta((d-1)/2, (d-1)/2) on [-1, 1].

    Beta(a,a) is exactly symmetric around 0, so we exploit symmetry:
    solve only the positive half (K/2 centroids on [0,1]) from positive
    samples, then mirror to get the full symmetric codebook. This enforces
    c_i = -c_{K-1-i} and boundary[K/2] = 0 exactly, eliminating finite-
    sample asymmetry from the naive full-range iteration.

    Results are cached globally — each (d, n_bits) pair is solved once.
    """
    key = (d, n_bits)
    if key in _CODEBOOK_CACHE:
        return _CODEBOOK_CACHE[key]

    print(f"    [codebook] Beta(d={d}, b={n_bits}) ... ", end="", flush=True)

    n_levels = 2 ** n_bits
    a = (d - 1) / 2.0

    if n_levels == 1:
        result = np.array([0.0]), np.array([-1.0, 1.0])
        _CODEBOOK_CACHE[key] = result
        print("done")
        return result

    # Draw samples from positive half only: Beta(a,a) on [0,1] → [0,1] → [0,1]
    # (use |x| of full-range samples to get the positive half distribution exactly)
    rng = np.random.default_rng(0)
    samples_full = 2.0 * rng.beta(a, a, size=n_samples) - 1.0
    samples_pos = np.abs(samples_full)   # positive half, same distribution as |Beta(a,a)|

    # Solve K/2-level Lloyd-Max on [0, 1] for positive half
    K_half = n_levels // 2
    probs = np.linspace(0, 100, K_half + 2)[1:-1]
    c_pos = np.percentile(samples_pos, probs)   # K_half positive centroids

    bnd_pos = np.empty(K_half + 1)
    bnd_pos[0] = 0.0; bnd_pos[-1] = 1.0

    for _ in range(max_iter):
        bnd_pos[1:-1] = 0.5 * (c_pos[:-1] + c_pos[1:])
        bin_idx = np.searchsorted(bnd_pos[1:-1], samples_pos)
        new_c = c_pos.copy()
        for j in range(K_half):
            sel = samples_pos[bin_idx == j]
            if sel.size:
                new_c[j] = sel.mean()
        if np.max(np.abs(new_c - c_pos)) < tol:
            c_pos = new_c
            break
        c_pos = new_c

    bnd_pos[1:-1] = 0.5 * (c_pos[:-1] + c_pos[1:])

    # Mirror: negative half is exact reflection of positive half
    centroids  = np.concatenate([-c_pos[::-1], c_pos])
    boundaries = np.concatenate([[-1.0], -bnd_pos[1:-1][::-1], [0.0], bnd_pos[1:-1], [1.0]])

    result = centroids, boundaries
    _CODEBOOK_CACHE[key] = result
    print("done")
    return result


# ═══════════════════════════════════════════════════════════════════════════════
# 3.  TURBO CODEC
# ═══════════════════════════════════════════════════════════════════════════════

class TurboQuantCodec:
    """
    TurboQuant codec for one (layer, head).

    Parameters
    ----------
    d_h       : head dimension (must be power of 2 for WHT)
    b_mse_K   : MSE bits for K (b or b-1 depending on scheme)
    b_mse_V   : MSE bits for V
    use_qjl_K : add 1-bit QJL on K MSE residual
    use_qjl_V : add 1-bit QJL on V MSE residual
    rng       : np.random.Generator
    """

    def __init__(
        self,
        d_h: int,
        b_mse_K: int,
        b_mse_V: int,
        use_qjl_K: bool = False,
        use_qjl_V: bool = False,
        use_wht: bool = True,
        rng: np.random.Generator = None,
    ):
        self.d_h = d_h
        self.b_mse_K = b_mse_K
        self.b_mse_V = b_mse_V
        self.use_qjl_K = use_qjl_K
        self.use_qjl_V = use_qjl_V
        self.use_wht   = use_wht

        if rng is None:
            rng = np.random.default_rng(RNG_SEED)

        # Shared WHT randomization signs (same rotation for K and V)
        self.wht_signs = rng.choice([-1.0, 1.0], size=d_h)

        # Separate QJL randomization signs for K and V residuals
        self.qjl_signs_K = rng.choice([-1.0, 1.0], size=d_h)
        self.qjl_signs_V = rng.choice([-1.0, 1.0], size=d_h)

        # Codebooks (set by fit_codebooks)
        self.centroids_K  = None
        self.boundaries_K = None
        self.centroids_V  = None
        self.boundaries_V = None

    def fit_codebooks(self, K_cal=None):
        """
        Fit Lloyd-Max codebooks analytically to Beta((d-1)/2, (d-1)/2).

        K_cal is accepted for interface compatibility with SpectralQuantCodec
        but is not used — TurboQuant's codebook is data-oblivious.
        """
        self.centroids_K, self.boundaries_K = solve_lloyd_max_beta(self.d_h, self.b_mse_K)
        self.centroids_V, self.boundaries_V = solve_lloyd_max_beta(self.d_h, self.b_mse_V)

    def _roundtrip(
        self,
        X: np.ndarray,
        centroids: np.ndarray,
        boundaries: np.ndarray,
        use_qjl: bool,
        qjl_signs: np.ndarray,
    ) -> np.ndarray:
        """
        Encode/decode roundtrip for a batch of vectors.

        X       : (L, d_h)
        Returns   (L, d_h) reconstructed vectors
        """
        d = self.d_h
        n_levels = len(centroids)

        # Normalize per-vector L2 norm
        norms = np.linalg.norm(X, axis=1, keepdims=True).clip(1e-12)
        X_norm = X / norms                            # (L, d_h), unit sphere

        if self.use_wht:
            X_rot = wht_rotate(X_norm, self.wht_signs)   # (L, d_h)
        else:
            X_rot = X_norm                            # plain: quantize directly

        # Scalar quantize with shared Beta codebook
        idx = np.clip(
            np.searchsorted(boundaries[1:-1], X_rot), 0, n_levels - 1
        )                                             # (L, d_h)
        X_quant = centroids[idx]                      # (L, d_h)

        if use_qjl:
            residual = X_rot - X_quant                # (L, d_h)
            r_norms  = np.linalg.norm(residual, axis=1)  # (L,)

            # Encode: sign(WHT(residual * qjl_signs))
            qjl_bits = np.sign(
                fwht_batch(residual * qjl_signs[np.newaxis, :])
            )                                         # (L, d_h) in {-1, +1}

            # Decode: E[r̂] ∝ WHT(qjl_bits) * qjl_signs * sqrt(π/2) * ||r|| / d
            r_hat = (
                fwht_batch(qjl_bits) * qjl_signs[np.newaxis, :]
                / d * np.sqrt(np.pi / 2.0) * r_norms[:, np.newaxis]
            )                                         # (L, d_h)
            X_quant = X_quant + r_hat

        if self.use_wht:
            X_hat_norm = wht_rotate_inv(X_quant, self.wht_signs)  # (L, d_h)
        else:
            X_hat_norm = X_quant                      # plain: no inverse rotation

        return X_hat_norm * norms

    def encode_decode(self, X: np.ndarray, is_key: bool = True) -> tuple:
        """
        Interface-compatible with SpectralQuantCodec.encode_decode.

        Returns
        -------
        X_hat : (L, d_h)
        meta  : empty dict (no per-dim breakdown for TurboQuant)
        """
        if is_key:
            X_hat = self._roundtrip(
                X, self.centroids_K, self.boundaries_K,
                self.use_qjl_K, self.qjl_signs_K,
            )
        else:
            X_hat = self._roundtrip(
                X, self.centroids_V, self.boundaries_V,
                self.use_qjl_V, self.qjl_signs_V,
            )
        return X_hat, {}


# ═══════════════════════════════════════════════════════════════════════════════
# 4.  END-TO-END EXPERIMENT
# ═══════════════════════════════════════════════════════════════════════════════

def run_turbo_experiment(
    K: np.ndarray,
    V: np.ndarray,
    Q: np.ndarray,
    K_cal: np.ndarray,
    budgets=(2, 3, 4, 5),
    verbose: bool = True,
) -> pd.DataFrame:
    """
    Run the full TurboQuant comparison for one (layer, head) simulation.

    Schemes compared at each budget b:
        Plain-KV — MSE b-bit on K and V, NO WHT rotation (HIP KV baseline)
        TQ-KV    — MSE b-bit on K and V, no QJL
        TQ-QKV   — (b-1)-bit MSE + 1-bit QJL on K; MSE b-bit on V
        TQ-KQV   — MSE b-bit on K; (b-1)-bit MSE + 1-bit QJL on V
        TQ-QKQV  — (b-1)-bit MSE + 1-bit QJL on both K and V

    Parameters
    ----------
    K, V  : (L, d_h)   key / value vectors (test set)
    Q     : (L_q, d_h) query vectors
    K_cal : (N_cal, d_h) calibration keys (accepted, not used by TurboQuant)

    Returns
    -------
    DataFrame with same 6D error schema as run_experiment in spectralquant_proto.
    """
    d_h = K.shape[1]
    rng = np.random.default_rng(RNG_SEED)

    rows = []

    for b in budgets:
        # Solve codebooks once per b (reused across K/V/QJL variants at same b)
        # Pre-solve both b-bit and (b-1)-bit codebooks for this budget
        _codebook_cache = {}

        def get_codebook(n_bits):
            if n_bits not in _codebook_cache:
                _codebook_cache[n_bits] = solve_lloyd_max_beta(d_h, n_bits)
            return _codebook_cache[n_bits]

        # All schemes at budget b share the same WHT and QJL signs so that
        # TQ-QKV and TQ-QKQV have identical K-path randomization → identical SM KL.
        shared_codec_seed = int(np.random.default_rng(RNG_SEED + b * 997).integers(1 << 31))

        for scheme_name, b_mse_K, b_mse_V, use_qjl_K, use_qjl_V, use_wht in [
            ("Plain-KV", b,     b,     False, False, False),
            ("TQ-KV",    b,     b,     False, False, True),
            ("TQ-QKV",   b - 1, b,     True,  False, True),
            ("TQ-KQV",   b,     b - 1, False, True,  True),
            ("TQ-QKQV",  b - 1, b - 1, True,  True,  True),
        ]:
            if b_mse_K < 1 or b_mse_V < 1:
                continue   # b=2 is minimum; b=1 would give 0-bit MSE

            codec = TurboQuantCodec(
                d_h, b_mse_K, b_mse_V,
                use_qjl_K=use_qjl_K, use_qjl_V=use_qjl_V,
                use_wht=use_wht,
                rng=np.random.default_rng(shared_codec_seed),
            )
            # Inject pre-solved codebooks to avoid redundant quad() calls
            codec.centroids_K,  codec.boundaries_K  = get_codebook(b_mse_K)
            codec.centroids_V,  codec.boundaries_V  = get_codebook(b_mse_V)

            K_hat, _ = codec.encode_decode(K, is_key=True)
            V_hat, _ = codec.encode_decode(V, is_key=False)

            T_ref = attention_output(Q, K,     V,     d_h)
            T_hat = attention_output(Q, K_hat, V_hat, d_h)

            row = dict(
                scheme     = scheme_name,
                budget     = b,
                n_bits_K   = float(b_mse_K + int(use_qjl_K)),
                n_bits_V   = float(b_mse_V + int(use_qjl_V)),
                has_qjl_K  = int(use_qjl_K),
                has_qjl_V  = int(use_qjl_V),
                relMSE     = rel_mse(T_ref, T_hat),
                cosine     = cosine_sim(T_ref, T_hat),
                ptrelMSE_K = rel_mse(K, K_hat),
                ptrelMSE_V = rel_mse(V, V_hat),
                ptcosine_K = cosine_sim(K, K_hat),
                ptcosine_V = cosine_sim(V, V_hat),
                kl_sm      = kl_softmax(Q, K, K_hat, d_h),
            )
            rows.append(row)

            if verbose:
                print(f"  {scheme_name:<14} b={b}  "
                      f"b_mse_K={b_mse_K} b_mse_V={b_mse_V}  "
                      f"wht={use_wht}  qjl_K={use_qjl_K}  qjl_V={use_qjl_V}")
                print(f"    K:  relMSE={row['ptrelMSE_K']:.4f}  "
                      f"1-cos={1-row['ptcosine_K']:.4f}")
                print(f"    V:  relMSE={row['ptrelMSE_V']:.4f}  "
                      f"1-cos={1-row['ptcosine_V']:.4f}")
                print(f"    SM: KL={row['kl_sm']:.4f}")
                print(f"    T:  relMSE={row['relMSE']:.4f}  "
                      f"1-cos={1-row['cosine']:.4f}")

    df = pd.DataFrame(rows)
    df = add_snr_err(df)
    return df


# ═══════════════════════════════════════════════════════════════════════════════
# 5.  REGIME REGISTRY  (mirrors run_ladder.py)
# ═══════════════════════════════════════════════════════════════════════════════

def _make_random(n, d, n_cal, seed):
    """
    TurboQuant's home territory: vectors uniformly distributed on the
    d-dimensional unit sphere.  Each coordinate of a unit vector is
    Beta((d-1)/2, (d-1)/2) distributed — exactly what the Beta codebook
    is fitted to, with no WHT rotation needed.
    """
    rng = np.random.default_rng(seed)
    def unit_sphere(shape):
        X = rng.standard_normal(shape).astype(np.float32)
        return X / np.linalg.norm(X, axis=1, keepdims=True)
    K_cal = unit_sphere((n_cal, d))
    K     = unit_sphere((n,     d))
    V     = unit_sphere((n,     d))
    Q     = unit_sphere((64,    d))
    return K, V, Q, K_cal


def _make_lowrank_aligned(n, d, rank, sigma_noise, n_cal, seed):
    """
    Low-rank signal in the FIRST `rank` standard basis directions — no random
    subspace rotation.  This is the hard case for plain scalar quantization:
    active coordinates have std ≈ 1/sqrt(rank) >> Beta std ≈ 1/sqrt(d), so the
    Beta codebook is badly mismatched without WHT.  WHT spreads the concentrated
    signal uniformly, restoring the Beta regime and demonstrating its core value.
    """
    rng = np.random.default_rng(seed)
    def make(m):
        Z = rng.standard_normal((m, rank)).astype(np.float32)
        X = np.zeros((m, d), dtype=np.float32)
        X[:, :rank] = Z
        X += sigma_noise * rng.standard_normal((m, d)).astype(np.float32)
        return X
    K_cal = make(n_cal)
    K     = make(n)
    V     = make(n)
    Q     = make(64)
    return K, V, Q, K_cal


REGIMES = {
    "random":           lambda n, d, n_cal, seed: _make_random(n, d, n_cal, seed),
    "lowrank_r4":       lambda n, d, n_cal, seed: gaussian_lowrank(n, d, 4,  n_cal=n_cal, seed=seed),
    "lowrank_r4_exp":   lambda n, d, n_cal, seed: gaussian_lowrank(n, d, 4,  n_cal=n_cal, seed=seed, lam_decay="exp"),
    "lowrank_r8_exp":   lambda n, d, n_cal, seed: gaussian_lowrank(n, d, 8,  n_cal=n_cal, seed=seed, lam_decay="exp"),
    "lowrank_r16":      lambda n, d, n_cal, seed: gaussian_lowrank(n, d, 16, n_cal=n_cal, seed=seed),
    "lowrank_aligned":  lambda n, d, n_cal, seed: _make_lowrank_aligned(n, d, 8, 0.05, n_cal, seed),
    "fattail_nu3":      lambda n, d, n_cal, seed: student_rotated(n, d, 4, nu=3.0, n_cal=n_cal, seed=seed),
    "fattail_nu15":     lambda n, d, n_cal, seed: student_rotated(n, d, 4, nu=1.5, n_cal=n_cal, seed=seed),
    "misalign_0":       lambda n, d, n_cal, seed: misaligned_kv(n, d, 4, theta=0.0,       n_cal=n_cal, seed=seed),
    "misalign_90":      lambda n, d, n_cal, seed: misaligned_kv(n, d, 4, theta=np.pi/2,   n_cal=n_cal, seed=seed),
    "twopop":           lambda n, d, n_cal, seed: two_population(n, d, rank_1=4, rank_2=12, n_cal=n_cal, seed=seed),
}


# ═══════════════════════════════════════════════════════════════════════════════
# 6.  MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def print_summary(all_df: pd.DataFrame):
    all_df = all_df.copy()
    all_df["dirK"]       = 1 - all_df["ptcosine_K"]
    all_df["dirV"]       = 1 - all_df["ptcosine_V"]
    all_df["dirT"]       = 1 - all_df["cosine"]
    all_df["budget_eff"] = all_df["budget"]   # QJL replaces 1 MSE bit, not additive

    g = all_df.groupby(["regime", "scheme", "budget_eff"])

    for metric, label in [
        ("ptrelMSE_K", "K  relMSE"),
        ("ptrelMSE_V", "V  relMSE"),
        ("kl_sm",      "SM KL-div"),
        ("relMSE",     "T  relMSE"),
        ("dirT",       "T  1-cos "),
    ]:
        print(f"\n{'='*64}")
        print(f"SUMMARY — {label}  (lower is better)")
        print(f"{'='*64}")
        pivot = g[metric].mean().unstack("budget_eff")
        print(pivot.to_string())


def main():
    parser = argparse.ArgumentParser(description="TurboQuant CPU prototype")
    parser.add_argument("--regime",   nargs="+", default=list(REGIMES.keys()),
                        choices=list(REGIMES.keys()))
    parser.add_argument("--budget",   type=int, nargs="+", default=[2, 3, 4, 5])
    parser.add_argument("--n_tokens", type=int, default=4096)
    parser.add_argument("--n_cal",    type=int, default=512)
    parser.add_argument("--d_h",      type=int, default=128)
    parser.add_argument("--seed",     type=int, default=42)
    parser.add_argument("--out_dir",  default=".")
    parser.add_argument("--quiet",    action="store_true")
    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    all_dfs = []

    for name in args.regime:
        print(f"\n{'='*64}")
        print(f"Regime: {name}")
        print(f"{'='*64}")

        fn = REGIMES[name]
        K, V, Q, K_cal = fn(args.n_tokens, args.d_h, args.n_cal, args.seed)

        calib = calibrate(K_cal)
        diag  = beta_diagnostic(K_cal, calib)
        print(f"  d_eff={calib['d_eff']}  "
              f"Beta KS={diag['ks_stat']:.3f}  KL={diag['kl_div']:.4f}")

        df = run_turbo_experiment(
            K, V, Q, K_cal,
            budgets=args.budget,
            verbose=not args.quiet,
        )
        df["regime"]  = name
        df["d_eff"]   = calib["d_eff"]
        df["beta_ks"] = diag["ks_stat"]
        df["beta_kl"] = diag["kl_div"]

        out_path = os.path.join(args.out_dir, f"metrics_tq_{name}.csv")
        df.to_csv(out_path, index=False)
        print(f"  → {out_path}")
        all_dfs.append(df)

    all_df = pd.concat(all_dfs, ignore_index=True)
    combined = os.path.join(args.out_dir, "metrics_tq_all.csv")
    all_df.to_csv(combined, index=False)
    print(f"\nCombined: {combined}")

    print_summary(all_df)


if __name__ == "__main__":
    main()
