"""
sq_codec.py — SpectralQuant codec (corrected design)
=====================================================

Design principles (confirmed from reference implementation):
  1. Separate U_K and U_V — calibrated independently from K_cal and V_cal
  2. QJL is a score estimator in Z space, NOT a reconstruction corrector
  3. Tail contributes an exact inner product in Z space
  4. V is decoded by dequantize → unrotate (no QJL)
  5. m projections with m ≥ d_eff for variance reduction

Score computation:
  q_rot   = Q @ U_K                           # rotate query to K's Z space
  sem     = QJL(q_rot[:d_eff], Z_k[:d_eff])   # unbiased estimate, m bits per key
  tail    = q_rot[d_eff:] @ Z_k_hat[d_eff:].T  # exact tail (dequantized)
  score   = sem + tail

V decode:
  Z_v_hat = dequantize(Z_v)                   # semantic + tail
  V_hat   = Z_v_hat @ U_V.T                   # rotate back to X space

This matches: Zandieh et al. 2024 (QJL) + reference SpectralQuant implementation.
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Optional, List
from .qjl import make_sign_matrix, qjl_encode_batch


# ── calibration ───────────────────────────────────────────────────────────────

def calibrate(X_cal: np.ndarray, max_d_eff: int = 32,
              gap_threshold: float = 10.0) -> dict:
    """
    Compute eigenbasis from calibration vectors.
    Call separately for K_cal and V_cal to get U_K and U_V.

    Returns dict: U, sig, d_eff, U_eff (d_h × d_eff), sig_eff

    gap_threshold: reject dim k if sig[k-1]/sig[k] > threshold (spectral gap).
    max_d_eff:     hard cap applied before gap check.
    """
    N, d_h = X_cal.shape
    Sigma = (X_cal.T @ X_cal) / N
    sig, U = np.linalg.eigh(Sigma)
    idx = np.argsort(sig)[::-1]
    sig, U = sig[idx], U[:, idx]
    sig = np.maximum(sig, 0.0)

    # Participation ratio estimate, then cap
    pr_est = min(participation_ratio(sig), max_d_eff)

    # Use max_d_eff (known regime rank) as the target; scan DOWN only to trim
    # a spurious dim (large gap). Corrects PR underestimation for steep spectra.
    d_eff = min(max_d_eff, len(sig))
    for k in range(1, d_eff):
        if sig[k] <= 1e-9:
            d_eff = k
            break
        if sig[k-1] / sig[k] > gap_threshold:
            d_eff = k
            break

    return dict(U=U, sig=sig, d_eff=d_eff,
                U_eff=U[:, :d_eff], sig_eff=sig[:d_eff])


def participation_ratio(sig: np.ndarray) -> int:
    sig = sig[sig > 0]
    if len(sig) == 0:
        return 1
    d_eff = (sig.sum() ** 2) / (sig ** 2).sum()
    return int(np.clip(round(d_eff), 1, len(sig)))


# ── water-filling ─────────────────────────────────────────────────────────────

def water_fill(sig: np.ndarray, budget_bits: int, min_bits: int = 2) -> np.ndarray:
    """Greedy integer water-filling. Returns bits per semantic dim."""
    d = len(sig)
    b = np.full(d, min_bits, dtype=int)
    dist = sig.copy().astype(float)
    for i in range(d):
        dist[i] = sig[i] * (4.0 ** (-min_bits))
    remaining = budget_bits - d * min_bits
    for _ in range(max(0, remaining)):
        i_star = int(np.argmax(dist))
        b[i_star] += 1
        dist[i_star] = sig[i_star] * (4.0 ** (-b[i_star]))
    return b


def water_fill_uniform(d_eff: int, b_per_dim: int) -> np.ndarray:
    return np.full(d_eff, b_per_dim, dtype=int)


# ── Lloyd-Max scalar quantizer ────────────────────────────────────────────────

def lloyd_max_fit(samples: np.ndarray, n_levels: int,
                  max_iter: int = 200, tol: float = 1e-8) -> tuple:
    if n_levels == 1:
        return np.array([-np.inf, np.inf]), np.array([float(np.mean(samples))])
    probs = np.linspace(0, 100, n_levels + 2)[1:-1]
    centroids = np.percentile(samples, probs)
    centroids = np.unique(centroids)
    if len(centroids) < n_levels:
        span = max(np.std(samples) * 4, 1e-6)
        centroids = np.linspace(np.mean(samples) - span/2,
                                np.mean(samples) + span/2, n_levels)
    for _ in range(max_iter):
        bounds_inner = 0.5 * (centroids[:-1] + centroids[1:])
        boundaries = np.concatenate([[-np.inf], bounds_inner, [np.inf]])
        new_centroids = np.empty(n_levels)
        for k in range(n_levels):
            mask = (samples >= boundaries[k]) & (samples < boundaries[k + 1])
            new_centroids[k] = samples[mask].mean() if mask.any() else centroids[k]
        if np.max(np.abs(new_centroids - centroids)) < tol:
            centroids = new_centroids
            break
        centroids = new_centroids
    boundaries = np.concatenate([[-np.inf],
                                  0.5 * (centroids[:-1] + centroids[1:]),
                                  [np.inf]])
    return boundaries, centroids


def lloyd_max_encode(x: np.ndarray, boundaries: np.ndarray) -> np.ndarray:
    return np.searchsorted(boundaries[1:-1], x).astype(np.int32)


def lloyd_max_decode(indices: np.ndarray, centroids: np.ndarray) -> np.ndarray:
    return centroids[np.clip(indices, 0, len(centroids) - 1)]


# ── SQ codebook ───────────────────────────────────────────────────────────────

@dataclass
class SQCodebook:
    """
    Per-head SQ codebook. Holds separate U_K, U_V and all quantizers.

    Calibrated from K_cal (for K) and V_cal (for V) independently.
    """
    # K basis
    U_K:     np.ndarray          # (d_h, d_h) — full eigenbasis for K
    sig_K:   np.ndarray          # (d_h,) eigenvalues
    d_eff_K: int                 # participation ratio for K

    # V basis
    U_V:     np.ndarray          # (d_h, d_h)
    sig_V:   np.ndarray          # (d_h,)
    d_eff_V: int

    # bit allocation
    b_sem_K: np.ndarray          # (d_eff_K,) bits per semantic dim, K
    b_sem_V: np.ndarray          # (d_eff_V,) bits per semantic dim, V
    b_tail:  int                 # bits for tail dims (shared)

    # semantic codebooks (one per dim)
    sem_bounds_K:    List        # list of boundary arrays
    sem_centroids_K: List
    sem_bounds_V:    List
    sem_centroids_V: List

    # tail codebooks (shared across dims)
    tail_bounds_K:    np.ndarray
    tail_centroids_K: np.ndarray
    tail_bounds_V:    np.ndarray
    tail_centroids_V: np.ndarray


def fit_codebook(K_cal: np.ndarray, V_cal: np.ndarray,
                 b_target: int, b_tail: int = 2,
                 uniform: bool = True,
                 max_d_eff: int = 32,
                 gap_threshold: float = 10.0) -> SQCodebook:
    """
    Calibrate and fit a full SQCodebook from K_cal and V_cal.

    Parameters
    ----------
    K_cal, V_cal  : (N_cal, d_h) calibration vectors
    b_target      : target bits/dim (nominal budget)
    b_tail        : bits for tail dims
    uniform       : True=uniform allocation, False=water-filling
    max_d_eff     : hard cap on d_eff (pass known regime rank for clean tests)
    gap_threshold : spectral gap ratio to trim spurious dimensions
    """
    cal_K = calibrate(K_cal, max_d_eff=max_d_eff, gap_threshold=gap_threshold)
    cal_V = calibrate(V_cal, max_d_eff=max_d_eff, gap_threshold=gap_threshold)

    d_eff_K = cal_K["d_eff"]
    d_eff_V = cal_V["d_eff"]

    # Bit allocation
    budget_K = b_target * d_eff_K
    budget_V = b_target * d_eff_V

    if uniform:
        b_sem_K = water_fill_uniform(d_eff_K, b_target)
        b_sem_V = water_fill_uniform(d_eff_V, b_target)
    else:
        b_sem_K = water_fill(cal_K["sig_eff"], budget_K, min_bits=b_tail)
        b_sem_V = water_fill(cal_V["sig_eff"], budget_V, min_bits=b_tail)

    # Fit semantic codebooks from rotated calibration data
    Z_K = K_cal @ cal_K["U_eff"]   # (N_cal, d_eff_K)
    Z_V = V_cal @ cal_V["U_eff"]   # (N_cal, d_eff_V)

    def fit_sem(Z, b_sem):
        bounds_list, cent_list = [], []
        for i, b in enumerate(b_sem):
            n_levels = max(1, 2 ** int(b))
            bnd, cen = lloyd_max_fit(Z[:, i], n_levels)
            bounds_list.append(bnd); cent_list.append(cen)
        return bounds_list, cent_list

    sem_bounds_K, sem_centroids_K = fit_sem(Z_K, b_sem_K)
    sem_bounds_V, sem_centroids_V = fit_sem(Z_V, b_sem_V)

    # Fit tail codebooks (shared across all tail dims)
    U_tail_K = cal_K["U"][:, d_eff_K:]
    U_tail_V = cal_V["U"][:, d_eff_V:]

    def fit_tail(X_cal, U_tail, b_tail):
        if b_tail > 0 and U_tail.shape[1] > 0:
            tail = X_cal @ U_tail
            return lloyd_max_fit(tail.ravel(), 2 ** b_tail)
        return np.array([-np.inf, np.inf]), np.array([0.0])

    tb_K, tc_K = fit_tail(K_cal, U_tail_K, b_tail)
    tb_V, tc_V = fit_tail(V_cal, U_tail_V, b_tail)

    return SQCodebook(
        U_K=cal_K["U"], sig_K=cal_K["sig"], d_eff_K=d_eff_K,
        U_V=cal_V["U"], sig_V=cal_V["sig"], d_eff_V=d_eff_V,
        b_sem_K=b_sem_K, b_sem_V=b_sem_V, b_tail=b_tail,
        sem_bounds_K=sem_bounds_K, sem_centroids_K=sem_centroids_K,
        sem_bounds_V=sem_bounds_V, sem_centroids_V=sem_centroids_V,
        tail_bounds_K=tb_K, tail_centroids_K=tc_K,
        tail_bounds_V=tb_V, tail_centroids_V=tc_V,
    )


# ── encode / decode ───────────────────────────────────────────────────────────

@dataclass
class SQEncoded:
    """Compressed representation of K or V tokens."""
    sem_idx:    np.ndarray          # (S, d_eff) quantized indices in Z semantic space
    tail_idx:   np.ndarray          # (S, d-d_eff) quantized indices in Z tail space
    Z_tail_hat: np.ndarray          # (S, d-d_eff) dequantized tail (for exact tail score)
    d_eff:      int

    # QJL fields — populated only when use_qjl=True in sq_encode_K
    sign_bits:   Optional[np.ndarray] = None   # (S, m) ±1 — 1-bit sketch of Z_sem residual
    r_norms_sem: Optional[np.ndarray] = None   # (S,)  — ||Z_sem - Z_sem_hat||


def sq_encode_K(K: np.ndarray, cb: SQCodebook,
                S_qjl: Optional[np.ndarray] = None) -> SQEncoded:
    """
    Rotate K → Z_K, quantize semantic and tail dims.

    Parameters
    ----------
    K      : (S, d_h) key vectors
    cb     : SQCodebook
    S_qjl  : (m, d_eff) sign matrix for 1-bit QJL sketch of Z_sem residual.
             If None, no QJL sketch is computed (SQU-KV / SQW-KV mode).

    If S_qjl is provided, computes:
      residual   = Z_sem - Z_sem_hat             in Z space
      sign_bits  = sign(residual @ S_qjl.T)      (S, m) — m bits per token
      r_norms_sem = ||residual||                  (S,)
    """
    d_eff  = cb.d_eff_K
    U_eff  = cb.U_K[:, :d_eff]
    U_tail = cb.U_K[:, d_eff:]

    Z_sem  = K @ U_eff    # (S, d_eff)
    Z_tail = K @ U_tail   # (S, d-d_eff)

    # Quantize semantic dims
    sem_idx = np.stack([
        lloyd_max_encode(Z_sem[:, i], cb.sem_bounds_K[i])
        for i in range(d_eff)
    ], axis=1)

    # Quantize tail dims
    tail_idx   = lloyd_max_encode(Z_tail.ravel(), cb.tail_bounds_K).reshape(Z_tail.shape)
    Z_tail_hat = lloyd_max_decode(tail_idx, cb.tail_centroids_K)

    # Optional 1-bit QJL sketch of Z_sem residual
    sign_bits = r_norms_sem = None
    if S_qjl is not None:
        Z_sem_hat = np.stack([
            lloyd_max_decode(sem_idx[:, i], cb.sem_centroids_K[i])
            for i in range(d_eff)
        ], axis=1)
        residual    = Z_sem - Z_sem_hat                 # (S, d_eff)
        r_norms_sem = np.linalg.norm(residual, axis=1)  # (S,) — per-token
        sign_bits   = np.sign(residual @ S_qjl.T)       # (S, m)
        sign_bits[sign_bits == 0] = 1.0

    return SQEncoded(sem_idx=sem_idx, tail_idx=tail_idx,
                     Z_tail_hat=Z_tail_hat, d_eff=d_eff,
                     sign_bits=sign_bits, r_norms_sem=r_norms_sem)


def sq_sigma_scale_K(cb: SQCodebook) -> float:
    """Expected residual norm from calibration: sqrt(sum_i sigma_i * 4^{-b_i}).
    Used as deterministic substitute for per-token r_norms_sem."""
    sig  = cb.sig_K[:cb.d_eff_K]
    b    = cb.b_sem_K
    return float(np.sqrt(np.sum(sig * 4.0 ** (-b.astype(float)))))


def sq_sigma_scale_V(cb: SQCodebook) -> float:
    """Same for V."""
    sig  = cb.sig_V[:cb.d_eff_V]
    b    = cb.b_sem_V
    return float(np.sqrt(np.sum(sig * 4.0 ** (-b.astype(float)))))


def sq_encode_V(V: np.ndarray, cb: SQCodebook,
                S_qjl: Optional[np.ndarray] = None) -> SQEncoded:
    """
    Rotate V → Z_V, quantize semantic and tail dims.

    If S_qjl provided (m, d_eff_V), computes 1-bit sketch of Z_sem residual
    for reconstruction correction at decode time.
    """
    d_eff  = cb.d_eff_V
    U_eff  = cb.U_V[:, :d_eff]
    U_tail = cb.U_V[:, d_eff:]

    Z_sem  = V @ U_eff
    Z_tail = V @ U_tail

    sem_idx = np.stack([
        lloyd_max_encode(Z_sem[:, i], cb.sem_bounds_V[i])
        for i in range(d_eff)
    ], axis=1)

    tail_idx   = lloyd_max_encode(Z_tail.ravel(), cb.tail_bounds_V).reshape(Z_tail.shape)
    Z_tail_hat = lloyd_max_decode(tail_idx, cb.tail_centroids_V)

    # Optional 1-bit QJL sketch of Z_sem residual for V reconstruction
    sign_bits = r_norms_sem = None
    if S_qjl is not None:
        Z_sem_hat = np.stack([
            lloyd_max_decode(sem_idx[:, i], cb.sem_centroids_V[i])
            for i in range(d_eff)
        ], axis=1)
        residual    = Z_sem - Z_sem_hat
        r_norms_sem = np.linalg.norm(residual, axis=1)
        sign_bits   = np.sign(residual @ S_qjl.T)
        sign_bits[sign_bits == 0] = 1.0

    return SQEncoded(sem_idx=sem_idx, tail_idx=tail_idx,
                     Z_tail_hat=Z_tail_hat, d_eff=d_eff,
                     sign_bits=sign_bits, r_norms_sem=r_norms_sem)


def sq_decode_V(enc: SQEncoded, cb: SQCodebook,
                S_qjl: Optional[np.ndarray] = None,
                sigma_scale: Optional[float] = None) -> np.ndarray:
    """
    Dequantize V and rotate back to X space.

    Without QJL (S_qjl=None or enc.sign_bits is None):
      V_hat = Z_sem_hat @ U_eff.T + Z_tail_hat @ U_tail.T

    With 1-bit QJL reconstruction correction:
      correction = sqrt(π/2)/m * r_norms * sign_bits @ S_qjl   (in Z space)
      V_hat = (Z_sem_hat + correction) @ U_eff.T + Z_tail_hat @ U_tail.T
    """
    d_eff  = cb.d_eff_V
    U_eff  = cb.U_V[:, :d_eff]
    U_tail = cb.U_V[:, d_eff:]

    Z_sem_hat = np.stack([
        lloyd_max_decode(enc.sem_idx[:, i], cb.sem_centroids_V[i])
        for i in range(d_eff)
    ], axis=1)

    if S_qjl is not None and enc.sign_bits is not None:
        m     = S_qjl.shape[0]
        scale = np.sqrt(np.pi / 2.0) / m
        if sigma_scale is not None:
            correction = scale * sigma_scale * (enc.sign_bits @ S_qjl)
        else:
            correction = scale * enc.r_norms_sem[:, np.newaxis] * (enc.sign_bits @ S_qjl)
        Z_sem_hat = Z_sem_hat + correction

    return Z_sem_hat @ U_eff.T + enc.Z_tail_hat @ U_tail.T


def sq_decode_K_for_metrics(enc: SQEncoded, cb: SQCodebook) -> np.ndarray:
    """
    Dequantize K and rotate back — used only for pt-metrics.
    NOT used for scoring (scoring uses QJL in Z space).
    """
    d_eff = cb.d_eff_K
    U_eff  = cb.U_K[:, :d_eff]
    U_tail = cb.U_K[:, d_eff:]

    Z_sem_hat = np.stack([
        lloyd_max_decode(enc.sem_idx[:, i], cb.sem_centroids_K[i])
        for i in range(d_eff)
    ], axis=1)

    return Z_sem_hat @ U_eff.T + enc.Z_tail_hat @ U_tail.T


# ── attention score ───────────────────────────────────────────────────────────

def sq_attention_score(Q: np.ndarray, enc_K: SQEncoded, cb: SQCodebook,
                       S_qjl: Optional[np.ndarray] = None,
                       sigma_scale: Optional[float] = None) -> np.ndarray:
    """
    Compute attention scores in Z_K space.

    Without QJL (S_qjl=None or enc_K.sign_bits is None):
      score = Q_rot_sem @ Z_sem_hat.T + Q_rot_tail @ Z_tail_hat.T

    With 1-bit QJL (enc_K.sign_bits must be pre-computed by sq_encode_K):
      Asymmetric estimator — same design as TQ-QKV but in Z_K space:
        q_sketch   = Q_rot_sem @ S_qjl.T               # (Nq, m)
        correction = sqrt(π/2)/m * r_norms * q_sketch @ sign_bits.T
        score      = Q_rot_sem @ Z_sem_hat.T            # MSE term
                   + correction                          # QJL correction
                   + Q_rot_tail @ Z_tail_hat.T          # exact tail

    Parameters
    ----------
    Q      : (Nq, d_h) queries
    enc_K  : output of sq_encode_K (with S_qjl if QJL is wanted)
    cb     : SQCodebook
    S_qjl  : (m, d_eff) sign matrix — must be the same S used in sq_encode_K

    Returns
    -------
    scores : (Nq, S) attention logits
    """
    d_eff  = cb.d_eff_K
    U_eff  = cb.U_K[:, :d_eff]
    U_tail = cb.U_K[:, d_eff:]

    Q_rot_sem  = Q @ U_eff    # (Nq, d_eff)
    Q_rot_tail = Q @ U_tail   # (Nq, d-d_eff)

    # MSE semantic score (always computed)
    Z_sem_hat = np.stack([
        lloyd_max_decode(enc_K.sem_idx[:, i], cb.sem_centroids_K[i])
        for i in range(d_eff)
    ], axis=1)                              # (S, d_eff)

    sem_score  = Q_rot_sem  @ Z_sem_hat.T  # (Nq, S)
    tail_score = Q_rot_tail @ enc_K.Z_tail_hat.T  # (Nq, S)

    if S_qjl is not None and enc_K.sign_bits is not None:
        m     = S_qjl.shape[0]
        scale = np.sqrt(np.pi / 2.0) / m
        q_sketch = Q_rot_sem @ S_qjl.T   # (Nq, m)
        # Use sigma_scale (deterministic) or per-token r_norms_sem
        if sigma_scale is not None:
            # Deterministic: same expected scale for every token
            correction = scale * sigma_scale * (q_sketch @ enc_K.sign_bits.T)
        else:
            # Per-token: actual residual norm
            correction = scale * (q_sketch @ enc_K.sign_bits.T) * enc_K.r_norms_sem[np.newaxis, :]
        sem_score = sem_score + correction

    return sem_score + tail_score
