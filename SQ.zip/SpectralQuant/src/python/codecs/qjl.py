"""
qjl.py — Johnson-Lindenstrauss residual sketch
================================================
Two variants, both satisfying the JL guarantee:

  Variant A — RHT (Randomized Hadamard Transform):
    S is a d-vector of ±1 signs.
    Encode: sign(WHT_norm(e * S))    — O(d log d), integer ±1 arithmetic
    Decode: WHT_norm(sign_bits) * S  — same cost

  Variant B — Full random projection:
    S is a (m × d) matrix of ±1 entries, m ≤ d.
    Encode: sign(e @ S.T)            — O(m*d), inner products, m bits per token
    Decode: sign_bits @ S            — same cost
    Scale:  sqrt(π/2) / m            — unbiased for any m

    m = d  → square matrix, m bits = d bits (original design)
    m < d  → rectangular, fewer bits but higher variance
    m >> d_eff, m < d → SQ selective QJL sweet spot (e.g. m=64, d_eff=8, d=128)

Both are selected automatically by S.ndim:
    S.ndim == 1       →  Variant A (RHT),  m = d implicitly
    S.ndim == 2 (m,d) →  Variant B (full), m from S.shape[0]

Scale: sqrt(π/2) / m   (unbiased estimator, Zandieh et al. 2024)

Constructors:
    make_sign_vector(d)      →  Variant A: (d,)   RHT, m=d
    make_sign_matrix(d, m=m) →  Variant B: (m, d) Full, m projections

Both Python and HIP implement both variants identically.
The caller selects by passing the appropriate S.
"""

import numpy as np
from typing import Optional


# ── constructors ──────────────────────────────────────────────────────────────

def make_sign_vector(d: int, rng: Optional[np.random.Generator] = None) -> np.ndarray:
    """Variant A: d-vector of ±1 for RHT-based QJL. O(d log d)."""
    if rng is None:
        rng = np.random.default_rng(0)
    return rng.choice([-1.0, 1.0], size=d).astype(np.float64)


def make_sign_matrix(d: int, rng: Optional[np.random.Generator] = None,
                     m: Optional[int] = None) -> np.ndarray:
    """Variant B: (m × d) matrix of ±1 for full-projection QJL.
    m=None defaults to m=d (square, O(d²)).
    m < d gives a rectangular projection with m bits per token — lower variance
    than m=d_eff but more bits than 1-bit-per-dim (useful when d_eff << m < d).
    """
    if rng is None:
        rng = np.random.default_rng(0)
    if m is None:
        m = d
    return rng.choice([-1.0, 1.0], size=(m, d)).astype(np.float64)


# ── internal WHT ──────────────────────────────────────────────────────────────

def _wht_norm(x: np.ndarray) -> np.ndarray:
    """Normalized WHT of 1D array. d must be power of 2."""
    x = x.astype(np.float64).copy()
    d = len(x)
    h = 1
    while h < d:
        x_r = x.reshape(-1, h * 2)
        left  = x_r[:, :h] + x_r[:, h:]
        right = x_r[:, :h] - x_r[:, h:]
        x = np.concatenate([left, right], axis=1).reshape(-1)
        h *= 2
    return x / np.sqrt(d)


def _wht_norm_batch(X: np.ndarray) -> np.ndarray:
    """Normalized WHT for batch of row vectors. Shape (N, d), d power of 2."""
    X = X.astype(np.float64).copy()
    N, d = X.shape
    h = 1
    while h < d:
        X = X.reshape(N, -1, h * 2)
        left  = X[:, :, :h] + X[:, :, h:]
        right = X[:, :, :h] - X[:, :, h:]
        X = np.concatenate([left, right], axis=2).reshape(N, d)
        h *= 2
    return X / np.sqrt(d)


# ── encode / decode (single vector) ──────────────────────────────────────────

def qjl_encode(residual: np.ndarray, S: np.ndarray) -> tuple[np.ndarray, float]:
    """
    Encode residual. S selects variant:
        S.ndim == 1      →  RHT:  sign(WHT_norm(residual * S))   m=d bits
        S.ndim == 2 (m,d)→  Full: sign(residual @ S.T)           m bits
    Returns (sign_bits (m,), r_norm).
    """
    residual = np.asarray(residual, dtype=np.float64).ravel()
    r_norm = float(np.linalg.norm(residual))
    if S.ndim == 1:
        projected = _wht_norm(residual * S)
    else:
        projected = residual @ S.T      # (m,)
    sign_bits = np.where(projected >= 0, 1.0, -1.0)
    return sign_bits, r_norm


def qjl_decode(sign_bits: np.ndarray, S: np.ndarray, r_norm: float) -> np.ndarray:
    """
    Decode QJL sketch. S selects variant:
        S.ndim == 1      →  RHT:  WHT_norm(sign_bits) * S   scale = sqrt(π/2)/d
        S.ndim == 2 (m,d)→  Full: sign_bits @ S             scale = sqrt(π/2)/m
    Unbiased estimator of the residual vector for any m.
    """
    sign_bits = np.asarray(sign_bits, dtype=np.float64).ravel()
    if S.ndim == 1:
        m = len(sign_bits)   # m == d for RHT
        scale = np.sqrt(np.pi / 2.0) / m
        correction = _wht_norm(sign_bits) * S
    else:
        m = S.shape[0]       # m rows, d cols
        scale = np.sqrt(np.pi / 2.0) / m
        correction = sign_bits @ S      # (m,) @ (m, d) → (d,)
    return scale * r_norm * correction


# ── encode / decode (batch) ───────────────────────────────────────────────────

def qjl_encode_batch(E: np.ndarray, S: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """
    Batch encode. E: (N, d).
    Returns (sign_bits (N, m), r_norms (N,)) where m=d for RHT, m=S.shape[0] for Full.
    S.ndim == 1      → RHT,  m=d
    S.ndim == 2 (m,d)→ Full, m projections
    """
    E = np.asarray(E, dtype=np.float64)
    if E.ndim == 1:
        E = E[np.newaxis, :]
    r_norms = np.linalg.norm(E, axis=1)
    if S.ndim == 1:
        projected = _wht_norm_batch(E * S[np.newaxis, :])   # (N, d)
    else:
        projected = E @ S.T                                   # (N, m)
    sign_bits = np.where(projected >= 0, 1.0, -1.0)
    return sign_bits, r_norms


def qjl_decode_batch(sign_bits: np.ndarray, S: np.ndarray,
                     r_norms: np.ndarray) -> np.ndarray:
    """
    Batch decode. sign_bits: (N, m), r_norms: (N,).
    S.ndim == 1      → RHT, scale = sqrt(π/2)/d
    S.ndim == 2 (m,d)→ Full, scale = sqrt(π/2)/m  (unbiased for any m)
    """
    sign_bits = np.asarray(sign_bits, dtype=np.float64)
    if sign_bits.ndim == 1:
        sign_bits = sign_bits[np.newaxis, :]
    if S.ndim == 1:
        m = sign_bits.shape[1]      # m == d for RHT
        scale = np.sqrt(np.pi / 2.0) / m
        corrections = _wht_norm_batch(sign_bits) * S[np.newaxis, :]  # (N, d)
    else:
        m = S.shape[0]
        scale = np.sqrt(np.pi / 2.0) / m
        corrections = sign_bits @ S                                    # (N, d)
    return scale * r_norms[:, np.newaxis] * corrections
