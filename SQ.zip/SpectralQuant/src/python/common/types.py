"""
types.py — shared dataclasses for TQ and SQ codecs.
Matches the C++ structs in src/hip/codecs/.
"""
from dataclasses import dataclass, field
import numpy as np


@dataclass
class EncodeResult:
    """Output of any codec encode operation."""
    pack:      np.ndarray  # (N, d) quantized indices, dtype uint8
    norms:     np.ndarray  # (N,)  per-token L2 norms
    r_norms:   np.ndarray  # (N,)  per-token residual norms (QJL only, else zeros)
    sign_bits: np.ndarray  # (N, d) QJL sign bits in {-1,+1} (QJL only, else zeros)


@dataclass
class TQCodebook:
    """TurboQuant codebook for one head (d, n_bits)."""
    d:          int
    n_bits:     int
    centroids:  np.ndarray   # (2^n_bits,)     Lloyd-Max levels
    boundaries: np.ndarray   # (2^n_bits + 1,) Lloyd-Max boundaries
    wht_signs:  np.ndarray   # (d,)            WHT randomization signs in {-1,+1}


@dataclass
class SQCodebook:
    """SpectralQuant codebook for one head."""
    d:        int
    d_eff:    int
    b_sem:    int              # bits per semantic dim
    b_tail:   int              # bits for tail dims (fixed)
    U:        np.ndarray       # (d, d_eff) eigenbasis
    lvl_sem:  list             # list of d_eff arrays, each (2^b_sem,)
    bnd_sem:  list             # list of d_eff boundary arrays
    lvl_tail: np.ndarray       # (2^b_tail,)
    bnd_tail: np.ndarray       # (2^b_tail + 1,)
