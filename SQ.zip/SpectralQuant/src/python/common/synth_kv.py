"""
synth_kv.py — Synthetic KV generator suite for SpectralQuant assumption testing
=================================================================================

Each generator returns (K, V, Q, K_cal) with shape (n_tokens, d_h) / (n_cal, d_h).

Generators
----------
gaussian_lowrank    — K from low-rank Gaussian subspace + small noise
                      Stress-tests: eigenbasis recovery, spectral gap
                      Closes turbo_analysis.pdf histogram paradox loop

student_rotated     — Gaussian eigenbasis structure, but per-dim marginals
                      are Student-t(nu) after rotation → non-Gaussian tails
                      Stress-tests: water-filling Gaussian assumption

misaligned_kv       — K and V live in different subspaces (rotation angle theta)
                      theta=0: same subspace (paper's default)
                      theta=pi/2: orthogonal subspaces
                      Stress-tests: V eigenbasis reuse from K calibration

two_population      — tokens drawn from two Gaussian clusters with different
                      spectral gaps (deff_1 ≠ deff_2)
                      Stress-tests: calibration stability across token types

Usage
-----
    from synth_kv import gaussian_lowrank, student_rotated, misaligned_kv

    K, V, Q, K_cal = gaussian_lowrank(n=4096, d=128, rank=4, n_cal=512)
"""

import numpy as np
from scipy.linalg import orth

# ═══════════════════════════════════════════════════════════════════════════════
# helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _make_query(K, rng, n_q=64):
    """Draw query vectors from the same distribution as K (simple: subsample)."""
    idx = rng.choice(len(K), size=min(n_q, len(K)), replace=False)
    return K[idx].copy()


def _make_subspace(d, rank, rng):
    """Random orthonormal subspace of dimension rank in R^d."""
    raw = rng.standard_normal((d, rank))
    return orth(raw)   # (d, rank)


def _sample_from_subspace(n, U, lam, rng, sigma_noise=0.0):
    """
    Draw n vectors from subspace U with variance profile lam.

    X = Z @ U^T + noise,   Z_i ~ N(0, lam_i)
    """
    rank = U.shape[1]
    Z = rng.standard_normal((n, rank)) * np.sqrt(lam)[np.newaxis, :]
    X = Z @ U.T
    if sigma_noise > 0:
        X += sigma_noise * rng.standard_normal(X.shape)
    return X.astype(np.float32)


# ═══════════════════════════════════════════════════════════════════════════════
# 1.  Gaussian low-rank
# ═══════════════════════════════════════════════════════════════════════════════

def gaussian_lowrank(n: int, d: int, rank: int, n_cal: int = 512,
                     sigma_noise: float = 0.01,
                     lam_decay: str = "sharp",
                     seed: int = 42) -> tuple:
    """
    K from rank-dimensional Gaussian subspace + isotropic noise.

    Parameters
    ----------
    rank       : effective rank of K's signal subspace
    sigma_noise: isotropic noise std (adds full-rank component to blur sharp gap)
    lam_decay  : 'sharp'  — all signal dims equal variance (hardest spectral gap)
                 'exp'    — exponential decay lambda_i = exp(-i*0.5)
                 'linear' — lambda_i = 1 - i/(rank+1)

    Notes
    -----
    This is the direct analogue of the lowrank mode in pquant_hip_metrics.hip.
    Expected result: SpectralQuant dominates TurboQuant because eigenbasis
    exactly captures the low-rank structure that WHT's marginal guarantee misses.
    """
    rng = np.random.default_rng(seed)
    U_K = _make_subspace(d, rank, rng)

    if lam_decay == "sharp":
        lam = np.ones(rank)
    elif lam_decay == "exp":
        lam = np.exp(-np.arange(rank) * 0.5)
    else:  # linear
        lam = 1.0 - np.arange(rank) / (rank + 1)
    lam = lam / lam.max()   # normalise peak to 1

    K_cal = _sample_from_subspace(n_cal, U_K, lam, rng, sigma_noise)
    K     = _sample_from_subspace(n,     U_K, lam, rng, sigma_noise)
    V     = _sample_from_subspace(n,     U_K, lam, rng, sigma_noise)
    Q     = _make_query(K, rng)

    return K, V, Q, K_cal


# ═══════════════════════════════════════════════════════════════════════════════
# 2.  Student-t rotated  (Gaussian structure, non-Gaussian marginals)
# ═══════════════════════════════════════════════════════════════════════════════

def student_rotated(n: int, d: int, rank: int, nu: float = 3.0,
                    n_cal: int = 512, sigma_noise: float = 0.01,
                    seed: int = 42) -> tuple:
    """
    K with Gaussian eigenbasis but Student-t(nu) marginals per semantic dim.

    Construction:
        - Calibrate eigenbasis from Gaussian K_cal (so U is correctly identified)
        - Test K drawn with t(nu) marginals in the rotated basis
        - SpectralQuant's water-filling assumes Gaussian → allocation error grows
          as nu → 1 (heavier tails)

    Parameters
    ----------
    nu : degrees of freedom.  nu→∞ is Gaussian.  nu=1 is Cauchy (extreme).
         nu < 3: variance undefined → water-fill allocation is badly miscalibrated.

    Expected result:
        - Beta diagnostic shows heavier tails than Beta(3/2, 3/2)
        - water-filling snr_err grows as nu decreases
        - Lloyd-Max codebook partially hedges (fits empirical marginal)
          but cannot fix wrong bit allocation
    """
    rng = np.random.default_rng(seed)
    U_K = _make_subspace(d, rank, rng)
    lam = np.exp(-np.arange(rank) * 0.5)
    lam /= lam.max()

    def sample_t_rotated(n_samp):
        # Draw t(nu) in rotated basis, scale by sqrt(lam)
        # scipy.stats not needed: t(nu) = N(0,1) / sqrt(Chi2(nu)/nu)
        z = rng.standard_normal((n_samp, rank))
        chi2 = rng.chisquare(nu, size=(n_samp, 1))
        t_samples = z / np.sqrt(chi2 / nu)
        t_scaled = t_samples * np.sqrt(lam)[np.newaxis, :]
        X = t_scaled @ U_K.T
        X += sigma_noise * rng.standard_normal(X.shape)
        return X.astype(np.float32)

    # Calibration is from Gaussian (so eigenbasis is correctly identified)
    K_cal = _sample_from_subspace(n_cal, U_K, lam, rng, sigma_noise)
    K     = sample_t_rotated(n)
    V     = sample_t_rotated(n)
    Q     = _make_query(K, rng)

    return K, V, Q, K_cal


# ═══════════════════════════════════════════════════════════════════════════════
# 3.  Misaligned K/V subspaces
# ═══════════════════════════════════════════════════════════════════════════════

def misaligned_kv(n: int, d: int, rank: int, theta: float = 0.0,
                  n_cal: int = 512, sigma_noise: float = 0.01,
                  seed: int = 42) -> tuple:
    """
    K and V live in different subspaces separated by angle theta.

    theta=0      : same subspace — V reuse of K's eigenbasis is exact
    theta=pi/4   : 45° rotation between subspaces
    theta=pi/2   : orthogonal subspaces — V reuse is maximally wrong

    Construction:
        U_K  = random orthonormal basis of dim rank
        U_V  = rotate(U_K, theta) in the plane spanned by U_K and a fresh direction

    Expected result:
        - At theta=0:   V reconstruction matches K quality
        - At theta=pi/2: V reconstruction degrades (K's eigenbasis is irrelevant for V)
        - Participation ratio of V in K's basis grows toward d_eff
        - Beta diagnostic for V shows variance mismatch after whitening

    Parameters
    ----------
    theta : rotation angle in radians between K and V subspaces
    """
    rng = np.random.default_rng(seed)
    lam = np.exp(-np.arange(rank) * 0.5)
    lam /= lam.max()

    U_K = _make_subspace(d, rank, rng)

    # Rotate U_K toward a fresh orthogonal direction by angle theta
    U_perp = _make_subspace(d, rank, rng)
    # Gram-Schmidt: make U_perp orthogonal to U_K column by column
    for j in range(rank):
        for k in range(rank):
            U_perp[:, j] -= np.dot(U_perp[:, j], U_K[:, k]) * U_K[:, k]
        norm = np.linalg.norm(U_perp[:, j])
        if norm > 1e-10:
            U_perp[:, j] /= norm

    # U_V = cos(theta) U_K + sin(theta) U_perp  (column-wise rotation)
    U_V = np.cos(theta) * U_K + np.sin(theta) * U_perp

    K_cal = _sample_from_subspace(n_cal, U_K, lam, rng, sigma_noise)
    K     = _sample_from_subspace(n,     U_K, lam, rng, sigma_noise)
    V     = _sample_from_subspace(n,     U_V, lam, rng, sigma_noise)
    Q     = _make_query(K, rng)

    return K, V, Q, K_cal


# ═══════════════════════════════════════════════════════════════════════════════
# 4.  Two-population mixture  (unstable spectral gap)
# ═══════════════════════════════════════════════════════════════════════════════

def two_population(n: int, d: int,
                   rank_1: int = 4, rank_2: int = 12,
                   mix: float = 0.5,
                   n_cal: int = 512, sigma_noise: float = 0.01,
                   seed: int = 42) -> tuple:
    """
    Token stream drawn from two populations with different spectral gaps.

    Population 1 (fraction mix):     rank_1 active dims  (e.g. noun tokens, deff=4)
    Population 2 (fraction 1-mix):   rank_2 active dims  (e.g. verb tokens, deff=12)

    A single calibration eigenbasis cannot simultaneously match both populations.
    Expected result:
        - Calibrated d_eff lands between rank_1 and rank_2
        - Water-fill allocation is suboptimal for both populations
        - Beta diagnostic shows bimodal or fat-tailed distribution

    Parameters
    ----------
    rank_1, rank_2 : effective ranks of the two populations
    mix            : fraction of tokens from population 1
    """
    rng = np.random.default_rng(seed)

    U_1 = _make_subspace(d, rank_1, rng)
    U_2 = _make_subspace(d, rank_2, rng)

    lam_1 = np.ones(rank_1)
    lam_2 = np.exp(-np.arange(rank_2) * 0.3)
    lam_2 /= lam_2.max()

    def sample_mixture(n_samp):
        n1 = int(n_samp * mix)
        n2 = n_samp - n1
        X1 = _sample_from_subspace(n1, U_1, lam_1, rng, sigma_noise)
        X2 = _sample_from_subspace(n2, U_2, lam_2, rng, sigma_noise)
        X  = np.concatenate([X1, X2], axis=0)
        perm = rng.permutation(n_samp)
        return X[perm]

    K_cal = sample_mixture(n_cal)
    K     = sample_mixture(n)
    V     = sample_mixture(n)
    Q     = _make_query(K, rng)

    return K, V, Q, K_cal


# ═══════════════════════════════════════════════════════════════════════════════
# 5.  CLI for quick inspection
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import sys

    print("synth_kv.py — generator smoke-test")
    print(f"{'='*50}")
    d, n, n_cal = 128, 2048, 256

    for name, fn, kwargs in [
        ("gaussian_lowrank  rank=4",   gaussian_lowrank,
         dict(n=n, d=d, rank=4, n_cal=n_cal)),
        ("gaussian_lowrank  rank=32",  gaussian_lowrank,
         dict(n=n, d=d, rank=32, n_cal=n_cal)),
        ("gaussian_lowrank  rank=32 exp", gaussian_lowrank,
         dict(n=n, d=d, rank=32, n_cal=n_cal, lam_decay="exp")),
        ("student_rotated   nu=3",     student_rotated,
         dict(n=n, d=d, rank=4, nu=3.0, n_cal=n_cal)),
        ("student_rotated   nu=1.5",   student_rotated,
         dict(n=n, d=d, rank=4, nu=1.5, n_cal=n_cal)),
        ("misaligned_kv     theta=0",  misaligned_kv,
         dict(n=n, d=d, rank=4, theta=0.0, n_cal=n_cal)),
        ("misaligned_kv     theta=pi/2", misaligned_kv,
         dict(n=n, d=d, rank=4, theta=np.pi/2, n_cal=n_cal)),
        ("two_population    4/12",     two_population,
         dict(n=n, d=d, rank_1=4, rank_2=12, n_cal=n_cal)),
    ]:
        K, V, Q, K_cal = fn(**kwargs)
        Sigma = K_cal.T @ K_cal / n_cal
        lam = np.sort(np.linalg.eigvalsh(Sigma))[::-1]
        lam = np.maximum(lam, 0)
        d_eff = int(round((lam.sum() ** 2) / (lam ** 2).sum()))
        frac  = lam[:d_eff].sum() / lam.sum() * 100
        print(f"{name:<35} K={K.shape}  d_eff={d_eff}  "
              f"energy_in_deff={frac:.1f}%  "
              f"K_std={K.std():.3f}")
