"""
sweep.py — Python reference sweep: TQ + SQ schemes, matching GPU CSV format.
============================================================================
Runs all TQ and SQ schemes on synthetic regimes. Outputs CSV with identical
columns to the GPU sweep for direct comparison.

SQ regimes carry rank in the name (e.g. lowrank_r4, lowrank_r8) so d_eff
is determined by the data structure, not a separate column.
d_eff column = D for all rows (dimension identification only).

Usage:
    python sweep.py --regime unit_sphere lowrank_r8 fattail \\
                    --budget 2 3 4 5 6 7 --trials 16 --d 128 \\
                    --out csv/sweep_py_d128.csv
"""

import argparse
import sys
import pathlib
import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from python.codecs.tq_codec import (tq_solve_codebook, tq_roundtrip,
                                     tq_encode_qjl_score, tq_attention_score)
from python.codecs.qjl import make_sign_vector, make_sign_matrix
from python.codecs.sq_codec import (fit_codebook, sq_encode_K, sq_encode_V,
                                     sq_decode_V, sq_decode_K_for_metrics,
                                     sq_attention_score)

# ── argument parsing ──────────────────────────────────────────────────────────

ap = argparse.ArgumentParser()
ap.add_argument("--regime",  nargs="+",
                default=["unit_sphere", "lowrank_r8", "lowrank_aligned_r8",
                         "fattail", "lowrank_steep_r4", "lowrank_misalign_r4"])
ap.add_argument("--budget",  nargs="+", type=int, default=[2,3,4,5,6,7])
ap.add_argument("--trials",  type=int, default=16)
ap.add_argument("--seed",    type=int, default=42)
ap.add_argument("--d",       type=int, default=128)
ap.add_argument("--n_cal",   type=int, default=512)
ap.add_argument("--m_qjl",   type=int, default=64,
                help="QJL projections for SQ schemes (default 64)")
ap.add_argument("--S",       nargs="+", type=int, default=None,
                help="Filter sequence lengths (default: all)")
ap.add_argument("--scheme",  nargs="+", default=None,
                help="Filter schemes (default: all)")
ap.add_argument("--out",     default="csv/sweep_py.csv")
args = ap.parse_args()

D      = args.d
RNG    = np.random.default_rng(args.seed)

SEQ_LENS = [64, 128, 256, 512, 1024, 2048, 4096]
NQ_VALS  = [1, 2, 4, 8, 16, 32, 64]

# ── data generators ───────────────────────────────────────────────────────────

def make_unit_sphere(S, Nq, n_cal, **kw):
    rng = np.random.default_rng(RNG.integers(1<<31))
    def sph(n): X = rng.standard_normal((n, D)); return X / np.linalg.norm(X, axis=1, keepdims=True)
    K, V, Q, Kc = sph(S), sph(S), sph(Nq), sph(n_cal)
    return K, V, Q, Kc, sph(n_cal)   # last = V_cal

def make_lowrank(S, Nq, n_cal, rank=8, **kw):
    rng = np.random.default_rng(RNG.integers(1<<31))
    A = rng.standard_normal((D, rank)) / np.sqrt(rank)
    def make(n): return rng.standard_normal((n, rank)) @ A.T
    return make(S), make(S), make(Nq), make(n_cal), make(n_cal)

def make_lowrank_aligned(S, Nq, n_cal, rank=8, noise=0.05, **kw):
    rng = np.random.default_rng(RNG.integers(1<<31))
    A = np.zeros((D, rank)); A[:rank, :] = np.eye(rank)
    def make(n):
        return rng.standard_normal((n, rank)) / np.sqrt(rank) @ A.T + noise * rng.standard_normal((n, D))
    return make(S), make(S), make(Nq), make(n_cal), make(n_cal)

def make_lowrank_steep(S, Nq, n_cal, rank=4, base=2.0, **kw):
    rng = np.random.default_rng(RNG.integers(1<<31))
    lam = np.array([base**(-i) for i in range(rank)]); lam /= lam.sum()
    A = rng.standard_normal((D, rank)); A, _ = np.linalg.qr(A); A = A[:, :rank]
    def make(n): return rng.standard_normal((n, rank)) * np.sqrt(lam) @ A.T
    return make(S), make(S), make(Nq), make(n_cal), make(n_cal)

def make_lowrank_misalign(S, Nq, n_cal, rank=4, **kw):
    rng = np.random.default_rng(RNG.integers(1<<31))
    AK = rng.standard_normal((D, rank)); AK, _ = np.linalg.qr(AK); AK = AK[:, :rank]
    AV = rng.standard_normal((D, rank)); AV, _ = np.linalg.qr(AV); AV = AV[:, :rank]
    K    = rng.standard_normal((S, rank)) @ AK.T / np.sqrt(rank)
    V    = rng.standard_normal((S, rank)) @ AV.T / np.sqrt(rank)
    Q    = rng.standard_normal((Nq, rank)) @ AK.T / np.sqrt(rank)
    K_cal = rng.standard_normal((n_cal, rank)) @ AK.T / np.sqrt(rank)
    V_cal = rng.standard_normal((n_cal, rank)) @ AV.T / np.sqrt(rank)
    return K, V, Q, K_cal, V_cal

def make_fattail(S, Nq, n_cal, nu=3.0, **kw):
    rng = np.random.default_rng(RNG.integers(1<<31))
    def make(n):
        normal = rng.standard_normal((n, D))
        chi2   = rng.chisquare(nu, size=(n, D))
        return normal / np.sqrt(chi2 / nu + 1e-6)
    return make(S), make(S), make(Nq), make(n_cal), make(n_cal)

# Regime name → (generator, kwargs)
def _parse_regime(name):
    """Parse regime name and extract rank if present.
    e.g. lowrank_r8 → (make_lowrank, {'rank': 8})
         lowrank_aligned_r8 → (make_lowrank_aligned, {'rank': 8})
    """
    import re
    rank_match = re.search(r'_r(\d+)$', name)
    rank = int(rank_match.group(1)) if rank_match else None
    base = re.sub(r'_r\d+$', '', name)   # strip _rN suffix

    FN_MAP = {
        "unit_sphere":      make_unit_sphere,
        "lowrank":          make_lowrank,
        "lowrank_aligned":  make_lowrank_aligned,
        "lowrank_steep":    make_lowrank_steep,
        "lowrank_misalign": make_lowrank_misalign,
        "fattail":          make_fattail,
    }
    if base not in FN_MAP:
        return None, {}
    kw = {"rank": rank} if rank is not None else {}
    return FN_MAP[base], kw

# ── schemes ───────────────────────────────────────────────────────────────────
# TQ: (name, wht, var_K, var_V)   var: "NONE"/"RHT"/"FULL"
# SQ: (name, "SQU"/"SQW", qjl_K, qjl_V)

TQ_SCHEMES = [
    ("Plain-KV",  False, "NONE", "NONE"),
    ("TQ-KV",     True,  "NONE", "NONE"),
    ("TQ-QKV",    True,  "RHT",  "NONE"),
    ("TQ-FKV",    True,  "FULL", "NONE"),
    ("TQ-KQV",    True,  "NONE", "RHT"),
    ("TQ-QKQV",   True,  "RHT",  "RHT"),
    ("TQ-KFV",    True,  "NONE", "FULL"),
    ("TQ-FKFV",   True,  "FULL", "FULL"),
]

SQ_SCHEMES = [
    ("SQU-KV",    "SQU", False, False),
    ("SQU-QKV",   "SQU", True,  False),
    ("SQU-KQV",   "SQU", False, True),
    ("SQU-QKQV",  "SQU", True,  True),
    ("SQW-KV",    "SQW", False, False),
    ("SQW-QKV",   "SQW", True,  False),
    ("SQW-KQV",   "SQW", False, True),
    ("SQW-QKQV",  "SQW", True,  True),
]

# ── helpers ───────────────────────────────────────────────────────────────────

def softmax(X):
    X = X - X.max(axis=-1, keepdims=True)
    E = np.exp(X); return E / E.sum(axis=-1, keepdims=True)

def attention(Q, K, V):
    W = softmax(Q @ K.T / np.sqrt(D))
    return W @ V, W

def cosine_sim(A, B):
    return np.sum(A*B, axis=1) / (np.linalg.norm(A, axis=1)*np.linalg.norm(B, axis=1) + 1e-12)

def rel_mse(A, B):
    return float(np.sum((A-B)**2) / (np.sum(A**2) + 1e-30))

def kl_div(P, Q_):
    P = np.clip(P, 1e-12, None); Q_ = np.clip(Q_, 1e-12, None)
    return float(np.mean(np.sum(P * np.log(P / Q_), axis=1)))

def topk5(W_ref, W_hat, k=5):
    top_ref = np.argsort(W_ref, axis=1)[:, -k:]
    top_hat = np.argsort(W_hat, axis=1)[:, -k:]
    overlap = np.mean([len(np.intersect1d(top_ref[i], top_hat[i]))/k
                       for i in range(len(W_ref))])
    return 1.0 - overlap

# ── CSV header ────────────────────────────────────────────────────────────────

HEADER = ("scheme,budget,n_bits_K,n_bits_V,has_qjl_K,has_qjl_V,vram_B,"
          "S,Nq,KL,relMSE,topk5,cosine,relMSE_K,relMSE_V,"
          "ptrelMSE_K,ptrelMSE_V,ptcosine_K,ptcosine_V,"
          "kern32,kern16,fpkern32,fpkern16,"
          "tot32,tot16,ftot32,ftot16,ratio32,ratio16,"
          "regime,d_eff,n_bits_K_eff,n_bits_V_eff")

NAN = float("nan")

def make_row(scheme_name, budget, nK, nV, has_qjl_K, has_qjl_V,
             seq_len, Nq, regime,
             sum_kl, sum_mse, sum_topk, sum_cos, sum_mseK, sum_mseV,
             ptrelMSE_K, ptrelMSE_V, ptcos_K, ptcos_V, nt):
    return (
        f"{scheme_name},{budget},{nK},{nV},"
        f"{int(has_qjl_K)},{int(has_qjl_V)},0,"
        f"{seq_len},{Nq},"
        f"{sum_kl/nt:.6f},{sum_mse/nt:.6f},"
        f"{sum_topk/nt:.4f},{sum_cos/nt:.6f},"
        f"{sum_mseK/nt:.6f},{sum_mseV/nt:.6f},"
        f"{ptrelMSE_K:.6f},{ptrelMSE_V:.6f},"
        f"{ptcos_K:.6f},{ptcos_V:.6f},"
        f"{NAN},{NAN},{NAN},{NAN},"
        f"{NAN},{NAN},{NAN},{NAN},"
        f"{NAN},{NAN},"
        f"{regime},{D},{nK},{nV}"
    )

# ── main sweep ────────────────────────────────────────────────────────────────

rows = []

for regime in args.regime:
    gen, kw = _parse_regime(regime)
    if gen is None:
        print(f"Unknown regime: {regime}", file=sys.stderr); continue
    print(f"[sweep_py] regime={regime}", file=sys.stderr)

    for seq_len in (args.S if args.S else SEQ_LENS):
        K_data, V_data, Q_data, K_cal, V_cal = gen(seq_len, max(NQ_VALS), args.n_cal, **kw)

        for budget in args.budget:
            print(f"[sweep_py]   S={seq_len} budget={budget}", file=sys.stderr)

            # ── TQ signs and codebooks ────────────────────────────────────────
            S2_K    = make_sign_vector(D, RNG)
            S2_V    = make_sign_vector(D, RNG)
            S_mat_K = make_sign_matrix(D, RNG)
            S_mat_V = make_sign_matrix(D, RNG)
            cb_tq   = {n: tq_solve_codebook(D, n) for n in [budget, budget-1] if n >= 1}

            # ── TQ schemes ────────────────────────────────────────────────────
            for scheme_name, wht, var_K, var_V in TQ_SCHEMES:
                if args.scheme and scheme_name not in args.scheme: continue
                use_qjl_K = var_K != "NONE"
                use_qjl_V = var_V != "NONE"
                nK = budget - int(use_qjl_K)
                nV = budget - int(use_qjl_V)
                if nK < 1 or nV < 1: continue

                cb_K = cb_tq[nK]; cb_V = cb_tq[nV]
                S_K = S_mat_K if var_K == "FULL" else S2_K
                S_V = S_mat_V if var_V == "FULL" else S2_V

                if wht:
                    K_hat = tq_roundtrip(K_data, cb_K, use_qjl=False)
                    V_hat = tq_roundtrip(V_data, cb_V, use_qjl=use_qjl_V,
                                         S2=S_V if use_qjl_V else None)
                else:
                    def plain_rt(X, cb):
                        norms = np.linalg.norm(X, axis=1, keepdims=True) + 1e-12
                        bnd = cb.boundaries[1:-1]
                        idx = np.clip(np.searchsorted(bnd, X/norms), 0, len(cb.centroids)-1)
                        return cb.centroids[idx] * norms
                    K_hat = plain_rt(K_data, cb_K)
                    V_hat = plain_rt(V_data, cb_V)

                k_enc = tq_encode_qjl_score(K_data, cb_K, S_K) if use_qjl_K else None

                ptrelMSE_K = float(np.mean(np.sum((K_data-K_hat)**2,axis=1)/(np.sum(K_data**2,axis=1)+1e-30)))
                ptrelMSE_V = float(np.mean(np.sum((V_data-V_hat)**2,axis=1)/(np.sum(V_data**2,axis=1)+1e-30)))
                ptcos_K = float(cosine_sim(K_data, K_hat).mean())
                ptcos_V = float(cosine_sim(V_data, V_hat).mean())

                for Nq in NQ_VALS:
                    if Nq > seq_len: continue
                    sum_kl=sum_mse=sum_cos=sum_topk=sum_mseK=sum_mseV=0.0
                    trial_rng = np.random.default_rng(args.seed ^ 0xBEEF1234)
                    for _ in range(args.trials):
                        Q = trial_rng.standard_normal((Nq, D))
                        T_ref, W_ref = attention(Q, K_data, V_data)
                        if use_qjl_K and k_enc:
                            sc = tq_attention_score(Q, k_enc, S_K) / np.sqrt(D)
                            W_hat_ = softmax(sc); T_hat = W_hat_ @ V_hat
                        else:
                            T_hat, W_hat_ = attention(Q, K_hat, V_hat)
                        sum_kl   += kl_div(W_ref, W_hat_)
                        sum_mse  += rel_mse(T_ref, T_hat)
                        sum_cos  += cosine_sim(T_ref, T_hat).mean()
                        sum_topk += topk5(W_ref, W_hat_)
                        sum_mseK += rel_mse(T_ref, attention(Q, K_hat, V_data)[0])
                        sum_mseV += rel_mse(T_ref, attention(Q, K_data, V_hat)[0])
                    rows.append(make_row(scheme_name, budget, nK, nV,
                                         use_qjl_K, use_qjl_V, seq_len, Nq, regime,
                                         sum_kl, sum_mse, sum_topk, sum_cos,
                                         sum_mseK, sum_mseV,
                                         ptrelMSE_K, ptrelMSE_V, ptcos_K, ptcos_V,
                                         args.trials))

            # ── SQ codebooks (one per budget, reused across SQ schemes) ───────
            sq_cb_cache = {}  # (uniform, nK, nV) → (cb_K, cb_V)

            def get_sq_cb(uniform, nK, nV):
                key = (uniform, nK, nV)
                if key not in sq_cb_cache:
                    b_tail_K = min(2, nK); b_tail_V = min(2, nV)
                    cb_K = fit_codebook(K_cal, V_cal, b_target=nK,
                                        b_tail=b_tail_K, uniform=uniform)
                    cb_V = fit_codebook(K_cal, V_cal, b_target=nV,
                                        b_tail=b_tail_V, uniform=uniform)
                    sq_cb_cache[key] = (cb_K, cb_V)
                return sq_cb_cache[key]

            # SQ signs drawn once per (regime, S, budget)
            sq_S_K = make_sign_matrix(1, RNG, m=args.m_qjl)  # placeholder, size set per d_eff
            sq_S_V = make_sign_matrix(1, RNG, m=args.m_qjl)

            # ── SQ schemes ────────────────────────────────────────────────────
            for scheme_name, family, qjl_K, qjl_V in SQ_SCHEMES:
                if args.scheme and scheme_name not in args.scheme: continue
                uniform = (family == "SQU")
                nK = budget - int(qjl_K)
                nV = budget - int(qjl_V)
                if nK < 1 or nV < 1: continue

                cb_K, cb_V = get_sq_cb(uniform, nK, nV)

                # Draw signs sized to d_eff
                S_qjl_K = make_sign_matrix(cb_K.d_eff_K, RNG, m=args.m_qjl) if qjl_K else None
                S_qjl_V = make_sign_matrix(cb_V.d_eff_V, RNG, m=args.m_qjl) if qjl_V else None

                enc_K = sq_encode_K(K_data, cb_K, S_qjl=S_qjl_K)
                enc_V = sq_encode_V(V_data, cb_V, S_qjl=S_qjl_V)
                K_hat = sq_decode_K_for_metrics(enc_K, cb_K)
                V_hat = sq_decode_V(enc_V, cb_V, S_qjl=S_qjl_V)

                ptrelMSE_K = float(np.mean(np.sum((K_data-K_hat)**2,axis=1)/(np.sum(K_data**2,axis=1)+1e-30)))
                ptrelMSE_V = float(np.mean(np.sum((V_data-V_hat)**2,axis=1)/(np.sum(V_data**2,axis=1)+1e-30)))
                ptcos_K = float(cosine_sim(K_data, K_hat).mean())
                ptcos_V = float(cosine_sim(V_data, V_hat).mean())

                for Nq in NQ_VALS:
                    if Nq > seq_len: continue
                    sum_kl=sum_mse=sum_cos=sum_topk=sum_mseK=sum_mseV=0.0
                    trial_rng = np.random.default_rng(args.seed ^ 0xBEEF1234)
                    for _ in range(args.trials):
                        Q = trial_rng.standard_normal((Nq, D))
                        T_ref, W_ref = attention(Q, K_data, V_data)
                        scores = sq_attention_score(Q, enc_K, cb_K,
                                                     S_qjl=S_qjl_K) / np.sqrt(D)
                        W_hat_ = softmax(scores)
                        T_hat  = W_hat_ @ V_hat
                        sum_kl   += kl_div(W_ref, W_hat_)
                        sum_mse  += rel_mse(T_ref, T_hat)
                        sum_cos  += cosine_sim(T_ref, T_hat).mean()
                        sum_topk += topk5(W_ref, W_hat_)
                        sum_mseK += rel_mse(T_ref, attention(Q, K_hat, V_data)[0])
                        sum_mseV += rel_mse(T_ref, attention(Q, K_data, V_hat)[0])
                    rows.append(make_row(scheme_name, budget, nK, nV,
                                         qjl_K, qjl_V, seq_len, Nq, regime,
                                         sum_kl, sum_mse, sum_topk, sum_cos,
                                         sum_mseK, sum_mseV,
                                         ptrelMSE_K, ptrelMSE_V, ptcos_K, ptcos_V,
                                         args.trials))

out = pathlib.Path(args.out)
out.parent.mkdir(parents=True, exist_ok=True)
with open(out, "w") as f:
    f.write(HEADER + "\n")
    for row in rows:
        f.write(row + "\n")

print(f"[sweep_py] Written {len(rows)} rows to {out}", file=sys.stderr)
