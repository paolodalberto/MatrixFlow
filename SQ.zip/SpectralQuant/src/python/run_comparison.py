"""
run_comparison.py — TQ vs SQ head-to-head comparison
=====================================================
Feeds identical (K, V, Q, K_cal, V_cal) to both frameworks.
Uses new sq_codec.py and tq_codec.py (corrected designs).

TQ schemes:  Plain-KV, TQ-KV, TQ-QKV
SQ schemes:  SQU-KV, SQU-QKV, SQW-KV, SQW-QKV

Metrics per scheme:
  ptcosine_K, ptcosine_V  — cache reconstruction quality
  cosine(T), KL            — attention output quality
  d2                       — combined distance metric

Usage:
    python run_comparison.py --regime fattail lowrank_aligned --budget 2 3 4
"""

import argparse
import sys
import pathlib
import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from python.codecs.tq_codec import (tq_solve_codebook, tq_roundtrip,
                                     tq_encode_qjl_score, tq_attention_score)
from python.codecs.qjl import make_sign_vector, make_sign_matrix
from python.codecs.sq_codec import (fit_codebook, sq_encode_K, sq_encode_V,
                                     sq_decode_V, sq_decode_K_for_metrics,
                                     sq_attention_score, sq_sigma_scale_K, sq_sigma_scale_V)

ap = argparse.ArgumentParser()
ap.add_argument("--regime",  nargs="+",
                default=["unit_sphere", "lowrank_aligned", "lowrank", "fattail"])
ap.add_argument("--budget",  nargs="+", type=int, default=[2, 3, 4])
ap.add_argument("--S",       type=int, default=256)
ap.add_argument("--Nq",      type=int, default=32)
ap.add_argument("--trials",  type=int, default=50)
ap.add_argument("--d",       type=int, default=128)
ap.add_argument("--seed",    type=int, default=42)
ap.add_argument("--m_qjl",   type=int, default=64,
                help="Number of QJL projections for SQ (default 64)")
ap.add_argument("--scheme",  nargs="+", default=None,
                help="Filter schemes (default: all)")
ap.add_argument("--use_sigma", action="store_true",
                help="Use calibrated sigma scale instead of per-token r_norms")
args = ap.parse_args()

D    = args.d
RNG  = np.random.default_rng(args.seed)

# ── data generators ───────────────────────────────────────────────────────────

def make_unit_sphere(S, rng):
    X = rng.standard_normal((S, D))
    return X / np.linalg.norm(X, axis=1, keepdims=True)

def make_lowrank_aligned(S, rng, rank=8, noise=0.05):
    A = np.zeros((D, rank)); A[:rank, :] = np.eye(rank)
    X = rng.standard_normal((S, rank)) @ A.T
    return X + noise * rng.standard_normal((S, D))

def make_lowrank(S, rng, rank=8):
    A = rng.standard_normal((D, rank)) / np.sqrt(rank)
    return rng.standard_normal((S, rank)) @ A.T

def make_fattail(S, rng, nu=3.0):
    normal = rng.standard_normal((S, D))
    chi2   = rng.chisquare(nu, size=(S, D))
    return normal / np.sqrt(chi2 / nu + 1e-6)

def make_lowrank_steep(S, rng, rank=4, base=2.0):
    lam = np.array([base**(-i) for i in range(rank)]); lam /= lam.sum()
    A = rng.standard_normal((D, rank)); A, _ = np.linalg.qr(A); A = A[:, :rank]
    return rng.standard_normal((S, rank)) * np.sqrt(lam) @ A.T

def make_waterfill_test(S, rng, rank=8, base=1.5):
    """Moderate exponential decay rank-8 — designed to trigger water-filling.
    base=1.5 → λ ratio ≈ 17, d_eff≈4, non-uniform allocation at b≥3."""
    lam = np.array([base**(-i) for i in range(rank)]).astype(float)
    lam /= lam.sum()
    A = rng.standard_normal((D, rank)); A, _ = np.linalg.qr(A); A = A[:, :rank]
    return rng.standard_normal((S, rank)) * np.sqrt(lam) @ A.T

def make_lowrank_misalign(S, rng, rank=4):
    # Returns K only — V drawn from different subspace separately in main loop
    AK = rng.standard_normal((D, rank)); AK, _ = np.linalg.qr(AK); AK = AK[:, :rank]
    return rng.standard_normal((S, rank)) @ AK.T / np.sqrt(rank)

REGIME_FN = {
    "unit_sphere":      make_unit_sphere,
    "lowrank_aligned":  make_lowrank_aligned,
    "lowrank":          make_lowrank,
    "lowrank_steep":    make_lowrank_steep,
    "lowrank_misalign": make_lowrank_misalign,
    "fattail":          make_fattail,
    "waterfill_test":   make_waterfill_test,
}

# ── attention helpers ─────────────────────────────────────────────────────────

def softmax(X):
    X = X - X.max(axis=-1, keepdims=True)
    E = np.exp(X); return E / E.sum(axis=-1, keepdims=True)

def attention(Q, K, V):
    W = softmax(Q @ K.T / np.sqrt(D))
    return W @ V, W

def cosine_mean(A, B):
    n = np.linalg.norm(A, axis=1) * np.linalg.norm(B, axis=1) + 1e-12
    return float(np.mean(np.sum(A * B, axis=1) / n))

def rel_mse(A, B):
    return float(np.sum((A-B)**2) / (np.sum(A**2) + 1e-30))

def kl_div(P, Q_):
    P = np.clip(P, 1e-12, None); Q_ = np.clip(Q_, 1e-12, None)
    return float(np.mean(np.sum(P * np.log(P / Q_), axis=1)))

def pt_cosine(A, B):
    n = np.linalg.norm(A, axis=1) * np.linalg.norm(B, axis=1) + 1e-12
    return float(np.mean(np.sum(A * B, axis=1) / n))

def d2(cosine, relmse):
    AS = 1.0 - cosine
    NF = relmse / (1.0 + relmse)
    return float(np.sqrt(AS**2 + NF**2))

# ── run one cell ──────────────────────────────────────────────────────────────

def run_cell(scheme, K, V, K_cal, V_cal, budget, trial_rng):
    """Run one (scheme, budget) cell. Returns metrics dict."""

    sum_cos = sum_mse = sum_kl = 0.0
    K_hat = V_hat = None

    if scheme == "Plain-KV":
        cb = tq_solve_codebook(D, budget)
        norms_K = np.linalg.norm(K, axis=1, keepdims=True) + 1e-12
        norms_V = np.linalg.norm(V, axis=1, keepdims=True) + 1e-12
        bnd = cb.boundaries[1:-1]
        K_hat = cb.centroids[np.clip(np.searchsorted(bnd, K/norms_K), 0, len(cb.centroids)-1)] * norms_K
        V_hat = cb.centroids[np.clip(np.searchsorted(bnd, V/norms_V), 0, len(cb.centroids)-1)] * norms_V
        for _ in range(args.trials):
            Q_ = trial_rng.standard_normal((args.Nq, D))
            T_ref, W_ref = attention(Q_, K, V)
            T_hat, W_hat = attention(Q_, K_hat, V_hat)
            sum_cos += cosine_mean(T_ref, T_hat)
            sum_mse += rel_mse(T_ref, T_hat)
            sum_kl  += kl_div(W_ref, W_hat)

    elif scheme.startswith("TQ-"):
        suffix = scheme.split("-", 1)[1]   # KV, KQV, QKV, QKQV
        qjl_K  = suffix[0] == "Q"
        qjl_V  = suffix[-2] == "Q"
        nK = budget - int(qjl_K)
        nV = budget - int(qjl_V)
        if nK < 1 or nV < 1:
            return None
        cb_K = tq_solve_codebook(D, nK)
        cb_V = tq_solve_codebook(D, nV)
        S2_K = make_sign_vector(D, RNG)
        S2_V = make_sign_vector(D, RNG)
        K_hat = tq_roundtrip(K, cb_K, use_qjl=False)
        V_hat = tq_roundtrip(V, cb_V, use_qjl=qjl_V, S2=S2_V if qjl_V else None)
        k_enc = tq_encode_qjl_score(K, cb_K, S2_K) if qjl_K else None
        for _ in range(args.trials):
            Q_ = trial_rng.standard_normal((args.Nq, D))
            T_ref, W_ref = attention(Q_, K, V)
            if qjl_K and k_enc:
                sc = tq_attention_score(Q_, k_enc, S2_K) / np.sqrt(D)
                W_hat_ = softmax(sc); T_hat = W_hat_ @ V_hat
            else:
                T_hat, W_hat_ = attention(Q_, K_hat, V_hat)
            sum_cos += cosine_mean(T_ref, T_hat)
            sum_mse += rel_mse(T_ref, T_hat)
            sum_kl  += kl_div(W_ref, W_hat_)

    elif scheme.startswith("SQU-") or scheme.startswith("SQW-"):
        uniform = scheme.startswith("SQU-")
        suffix  = scheme.split("-", 1)[1]   # KV, KQV, QKV, QKQV
        # Q before K marker = QJL on K; Q before V marker = QJL on V
        qjl_K = suffix[0] == "Q"
        qjl_V = suffix[-2] == "Q"          # second-to-last char before V
        nK_bits = budget - int(qjl_K)
        nV_bits = budget - int(qjl_V)
        if nK_bits < 1 or nV_bits < 1:
            return None

        b_tail_K = min(2, nK_bits)
        b_tail_V = min(2, nV_bits)
        cb_K = fit_codebook(K_cal, V_cal, b_target=nK_bits, b_tail=b_tail_K, uniform=uniform)
        cb_V = fit_codebook(K_cal, V_cal, b_target=nV_bits, b_tail=b_tail_V, uniform=uniform)

        S_qjl_K = make_sign_matrix(cb_K.d_eff_K, RNG, m=args.m_qjl) if qjl_K else None
        S_qjl_V = make_sign_matrix(cb_V.d_eff_V, RNG, m=args.m_qjl) if qjl_V else None

        enc_K = sq_encode_K(K, cb_K, S_qjl=S_qjl_K)
        enc_V = sq_encode_V(V, cb_V, S_qjl=S_qjl_V)
        K_hat = sq_decode_K_for_metrics(enc_K, cb_K)

        sig_K = sq_sigma_scale_K(cb_K) if args.use_sigma and qjl_K else None
        sig_V = sq_sigma_scale_V(cb_V) if args.use_sigma and qjl_V else None

        V_hat = sq_decode_V(enc_V, cb_V, S_qjl=S_qjl_V, sigma_scale=sig_V)

        for _ in range(args.trials):
            Q_ = trial_rng.standard_normal((args.Nq, D))
            T_ref, W_ref = attention(Q_, K, V)
            scores = sq_attention_score(Q_, enc_K, cb_K, S_qjl=S_qjl_K,
                                        sigma_scale=sig_K) / np.sqrt(D)
            W_hat_ = softmax(scores)
            T_hat  = W_hat_ @ V_hat
            sum_cos += cosine_mean(T_ref, T_hat)
            sum_mse += rel_mse(T_ref, T_hat)
            sum_kl  += kl_div(W_ref, W_hat_)
    else:
        return None

    nt = args.trials
    cos  = sum_cos / nt
    mse  = sum_mse / nt
    kl   = sum_kl  / nt
    # pt-metrics always use MSE-only reconstruction for consistency
    return dict(
        ptcosine_K = pt_cosine(K, K_hat),
        ptcosine_V = pt_cosine(V, V_hat),
        cosine     = cos,
        relMSE     = mse,
        KL         = kl,
        d2         = d2(cos, mse),
    )

# ── main ──────────────────────────────────────────────────────────────────────

ALL_SCHEMES = [
    "Plain-KV",
    "TQ-KV", "TQ-KQV", "TQ-QKV", "TQ-QKQV",
    "SQU-KV", "SQU-KQV", "SQU-QKV", "SQU-QKQV",
    "SQW-KV", "SQW-KQV", "SQW-QKV", "SQW-QKQV",
]
SCHEMES = [s for s in ALL_SCHEMES if not args.scheme or s in args.scheme]

HDR = f"{'Scheme':<14} {'budget':>6} {'ptcos_K':>8} {'ptcos_V':>8} {'cosine':>8} {'KL':>10} {'d2':>8}"
SEP = "-" * len(HDR)

for regime in args.regime:
    if regime not in REGIME_FN:
        print(f"Unknown regime: {regime}"); continue
    fn = REGIME_FN[regime]

    K     = fn(args.S, RNG)
    V     = fn(args.S, RNG)
    K_cal = fn(512,    RNG)
    V_cal = fn(512,    RNG)

    print(f"\n{'='*len(HDR)}")
    sigma_str = "sigma_scale" if args.use_sigma else "r_norms"
    print(f"Regime: {regime}  S={args.S}  Nq={args.Nq}  trials={args.trials}  m_qjl={args.m_qjl}  qjl={sigma_str}")
    print(f"{'='*len(HDR)}")
    print(HDR)
    print(SEP)

    for budget in args.budget:
        first = True
        for scheme in SCHEMES:
            trial_rng = np.random.default_rng(args.seed ^ 0xBEEF1234)
            r = run_cell(scheme, K, V, K_cal.copy(), V_cal.copy(), budget, trial_rng)
            if r is None:
                continue
            prefix = f"{budget:>6}" if first else f"{'':>6}"
            first = False
            print(f"{scheme:<14} {prefix} "
                  f"{r['ptcosine_K']:>8.4f} {r['ptcosine_V']:>8.4f} "
                  f"{r['cosine']:>8.4f} {r['KL']:>10.6f} {r['d2']:>8.4f}")
        print(SEP)
