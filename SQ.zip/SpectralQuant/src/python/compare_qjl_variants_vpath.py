"""
compare_qjl_variants_vpath.py — QJL-V reconstruction: MSE vs RHT vs Full
==========================================================================
Symmetric to compare_qjl_variants.py but tests V reconstruction quality,
not K score correction. Runs on identical V, K, Q data.

K always uses full-budget MSE (no QJL). V uses:
  MSE  — (b)-bit WHT Lloyd-Max, no QJL
  RHT  — (b-1)-bit MSE + RHT QJL correction (d-vector S2)
  Full — (b-1)-bit MSE + Full QJL correction (d×d S_mat)

Metrics reported per (regime, budget, variant):
  ptcosine_V  — V reconstruction quality (Q-independent)
  ptrelMSE_V  — V reconstruction relMSE
  cosine      — cosine(T_ref, T_hat) averaged over trials
  relMSE      — relMSE(T_ref, T_hat)
  KL          — KL(W_ref, W_hat)
  topk5       — top-5 attention recall

Usage:
    python compare_qjl_variants_vpath.py --regime unit_sphere lowrank fattail --budget 2 3 4
"""

import argparse
import sys
import pathlib
import numpy as np
import pandas as pd

HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE.parent))

from python.codecs.tq_codec import (tq_solve_codebook, tq_roundtrip)
from python.codecs.qjl import make_sign_vector, make_sign_matrix

ap = argparse.ArgumentParser()
ap.add_argument("--regime",  nargs="+", default=["unit_sphere", "lowrank", "fattail"])
ap.add_argument("--budget",  nargs="+", type=int, default=[2, 3, 4])
ap.add_argument("--S",       type=int, default=256)
ap.add_argument("--Nq",      type=int, default=32)
ap.add_argument("--trials",  type=int, default=200)
ap.add_argument("--d",       type=int, default=128)
ap.add_argument("--seed",    type=int, default=42)
args = ap.parse_args()

D    = args.d
RNG  = np.random.default_rng(args.seed)

# ── data generators ───────────────────────────────────────────────────────────

def make_unit_sphere(S, rng):
    X = rng.standard_normal((S, D))
    return X / np.linalg.norm(X, axis=1, keepdims=True)

def make_lowrank(S, rng, rank=8):
    A = rng.standard_normal((D, rank)) / np.sqrt(rank)
    return rng.standard_normal((S, rank)) @ A.T

def make_fattail(S, rng, nu=3.0):
    normal = rng.standard_normal((S, D))
    chi2   = rng.chisquare(nu, size=(S, D))
    return normal / np.sqrt(chi2 / nu + 1e-6)

REGIME_FN = {
    "unit_sphere": make_unit_sphere,
    "lowrank":     make_lowrank,
    "fattail":     make_fattail,
}

# ── attention helpers ─────────────────────────────────────────────────────────

def softmax(X):
    X = X - X.max(axis=-1, keepdims=True)
    E = np.exp(X); return E / E.sum(axis=-1, keepdims=True)

def attention(Q, K, V):
    W = softmax(Q @ K.T / np.sqrt(D))
    return W @ V, W

def cosine_mean(A, B):
    n = np.linalg.norm(A, axis=1) * np.linalg.norm(B, axis=1) + 1e-12
    return float(np.mean(np.sum(A * B, axis=1) / n))

def rel_mse(A, B):
    return float(np.sum((A-B)**2) / (np.sum(A**2) + 1e-30))

def pt_cosine(A, B):
    n = np.linalg.norm(A, axis=1) * np.linalg.norm(B, axis=1) + 1e-12
    return float(np.mean(np.sum(A * B, axis=1) / n))

def pt_relmse(A, B):
    return float(np.mean(np.sum((A-B)**2, axis=1) / (np.sum(A**2, axis=1) + 1e-30)))

def topk_recall(W_ref, W_hat, k=5):
    k = min(k, W_ref.shape[1])
    top_ref = np.argsort(W_ref, axis=1)[:, -k:]
    top_hat = np.argsort(W_hat, axis=1)[:, -k:]
    return float(np.mean([
        len(np.intersect1d(top_ref[i], top_hat[i])) / k
        for i in range(len(W_ref))]))

def kl_div(P, Q_):
    P = np.clip(P, 1e-12, None); Q_ = np.clip(Q_, 1e-12, None)
    return float(np.mean(np.sum(P * np.log(P / Q_), axis=1)))

# ── sweep ─────────────────────────────────────────────────────────────────────

print(f"{'regime':<16} {'budget':>6} {'variant':<8} "
      f"{'ptcos_V':>8} {'ptMSE_V':>8} {'topk5':>8} {'KL':>10} {'cosine':>8} {'relMSE':>8}")
print("-" * 82)

rows = []

for regime in args.regime:
    if regime not in REGIME_FN:
        print(f"Unknown regime: {regime}"); continue
    fn = REGIME_FN[regime]

    K = fn(args.S, RNG)
    V = fn(args.S, RNG)

    # K always uses full budget MSE — K_hat is fixed across all V variants
    # Signs drawn once per regime
    S2_V   = make_sign_vector(D, RNG)    # d-vector — RHT
    S_mat_V = make_sign_matrix(D, RNG)  # d×d     — Full

    trial_rng = np.random.default_rng(args.seed ^ 0xBEEF1234)

    for budget in args.budget:
        nV = budget - 1   # MSE bits for QJL variants (1 bit for QJL)
        if nV < 1: continue

        cb_K = tq_solve_codebook(D, budget)   # full budget for K
        cb_V = tq_solve_codebook(D, nV)       # b-1 bits for QJL variants

        # K reconstruction — same for all V variants
        K_hat = tq_roundtrip(K, cb_K, use_qjl=False)

        # V reconstructions
        V_mse  = tq_roundtrip(V, tq_solve_codebook(D, budget), use_qjl=False)  # b-bit MSE baseline
        V_rht  = tq_roundtrip(V, cb_V, use_qjl=True, S2=S2_V)
        V_full = tq_roundtrip(V, cb_V, use_qjl=True, S2=S_mat_V)

        variants = [
            ("MSE",  V_mse),
            ("RHT",  V_rht),
            ("Full", V_full),
        ]

        for vname, V_hat in variants:
            ptcos_V   = pt_cosine(V, V_hat)
            ptrelmse_V = pt_relmse(V, V_hat)

            sum_cos = sum_mse = sum_kl = sum_topk = 0.0
            for _ in range(args.trials):
                Q = trial_rng.standard_normal((args.Nq, D))
                T_ref, W_ref = attention(Q, K, V)
                T_hat, W_hat = attention(Q, K_hat, V_hat)
                sum_cos  += cosine_mean(T_ref, T_hat)
                sum_mse  += rel_mse(T_ref, T_hat)
                sum_kl   += kl_div(W_ref, W_hat)
                sum_topk += topk_recall(W_ref, W_hat)

            nt = args.trials
            print(f"{regime:<16} {budget:>6} {vname:<8} "
                  f"{ptcos_V:>8.4f} {ptrelmse_V:>8.4f} "
                  f"{sum_topk/nt:>8.4f} {sum_kl/nt:>10.6f} "
                  f"{sum_cos/nt:>8.4f} {sum_mse/nt:>8.4f}")
            rows.append({
                "regime": regime, "budget": budget, "variant": vname,
                "ptcosine_V": ptcos_V, "ptrelMSE_V": ptrelmse_V,
                "topk5": sum_topk/nt, "KL": sum_kl/nt,
                "cosine": sum_cos/nt, "relMSE": sum_mse/nt,
            })
        print()

df = pd.DataFrame(rows)
out = "/tmp/qjl_vpath_comparison.csv"
df.to_csv(out, index=False)
print(f"Saved: {out}")
