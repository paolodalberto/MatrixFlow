import numpy as np

# 1. Setup Simulation Parameters
np.random.seed(42)
dim = 512              # Hidden dimension of the LLM vector
seq_len = 128          # Sequence length (multiple tokens in KV cache)

# Generate a Query vector (e.g., the current token looking at the past)
Q_vec = np.random.normal(0, 1, dim)
Q_vec[10] = 15.0  # Outlier channel in Query

# Generate a matrix of Key/Value vectors (128 tokens in the KV cache)
# We add heavy outlier channels to mimic real LLM activation distributions
V_matrix = np.random.normal(0, 1, (seq_len, dim))
V_matrix[:, 10] = 15.0   # Positive outlier channel
V_matrix[:, 20] = -15.0  # Negative outlier channel

# Calculate true attention scores (inner products for the entire sequence)
true_inner_products = V_matrix @ Q_vec

# Generate a global random rotation matrix for PolarQuant
Q_mat, _ = np.linalg.qr(np.random.normal(0, 1, (dim, dim)))

def lloyd_max_quantize_matrix(X, bits):
    """Quantizes a matrix row-by-row using optimal Gaussian centroids."""
    scale = np.std(X, axis=1, keepdims=True)
    norm_X = X / scale
    
    if bits == 2:
        centroids = np.array([-1.51, -0.45, 0.45, 1.51])
    elif bits == 3:
        centroids = np.array([-2.15, -1.34, -0.76, -0.24, 0.24, 0.76, 1.34, 2.15])
        
    distances = np.abs(norm_X[:, :, np.newaxis] - centroids)
    indices = np.argmin(distances, axis=2)
    return centroids[indices] * scale

# Rotate the entire matrix to smear outliers
V_matrix_rot = V_matrix @ Q_mat

# =====================================================================
# STRATEGY A: PURE 3-BIT MSE POLARQUANT (BATCH)
# =====================================================================
V_matrix_3bit_rot = lloyd_max_quantize_matrix(V_matrix_rot, bits=3)
V_matrix_3bit = V_matrix_3bit_rot @ Q_mat.T
inner_3bit_mse = V_matrix_3bit @ Q_vec

# =====================================================================
# STRATEGY B: HYBRID 3-BIT (2-BIT MSE BASE + 1-BIT QJL RESIDUAL)
# =====================================================================
# 1. 2-Bit Base
V_matrix_2bit_rot = lloyd_max_quantize_matrix(V_matrix_rot, bits=2)
V_matrix_2bit = V_matrix_2bit_rot @ Q_mat.T

# 2. Extract Residual Matrix
V_matrix_res = V_matrix - V_matrix_2bit

# 3. Apply 1-Bit QJL Projection Matrix
QJL_Proj = np.random.choice([-1, 1], size=(dim, dim)) / np.sqrt(dim)
V_res_proj = V_matrix_res @ QJL_Proj.T

# Extreme 1-bit compression (Sign matrix)
V_qjl_bit = np.sign(V_res_proj)

# Reconstruct residual matrix using row-wise scale factors
scales = np.mean(np.abs(V_res_proj), axis=1, keepdims=True)
V_res_recon = (V_qjl_bit * scales) @ QJL_Proj

# 4. Final Hybrid Reconstruction
V_matrix_hybrid = V_matrix_2bit + V_res_recon
inner_hybrid = V_matrix_hybrid @ Q_vec

# =====================================================================
# EVALUATION & PROOF OF CONVERGENCE
# =====================================================================
# Mean Squared Error (Physical distance)
mse_3bit = np.mean((V_matrix - V_matrix_3bit) ** 2)
mse_hybrid = np.mean((V_matrix - V_matrix_hybrid) ** 2)

# Inner Product Errors across the entire sequence
errors_3bit = np.abs(true_inner_products - inner_3bit_mse)
errors_hybrid = np.abs(true_inner_products - inner_hybrid)

# Systematic Bias Check (Are we systematically underestimating/overestimating?)
bias_3bit = np.mean(true_inner_products - inner_3bit_mse)
bias_hybrid = np.mean(true_inner_products - inner_hybrid)

print(f"=== PHYSICAL MATRIX ERROR ===")
print(f"Pure 3-Bit MSE Matrix Error (MSE):   {mse_3bit:.4f}")
print(f"Hybrid 2+1 QJL Matrix Error (MSE):   {mse_hybrid:.4f} (Worse element-wise match)\n")

print(f"=== DOWNSTREAM ATTENTION SCORE ERROR (128 Tokens) ===")
print(f"Pure 3-Bit MAE (Mean Absolute Error): {np.mean(errors_3bit):.4f}")
print(f"Hybrid 2+1 MAE (Mean Absolute Error): {np.mean(errors_hybrid):.4f} (More accurate attention map!)\n")

print(f"=== SYSTEMATIC BIAS ANALYSIS ===")
print(f"Pure 3-Bit Systematic Bias:          {bias_3bit:.4f} (Consistently pulls scores inward)")
print(f"Hybrid 2+1 Systematic Bias:          {bias_hybrid:.4f} (Centered near 0, error cancels out)")
