# SpectralQuant — src/

Source code for the KV-cache quantization sweep described in:
**"Ablation, Statistical Inference and Validation for KV-Cache Compression"**
Paolo D'Alberto, 2026.

---

## Directory Structure

```
src/
├── hip/                        # HIP/C++ GPU implementation (AMD ROCm)
│   ├── common/
│   │   ├── pquant_common.h     # Codebook solvers, data generators, CPU encode/decode,
│   │   │                       #   metrics, SQ calibration (spectral gap criterion)
│   │   └── types.h             # Shared structs (SQCodebook, KVData, SweepResult)
│   ├── gpu/
│   │   ├── tq_kernels.hip      # TQ GPU decode kernels + launch wrappers
│   │   ├── sq_kernels.hip      # SQ GPU decode kernels + launch wrappers
│   │   ├── attention.hip       # Attention trial loop (6-pass)
│   │   └── device.hip          # Device buffer alloc/upload
│   ├── schemes/
│   │   ├── plain_kv.hip        # Plain-KV scheme
│   │   ├── tq_kv.hip           # TQ-KV scheme
│   │   ├── tq_qkv.hip          # TQ-QKV (RHT score correction on K)
│   │   ├── tq_kqv.hip          # TQ-KQV (RHT reconstruction on V)
│   │   ├── tq_qkqv.hip         # TQ-QKQV (both)
│   │   ├── squ_kv.hip          # SQU-KV (uniform bit allocation)
│   │   ├── sqw_kv.hip          # SQW-KV (water-filling allocation)
│   │   └── squ_qkv.hip         # SQU-QKV (uniform + QJL on K)
│   ├── csv/                    # Output CSVs (production sweeps)
│   ├── logs/                   # Sweep stderr logs
│   ├── main.hip                # Outer sweep loop, CSV output
│   └── run_final6_sweep_v2_alld.sh  # Production sweep: d=64/128/256, 200 trials
│
├── python/                     # Python reference implementations
│   ├── codecs/
│   │   ├── tq_codec.py         # TurboQuant codec (WHT + Beta Lloyd-Max + QJL)
│   │   ├── sq_codec.py         # SpectralQuant codec (eigenbasis + water-filling + QJL)
│   │   └── qjl.py              # 1-bit QJL: sign matrix, encode, asymmetric score
│   └── sweep.py                # Python sweep (matches HIP CSV format)
│
└── analysis/                   # Plotting and analysis scripts
    ├── compare_py_hip.py        # Python vs HIP statistical comparison (KS test)
    ├── compare_quant_6d.py      # 6D error geometry: pairwise scheme scatter
    ├── combine_6d_panels.py     # Stitch two 6D PNGs side by side
    ├── plot_d2_vs_budget.py     # d2 vs budget curves, one panel per regime
    ├── plot_d2_vs_d.py          # d2 vs dimension (d=64/128/256), rows=regime
    ├── plot_d2_ranking.py       # Ranking heatmap (scheme × regime per budget)
    ├── plot_waterfill_comparison.py  # SQU vs SQW: lowrank and lowrank_steep
    ├── plot_calibration_sensitivity.py  # Before/after spectral gap fix
    ├── iso_storage.py           # Iso-storage comparison: TQ vs SQ
    ├── iso_quality.py           # Iso-quality comparison: TQ vs SQ
    ├── sq_replaces_tq.py        # Minimum SQ budget to replace TQ at given quality
    └── snr_metrics_6d.py        # 6D error metric definitions
```

---

## Building

Requires ROCm and rocBLAS on an AMD GPU (tested on MI100/MI300X).
D is a compile-time constant — recompile for each head dimension.

```bash
cd hip
hipcc -O3 -I./common -Wno-unused-result -o sweep main.hip -lrocblas
```

---

## Running the Production Sweep

Full sweep across d=64, 128, 256 — 200 trials, 6 schemes, 6 regimes, budgets 2–7:

```bash
cd hip
chmod +x run_final6_sweep_v2_alld.sh
bash run_final6_sweep_v2_alld.sh
# Outputs: csv/final6_gpu_d{64,128,256}_t200_v2.csv
```

Single regime quick test:

```bash
HIP_VISIBLE_DEVICES=0 ./sweep \
    --regime lowrank_aligned \
    --budget 2 3 4 \
    --trials 32 \
    --scheme TQ-KV SQU-KV
```

---

## Python vs HIP Validation

```bash
cd hip
python3 ../analysis/compare_py_hip.py \
    --hip_bin ./sweep \
    --regime lowrank_aligned \
    --budget 2 3 4 \
    --trials 200 \
    --S 64 128 256 512 1024 2048 4096 \
    --scheme SQU-KV
```

Expected: `ptcosine_K` and `ptcosine_V` p > 0.05 (not significant) — codec correct.
Remaining gaps in `cosine`/`d2` are Q-RNG differences (Python PCG64 vs HIP mt19937), expected.

---

## Key Design Decisions

**CPU encode, GPU decode.** All quantization encoding happens on CPU
(`pquant_common.h`). Encoded indices are uploaded to GPU, decoded by GPU kernels,
and attention is computed entirely on GPU.

**Budget-neutral QJL.** At budget b with QJL, MSE uses b−1 bits and QJL uses
1 bit, keeping total bits/token = b. Applies identically to TQ and SQ.

**SQ spectral gap criterion.** `sq_calibrate` in `pquant_common.h` applies a
spectral gap criterion (λ_{k-1}/λ_k > 10) to trim spurious eigenvalues that
inflate the participation ratio. The known regime rank is passed as `max_d_eff`
to correct PR underestimation on steep spectra. This is critical for correctness —
without it, a single spurious eigenvalue (λ ≈ 0.005) causes d2 to jump from
0.07 to 1.63.

**Separate K and V calibration.** SQ calibrates U_K and U_V independently.
For lowrank_misalign, K and V live in orthogonal subspaces — shared calibration
collapses V quality completely.

**Storage formula.** TQ at b bits/token uses b×d bits. SQU at b_sem bits uses
b_sem×d_eff + b_tail×(d−d_eff) bits. With d=128, d_eff=8, b_tail=2:
TQ b=2 → 256 bits (equal); TQ b=3 → 384 bits vs SQU b=3 → 264 bits (31% saving).

---

## Production Data

| File | Description |
|---|---|
| `hip/csv/final6_gpu_d64_t200_v2.csv`  | d=64,  200 trials, 6 schemes, 6 regimes, b=2–7 |
| `hip/csv/final6_gpu_d128_t200_v2.csv` | d=128, 200 trials, 6 schemes, 6 regimes, b=2–7 |
| `hip/csv/final6_gpu_d256_t200_v2.csv` | d=256, 200 trials, 6 schemes, 6 regimes, b=2–7 |

All v2 files use the spectral gap calibration fix. Do not use pre-v2 CSVs.

---

## Schemes

| Scheme | Family | bits/token (d=128, b=2) | Description |
|---|---|---|---|
| Plain-KV  | —  | 256 | Scalar uniform quantization, no rotation |
| TQ-KV     | TQ | 256 | WHT rotation + Beta Lloyd-Max |
| TQ-QKV    | TQ | 256 | TQ-KV + 1-bit RHT score correction on K |
| SQU-KV    | SQ | 256 | Eigenbasis + uniform allocation |
| SQW-KV    | SQ | 256 | Eigenbasis + water-filling allocation |
| SQU-QKV   | SQ | 256 | SQU-KV + 1-bit RHT score correction on K in Z space |

## Regimes

| Regime | Rank | Distribution | K/V alignment |
|---|---|---|---|
| unit_sphere      | d   | Uniform on sphere   | aligned |
| lowrank_aligned  | 8   | Gaussian + 5% noise | aligned |
| lowrank          | 8   | Gaussian, no noise  | aligned |
| fattail          | d   | Student-t(ν=3)      | aligned |
| lowrank_steep    | 4   | Exponential decay (ratio 8) | aligned |
| lowrank_misalign | 4   | Gaussian, no noise  | orthogonal |
