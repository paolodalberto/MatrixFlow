"""
plot_calibration_sensitivity.py — SQ eigenvalue sensitivity figure
===================================================================
Left panel:  pre-fix (final6_gpu_d128_t64.csv) — non-monotone d2 vs S
Right panel: post-fix (final6_gpu_d128_t200_v2.csv) — clean monotone d2 vs S

Shows that a single spurious eigenvalue (PR=9 instead of 8) causes d2 to
jump from 0.07 to 1.63 on lowrank_aligned at d=128.

Usage (from src/):
    python3 analysis/plot_calibration_sensitivity.py \
        --pre  hip/csv/final6_gpu_d128_t64.csv \
        --post hip/csv/final6_gpu_d128_t200_v2.csv \
        --out  figures/calibration_sensitivity.png
"""

import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.lines as mlines

ap = argparse.ArgumentParser()
ap.add_argument("--pre",  default="hip/csv/final6_gpu_d128_t64.csv")
ap.add_argument("--post", default="hip/csv/final6_gpu_d128_t200_v2.csv")
ap.add_argument("--out",  default="figures/calibration_sensitivity.png")
ap.add_argument("--regime", default="lowrank_aligned")
ap.add_argument("--scheme", default="SQU-KV")
args = ap.parse_args()

BUDGETS = [2, 3, 4, 5, 6, 7]
COLORS  = plt.cm.viridis(np.linspace(0.15, 0.85, len(BUDGETS)))

def load(path):
    df = pd.read_csv(path)
    df = df[(df["scheme"] == args.scheme) & (df["regime"] == args.regime)].copy()
    df["d2"] = np.sqrt((1 - df["cosine"])**2 +
                       (df["relMSE"] / (1 + df["relMSE"]))**2)
    return df.groupby(["S", "budget"])["d2"].mean().reset_index()

pre  = load(args.pre)
post = load(args.post)

S_vals = sorted(pre["S"].unique())

fig, axes = plt.subplots(1, 2, figsize=(12, 4.5), sharey=True)

for ax, df, title, trials in [
    (axes[0], pre,  "Before fix (spurious eigenvalue)",  "64 trials"),
    (axes[1], post, "After fix (spectral gap criterion)", "200 trials"),
]:
    for b, color in zip(BUDGETS, COLORS):
        sub = df[df["budget"] == b].sort_values("S")
        ax.plot(sub["S"], sub["d2"],
                color=color, lw=2, marker="o", ms=5,
                label=f"b={b}")

    ax.axhline(1.0, color="red", lw=1, ls=":", alpha=0.6, label="d₂=1 (anti-corr.)")
    ax.set_title(f"{title}\n({trials}, d=128, {args.regime})",
                 fontsize=10, fontweight="bold")
    ax.set_xlabel("Number of tokens S", fontsize=9)
    ax.set_ylabel("d₂ (lower = better)", fontsize=9)
    ax.set_xscale("log", base=2)
    ax.set_xticks(S_vals)
    ax.set_xticklabels([str(s) for s in S_vals], fontsize=8)
    ax.grid(True, alpha=0.3, lw=0.5)
    ax.set_ylim(0, 2.0)

# Shared budget legend
handles = [mlines.Line2D([], [], color=COLORS[i], lw=2, marker="o", ms=5,
                          label=f"b={b}")
           for i, b in enumerate(BUDGETS)]
handles.append(mlines.Line2D([], [], color="red", lw=1, ls=":",
                              label="d₂=1 (anti-correlated)"))
fig.legend(handles=handles, loc="upper center", ncol=len(handles),
           fontsize=8, framealpha=0.9, bbox_to_anchor=(0.5, 1.02))

fig.suptitle(
    f"SQ Calibration Sensitivity — {args.scheme} on {args.regime}, d=128\n"
    "d₂ = √((1−cosine)² + (relMSE/(1+relMSE))²)  lower = better",
    fontsize=10, y=1.08)

import os
os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
plt.tight_layout()
plt.savefig(args.out, dpi=150, bbox_inches="tight")
print(f"Saved: {args.out}")
