"""
plot_waterfill_comparison.py — SQU-KV vs SQW-KV across d and regime
====================================================================
2 rows (lowrank, lowrank_steep) × 3 cols (d=64, 128, 256)
Shows where water-filling is identical (lowrank) vs where it activates (steep).

Usage (from src/):
    python3 analysis/plot_waterfill_comparison.py \
        --csvs hip/csv/final6_gpu_d64_t200_v2.csv \
               hip/csv/final6_gpu_d128_t200_v2.csv \
               hip/csv/final6_gpu_d256_t200_v2.csv \
        --out figures/waterfill_comparison.png
"""

import argparse
import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.lines as mlines

ap = argparse.ArgumentParser()
ap.add_argument("--csvs", nargs=3,
                default=["hip/csv/final6_gpu_d64_t200_v2.csv",
                         "hip/csv/final6_gpu_d128_t200_v2.csv",
                         "hip/csv/final6_gpu_d256_t200_v2.csv"])
ap.add_argument("--out", default="figures/waterfill_comparison.png")
args = ap.parse_args()

REGIMES = ["lowrank", "lowrank_steep"]
REGIME_LABELS = {"lowrank": "Lowrank (rank=8, flat spectrum)",
                 "lowrank_steep": "Lowrank Steep (rank=4, ratio=8)"}
SCHEMES = ["SQU-KV", "SQW-KV"]
STYLE = {
    "SQU-KV": dict(color="#1f77b4", lw=2.5, ls="-",  marker="s", ms=6, label="SQU-KV (uniform)"),
    "SQW-KV": dict(color="#9467bd", lw=1.8, ls="--", marker="D", ms=5, label="SQW-KV (water-fill)"),
}

# Load and annotate each CSV with d value
frames = []
for csv in args.csvs:
    m = re.search(r'_d(\d+)_', csv)
    d = int(m.group(1)) if m else 0
    df = pd.read_csv(csv)
    df["d"] = d
    frames.append(df)
data = pd.concat(frames, ignore_index=True)
data["d2"] = np.sqrt((1 - data["cosine"])**2 +
                     (data["relMSE"] / (1 + data["relMSE"]))**2)

agg = (data[data["scheme"].isin(SCHEMES)]
       .groupby(["regime", "d", "budget", "scheme"])["d2"]
       .mean().reset_index())

d_values = sorted(data["d"].unique())
budgets  = sorted(agg["budget"].unique())

fig, axes = plt.subplots(2, 3, figsize=(13, 7), sharey=False)

for row, regime in enumerate(REGIMES):
    for col, d in enumerate(d_values):
        ax = axes[row][col]
        sub = agg[(agg["regime"] == regime) & (agg["d"] == d)]

        for sch in SCHEMES:
            s = sub[sub["scheme"] == sch].sort_values("budget")
            if s.empty:
                continue
            st = STYLE[sch]
            ax.plot(s["budget"], s["d2"],
                    color=st["color"], lw=st["lw"], ls=st["ls"],
                    marker=st["marker"], ms=st["ms"], zorder=3)

        # Annotate max delta
        piv = sub.pivot(index="budget", columns="scheme", values="d2")
        if "SQU-KV" in piv and "SQW-KV" in piv:
            delta = (piv["SQW-KV"] - piv["SQU-KV"]).abs()
            max_delta = delta.max()
            ax.text(0.97, 0.97, f"max|Δd₂|={max_delta:.3f}",
                    transform=ax.transAxes, ha="right", va="top",
                    fontsize=8, color="#555555")

        ax.set_title(f"d={d}", fontsize=10, fontweight="bold")
        ax.set_xlabel("Budget (bits/dim)", fontsize=8)
        ax.set_ylabel("d₂ (lower = better)", fontsize=8)
        ax.set_xticks(budgets)
        ax.grid(True, alpha=0.3, lw=0.5)
        ax.set_ylim(bottom=0)

    # Row label on left
    axes[row][0].set_ylabel(
        f"{REGIME_LABELS[regime]}\nd₂ (lower = better)", fontsize=8)

# Legend
handles = [mlines.Line2D([], [], color=STYLE[s]["color"], lw=STYLE[s]["lw"],
                          ls=STYLE[s]["ls"], marker=STYLE[s]["marker"],
                          ms=STYLE[s]["ms"], label=STYLE[s]["label"])
           for s in SCHEMES]
fig.legend(handles=handles, loc="upper center", ncol=2,
           fontsize=9, framealpha=0.9, bbox_to_anchor=(0.5, 1.01))

fig.suptitle(
    "SQU-KV vs SQW-KV: does water-filling help?\n"
    "d₂ = √((1−cosine)² + (relMSE/(1+relMSE))²)  lower = better",
    fontsize=11, y=1.06)

import os
os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
plt.tight_layout()
plt.savefig(args.out, dpi=150, bbox_inches="tight")
print(f"Saved: {args.out}")
