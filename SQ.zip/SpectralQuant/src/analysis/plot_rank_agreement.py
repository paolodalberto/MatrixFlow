"""
plot_rank_agreement.py — Python vs HIP rank agreement table
============================================================
Computes d2 rankings from both Python (tq_py_d128_t16.csv) and HIP
(tq_d128_t200.csv), then shows rank(py) vs rank(hip) per (scheme, regime).

Cell content: rank number, colored green if agree, orange if Δ1, red if Δ2+.
One panel per budget.

Usage (from src/):
    python3 analysis/plot_rank_agreement.py \
        --py  csv/tq_py_d128_t16.csv \
        --hip csv/tq_d128_t200.csv \
        --out figures/rank_agreement.png \
        --budgets 2 4 6
"""

import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

ap = argparse.ArgumentParser()
ap.add_argument("--py",      default="csv/tq_py_d128_t16.csv")
ap.add_argument("--hip",     default="csv/tq_d128_t200.csv")
ap.add_argument("--out",     default="figures/rank_agreement.png")
ap.add_argument("--budgets", nargs="+", type=int, default=[2, 4, 6])
args = ap.parse_args()

# ── load ──────────────────────────────────────────────────────────────────────

def load_d2(path, label):
    df = pd.read_csv(path)
    df["d2"] = np.sqrt((1 - df["cosine"])**2 +
                       (df["relMSE"] / (1 + df["relMSE"]))**2)
    agg = df.groupby(["scheme", "regime", "budget"])["d2"].mean().reset_index()
    agg["src"] = label
    return agg

py_agg  = load_d2(args.py,  "py")
hip_agg = load_d2(args.hip, "hip")

SCHEMES = [
    "TQ-KV",
    "TQ-KQV",
    "TQ-QKV",
    "TQ-QKQV",
    "TQ-FKV",
    "TQ-KFV",
    "TQ-FKFV",
    "Plain-KV",
]

REGIMES = [
    "unit_sphere",
    "lowrank_aligned",
    "lowrank",
    "fattail",
    "lowrank_steep",
    "lowrank_misalign",
]

REGIME_LABELS = {
    "unit_sphere":      "UnitSph",
    "lowrank_aligned":  "LR-Align",
    "lowrank":          "Lowrank",
    "fattail":          "Fattail",
    "lowrank_steep":    "LR-Steep",
    "lowrank_misalign": "LR-Misalign",
}

BUDGETS = args.budgets

# ── compute ranks ─────────────────────────────────────────────────────────────

def get_ranks(agg, budget):
    """Returns dict: (scheme, regime) -> rank"""
    sub = agg[agg["budget"] == budget]
    ranks = {}
    for regime in REGIMES:
        r = sub[sub["regime"] == regime].set_index("scheme")["d2"]
        schemes_present = [s for s in SCHEMES if s in r.index]
        sorted_schemes  = sorted(schemes_present, key=lambda s: r[s])
        for rank, sch in enumerate(sorted_schemes):
            ranks[(sch, regime)] = rank + 1
    return ranks

# ── plot ──────────────────────────────────────────────────────────────────────

nrows = 1
ncols = len(BUDGETS)
fig, axes = plt.subplots(nrows, ncols,
                         figsize=(7 * ncols, 5.5),
                         squeeze=False)

for ri, budget in enumerate(BUDGETS):
    ax = axes[0][ri]
    ax.set_xlim(-0.5, len(REGIMES) - 0.5)
    ax.set_ylim(-0.5, len(SCHEMES) - 0.5)
    ax.set_aspect("equal")

    py_ranks  = get_ranks(py_agg,  budget)
    hip_ranks = get_ranks(hip_agg, budget)

    for si, sch in enumerate(SCHEMES):
        for rj, regime in enumerate(REGIMES):
            pr = py_ranks.get((sch, regime), None)
            hr = hip_ranks.get((sch, regime), None)
            if pr is None or hr is None:
                continue

            delta = abs(pr - hr)
            if delta == 0:
                color = "#2ca02c"   # green — agree
            elif delta == 1:
                color = "#ff7f0e"   # orange — off by one
            else:
                color = "#d62728"   # red — disagree

            rect = mpatches.FancyBboxPatch(
                (rj - 0.45, len(SCHEMES) - 1 - si - 0.45),
                0.9, 0.9,
                boxstyle="round,pad=0.05",
                facecolor=color, edgecolor="white", lw=1.5,
                alpha=0.85)
            ax.add_patch(rect)

            # Cell text: py_rank / hip_rank
            ax.text(rj, len(SCHEMES) - 1 - si,
                    f"py#{pr}\nhip#{hr}",
                    ha="center", va="center",
                    fontsize=7.5, color="white", fontweight="bold")

    ax.set_xticks(range(len(REGIMES)))
    ax.set_xticklabels([REGIME_LABELS[r] for r in REGIMES],
                       fontsize=8, rotation=30, ha="left")
    ax.set_yticks(range(len(SCHEMES)))
    ax.set_yticklabels(list(reversed(SCHEMES)), fontsize=8)
    ax.set_title(f"Budget = {budget}", fontsize=11, fontweight="bold")
    ax.xaxis.tick_top()
    ax.xaxis.set_label_position("top")
    # only show y labels on leftmost panel
    if ri > 0:
        ax.set_yticklabels([])
    ax.tick_params(length=0)
    for spine in ax.spines.values():
        spine.set_visible(False)

# Legend
legend_patches = [
    mpatches.Patch(color="#2ca02c", label="Agree (Δ=0)"),
    mpatches.Patch(color="#ff7f0e", label="Off by one (Δ=1)"),
    mpatches.Patch(color="#d62728", label="Disagree (Δ≥2)"),
]
fig.legend(handles=legend_patches, loc="lower center", ncol=3,
           fontsize=10, framealpha=0.9,
           bbox_to_anchor=(0.5, -0.02))

fig.suptitle("Python vs HIP Rank Agreement — d=128\n"
             "Ranked by d2 per (scheme, regime, budget)",
             fontsize=12, y=1.01)

import os
os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
plt.tight_layout()
plt.savefig(args.out, dpi=150, bbox_inches="tight")
print(f"Saved: {args.out}")
