"""
plot_d2_ranking.py — d2 ranking table across all regimes and budgets
=====================================================================
Reads CSV (HIP or Python sweep), computes d2 per (scheme, regime, budget),
and produces a heatmap-style ranking table: rows=schemes, cols=regimes,
one panel per budget.

d2 = sqrt((1-cosine)^2 + (relMSE/(1+relMSE))^2)   lower = better

Usage (from src/):
    python3 analysis/plot_d2_ranking.py \
        --csv csv/tq_d128_t200.csv \
        --out figures/d2_ranking.png

    python3 analysis/plot_d2_ranking.py \
        --csv csv/tq_sq_py_d128_t16.csv \
        --out figures/d2_ranking_tqsq.png
"""

import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

ap = argparse.ArgumentParser()
ap.add_argument("--csv",  default="csv/tq_d128_t200.csv")
ap.add_argument("--out",  default="figures/d2_ranking.png")
ap.add_argument("--budgets", nargs="+", type=int, default=[2, 3, 4, 5, 6, 7])
args = ap.parse_args()

# ── load and compute d2 ───────────────────────────────────────────────────────

df = pd.read_csv(args.csv)
df["d2"] = np.sqrt((1 - df["cosine"])**2 +
                   (df["relMSE"] / (1 + df["relMSE"]))**2)

# Normalize regime names — strip rank suffix (lowrank_r8 → lowrank etc.)
import re
df["regime"] = df["regime"].str.replace(r'_r\d+$', '', regex=True)

# Average over S and Nq — one d2 per (scheme, regime, budget)
agg = df.groupby(["scheme", "regime", "budget"])["d2"].mean().reset_index()

# Final 6 contenders — complete story from baseline to eigenbasis+QJL
FINAL_6 = ["Plain-KV", "TQ-KV", "TQ-QKV", "SQU-KV", "SQW-KV", "SQU-QKV"]

present = set(agg["scheme"].unique())
SCHEMES = [s for s in FINAL_6 if s in present]

REGIMES = [r for r in [
    "unit_sphere", "lowrank_aligned", "lowrank",
    "fattail", "lowrank_steep", "lowrank_misalign",
] if r in agg["regime"].unique()]

REGIME_LABELS = {
    "unit_sphere":      "Unit\nSphere",
    "lowrank_aligned":  "LR\nAligned",
    "lowrank":          "Lowrank",
    "fattail":          "Fattail",
    "lowrank_steep":    "LR\nSteep",
    "lowrank_misalign": "LR\nMisalign",
}

BUDGETS = args.budgets

# ── plot ──────────────────────────────────────────────────────────────────────

ncols = 3
nrows = (len(BUDGETS) + ncols - 1) // ncols
row_h = max(4, len(SCHEMES) * 0.6)
fig, axes = plt.subplots(nrows, ncols,
                         figsize=(6 * ncols, row_h * nrows),
                         squeeze=False)
axes_flat = [axes[r][c] for r in range(nrows) for c in range(ncols)]
# hide unused panels
for ax in axes_flat[len(BUDGETS):]:
    ax.set_visible(False)

for ax, budget in zip(axes_flat, BUDGETS):
    sub = agg[agg["budget"] == budget]

    # Build matrix: rows=schemes, cols=regimes
    mat = np.full((len(SCHEMES), len(REGIMES)), np.nan)
    rank_mat = np.full_like(mat, np.nan)

    for j, regime in enumerate(REGIMES):
        col = sub[sub["regime"] == regime].set_index("scheme")["d2"]
        vals = []
        for i, sch in enumerate(SCHEMES):
            if sch in col.index:
                mat[i, j] = col[sch]
                vals.append((col[sch], i))
        # Rank within this regime (1=best/lowest d2)
        vals_sorted = sorted(vals, key=lambda x: x[0])
        for rank, (_, i) in enumerate(vals_sorted):
            rank_mat[i, j] = rank + 1

    # Color by rank (1=green, N=red)
    n_schemes = len(SCHEMES)
    cmap = plt.cm.RdYlGn_r
    norm = mcolors.Normalize(vmin=1, vmax=n_schemes)

    im = ax.imshow(rank_mat, cmap=cmap, norm=norm, aspect="auto")

    # Annotate with d2 value and rank
    for i in range(len(SCHEMES)):
        for j in range(len(REGIMES)):
            if not np.isnan(mat[i, j]):
                rank = int(rank_mat[i, j])
                d2v  = mat[i, j]
                ax.text(j, i, f"#{rank}\n{d2v:.3f}",
                        ha="center", va="center", fontsize=9,
                        color="black",
                        fontweight="bold" if rank == 1 else "normal")

    ax.set_xticks(range(len(REGIMES)))
    ax.set_xticklabels([REGIME_LABELS[r] for r in REGIMES], fontsize=8)
    ax.set_yticks(range(len(SCHEMES)))
    ax.set_yticklabels(SCHEMES, fontsize=9)
    ax.set_title(f"Budget = {budget}", fontsize=11, fontweight="bold")
    ax.set_xlabel("Regime", fontsize=9)
    if ax == axes_flat[0]:
        ax.set_ylabel("Scheme", fontsize=9)


src_label = args.csv.split("/")[-1].replace(".csv", "")
fig.suptitle(f"d2 Ranking — {src_label}\n"
             "d2 = √((1−cosine)² + (relMSE/(1+relMSE))²)  lower = better",
             fontsize=11, y=1.02)

import os
os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
plt.tight_layout()
plt.savefig(args.out, dpi=150, bbox_inches="tight")
print(f"Saved: {args.out}")
