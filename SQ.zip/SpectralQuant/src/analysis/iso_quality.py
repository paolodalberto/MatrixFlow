"""
iso_quality.py — Iso-quality comparison: TQ-KV vs SQ schemes
=============================================================
For each TQ-KV (budget 2, 4, 6), find the SQ scheme+budget that achieves
the closest d2 quality, then compare storage (bytes/token).

If SQ achieves the same quality with fewer bytes → SQ is more efficient.
If SQ needs more bytes → TQ is more efficient.

Usage (from src/):
    python3 analysis/iso_quality.py \
        --csv64  csv/final6_gpu_d64_t200.csv  \
        --csv128 csv/final6_gpu_d128_t200.csv \
        --csv256 csv/final6_gpu_d256_t200.csv \
        --sq SQU-KV SQU-QKV \
        --regime lowrank_aligned lowrank fattail lowrank_misalign \
        --S 64 1024 4096 --d 256
"""

import argparse
import numpy as np
import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument("--csv64",   default="csv/final6_gpu_d64_t200.csv")
ap.add_argument("--csv128",  default="csv/final6_gpu_d128_t200.csv")
ap.add_argument("--csv256",  default="csv/final6_gpu_d256_t200.csv")
ap.add_argument("--ref",     default="TQ-KV")
ap.add_argument("--sq",      nargs="+", default=["SQU-KV", "SQU-QKV"])
ap.add_argument("--regime",  nargs="+",
                default=["lowrank_aligned","lowrank","fattail","lowrank_misalign"])
ap.add_argument("--S",       nargs="+", type=int, default=[64, 1024, 4096])
ap.add_argument("--d",       nargs="+", type=int, default=[128])
ap.add_argument("--budgets", nargs="+", type=int, default=[2, 4, 6],
                help="TQ-KV budgets to use as reference quality targets")
args = ap.parse_args()

# ── load ──────────────────────────────────────────────────────────────────────

PATH = {64: args.csv64, 128: args.csv128, 256: args.csv256}

dfs = []
for d_val in args.d:
    try:
        tmp = pd.read_csv(PATH[d_val])
        tmp["d_val"] = d_val
        dfs.append(tmp)
    except FileNotFoundError:
        print(f"Warning: {PATH[d_val]} not found, skipping d={d_val}")

df = pd.concat(dfs, ignore_index=True)
df["d2"] = np.sqrt((1-df["cosine"])**2 + (df["relMSE"]/(1+df["relMSE"]))**2)

# ── iso-quality comparison ────────────────────────────────────────────────────

for d_val in args.d:
    for S_val in args.S:
        sub = df[(df["d_val"]==d_val) & (df["S"]==S_val)]
        agg = sub.groupby(["scheme","regime","budget"]).agg(
            d2   = ("d2",     "mean"),
            vram = ("vram_B", "mean"),
        ).reset_index()

        print(f"\n{'='*80}")
        print(f"d={d_val}  S={S_val}")
        print(f"{'='*80}")

        for regime in args.regime:
            ref_df = agg[(agg["scheme"]==args.ref) & (agg["regime"]==regime)]
            if ref_df.empty:
                continue

            print(f"\n  Regime: {regime}")
            print(f"  {'TQ-KV':^30} | {'Closest SQ match':^45} | {'Δbytes':>8}  verdict")
            print(f"  {'b':>3} {'d2':>8} {'bytes':>8}  | "
                  f"{'scheme':<12} {'b':>3} {'d2':>8} {'bytes':>8}  |")
            print("  " + "-"*78)

            for b_ref in args.budgets:
                ref_row = ref_df[ref_df["budget"]==b_ref]
                if ref_row.empty:
                    continue
                d2_ref   = float(ref_row["d2"].iloc[0])
                vram_ref = float(ref_row["vram"].iloc[0])

                for sq_scheme in args.sq:
                    sq_df = agg[(agg["scheme"]==sq_scheme) & (agg["regime"]==regime)]
                    if sq_df.empty:
                        continue

                    # Find SQ entry with closest d2 to reference
                    sq_df = sq_df.copy()
                    sq_df["dist"] = (sq_df["d2"] - d2_ref).abs()
                    best    = sq_df.loc[sq_df["dist"].idxmin()]
                    d2_sq   = float(best["d2"])
                    vram_sq = float(best["vram"])
                    b_sq    = int(best["budget"])
                    delta   = int(vram_sq - vram_ref)

                    # Only meaningful if SQ quality is within 50% of TQ quality
                    quality_ratio = abs(d2_sq - d2_ref) / (d2_ref + 1e-9)
                    if quality_ratio > 0.5:
                        verdict = "SQ cannot match"
                    elif delta < -100:
                        verdict = "SQ saves"
                    elif delta > 100:
                        verdict = "TQ saves"
                    else:
                        verdict = "equal"

                    sign = "+" if delta >= 0 else ""
                    print(f"  {b_ref:>3} {d2_ref:>8.4f} {int(vram_ref):>8}  | "
                          f"{sq_scheme:<12} {b_sq:>3} {d2_sq:>8.4f} {int(vram_sq):>8}  | "
                          f"{sign}{delta:>7}  {verdict}")
