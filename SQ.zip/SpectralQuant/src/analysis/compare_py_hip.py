"""
compare_py_hip.py — numerical comparison between Python (oracle) and HIP sweep
===============================================================================
Runs both sweeps with matching parameters, joins on (scheme, budget, S, Nq),
and reports per-metric absolute differences.

Key expectations:
  ptcosine_K, ptcosine_V  — Q-independent, must match within float32 precision
                             (tolerance 1e-4). Any larger gap = codec bug.
  cosine, relMSE, KL      — Q-dependent (different RNGs), expect small gap.
                             Flagged if |delta| > 0.05 for cosine.

Usage (from src/hip/ directory where sweep binary lives):
  python ../../analysis/compare_py_hip.py \\
      --hip_bin ./sweep \\
      --regime unit_sphere \\
      --budget 2 3 \\
      --trials 10 \\
      --S 64 128 \\
      --scheme Plain-KV TQ-KV TQ-KQV TQ-QKV TQ-QKQV

The script runs the HIP binary, then runs the Python sweep in-process,
joins the results, and prints a diff table.
"""

import argparse
import subprocess
import sys
import io
import os
import pathlib
import numpy as np
import pandas as pd
from scipy.stats import ks_2samp

# ── paths ─────────────────────────────────────────────────────────────────────

HERE    = pathlib.Path(__file__).parent
SRC     = HERE.parent
PY_DIR  = SRC / "python"

sys.path.insert(0, str(SRC))

from python.codecs.tq_codec import (tq_solve_codebook, tq_roundtrip,
                                     tq_encode_qjl_score, tq_attention_score)
from python.codecs.qjl import make_sign_vector, make_sign_matrix
from python.codecs.sq_codec import (fit_codebook, sq_encode_K, sq_encode_V,
                                     sq_decode_V, sq_decode_K_for_metrics,
                                     sq_attention_score)

# ── argument parsing ──────────────────────────────────────────────────────────

ap = argparse.ArgumentParser()
ap.add_argument("--hip_bin",  default="./sweep")
ap.add_argument("--regime",   nargs="+", default=["unit_sphere"])
ap.add_argument("--budget",   nargs="+", type=int, default=[2, 3])
ap.add_argument("--trials",   type=int, default=10)
ap.add_argument("--S",        nargs="+", type=int, default=[64, 128])
ap.add_argument("--scheme",   nargs="+",
                default=["Plain-KV", "TQ-KV", "TQ-KQV", "TQ-QKV", "TQ-QKQV"])
ap.add_argument("--seed",     type=int, default=42)
ap.add_argument("--d",        type=int, default=128)
ap.add_argument("--m_qjl",   type=int, default=64)
args = ap.parse_args()

D    = args.d
SEED = args.seed
RNG  = np.random.default_rng(SEED)

# ── data generators (must match pquant_common.h make_* functions) ─────────────

def sph(rng, n):
    X = rng.standard_normal((n, D))
    return X / np.linalg.norm(X, axis=1, keepdims=True)

def make_unit_sphere(S, n_cal, rng):
    return sph(rng, S), sph(rng, S), sph(rng, n_cal)

def make_lowrank_aligned(S, n_cal, rng, rank=8, noise=0.05):
    A = rng.standard_normal((D, rank)) / np.sqrt(rank)
    def make(n): return rng.standard_normal((n, rank)) @ A.T + noise * rng.standard_normal((n, D))
    return make(S), make(S), make(n_cal)

def make_lowrank(S, n_cal, rng, rank=8):
    A = rng.standard_normal((D, rank)) / np.sqrt(rank)
    def make(n): return rng.standard_normal((n, rank)) @ A.T
    return make(S), make(S), make(n_cal)

def make_fattail(S, n_cal, rng, nu=3.0):
    def make(n):
        normal = rng.standard_normal((n, D))
        chi2   = rng.chisquare(nu, size=(n, D))
        return normal / np.sqrt(chi2 / nu + 1e-6)
    return make(S), make(S), make(n_cal)

def make_lowrank_steep(S, n_cal, rng, rank=4, base=2.0):
    lam = np.array([base**(-i) for i in range(rank)], dtype=float); lam /= lam.sum()
    A = rng.standard_normal((D, rank)); A, _ = np.linalg.qr(A); A = A[:, :rank]
    def make(n): return rng.standard_normal((n, rank)) * np.sqrt(lam) @ A.T
    return make(S), make(S), make(n_cal)

def make_lowrank_misalign(S, n_cal, rng, rank=4):
    AK = rng.standard_normal((D, rank)); AK, _ = np.linalg.qr(AK); AK = AK[:, :rank]
    AV = rng.standard_normal((D, rank)); AV, _ = np.linalg.qr(AV); AV = AV[:, :rank]
    K     = rng.standard_normal((S, rank)) @ AK.T / np.sqrt(rank)
    V     = rng.standard_normal((S, rank)) @ AV.T / np.sqrt(rank)
    K_cal = rng.standard_normal((n_cal, rank)) @ AK.T / np.sqrt(rank)
    # Return V as V_cal approximation (first n_cal rows used for SQ V calibration)
    return K, V, K_cal

REGIME_RANK = {
    "lowrank_aligned":  8,
    "lowrank":          8,
    "lowrank_steep":    4,
    "lowrank_misalign": 4,
    "unit_sphere":      32,  # let PR decide
    "fattail":          32,
}

REGIME_FN = {
    "unit_sphere":      make_unit_sphere,
    "lowrank_aligned":  make_lowrank_aligned,
    "lowrank":          make_lowrank,
    "lowrank_steep":    make_lowrank_steep,
    "lowrank_misalign": make_lowrank_misalign,
    "fattail":          make_fattail,
}

# ── attention helpers ─────────────────────────────────────────────────────────

def softmax(X):
    X = X - X.max(axis=-1, keepdims=True)
    E = np.exp(X); return E / E.sum(axis=-1, keepdims=True)

def attention(Q, K, V):
    W = softmax(Q @ K.T / np.sqrt(D))
    return W @ V, W

def cosine_mean(A, B):
    n = np.linalg.norm(A, axis=1) * np.linalg.norm(B, axis=1) + 1e-12
    return float(np.mean(np.sum(A * B, axis=1) / n))

def rel_mse(A, B):
    return float(np.sum((A-B)**2) / (np.sum(A**2) + 1e-30))

def pt_cosine(A, B):
    n = np.linalg.norm(A, axis=1) * np.linalg.norm(B, axis=1) + 1e-12
    return float(np.mean(np.sum(A * B, axis=1) / n))

def pt_relmse(A, B):
    num = np.sum((A-B)**2, axis=1)
    den = np.sum(A**2, axis=1) + 1e-30
    return float(np.mean(num / den))

# ── Python sweep ──────────────────────────────────────────────────────────────

# (wht, qjl_K_variant, qjl_V_variant)
# qjl_K/V_variant: "NONE", "RHT", "FULL"
SCHEME_FLAGS = {
    "Plain-KV":  (False, "NONE", "NONE"),
    "TQ-KV":     (True,  "NONE", "NONE"),
    "TQ-KQV":    (True,  "NONE", "RHT"),
    "TQ-QKV":    (True,  "RHT",  "NONE"),
    "TQ-QKQV":   (True,  "RHT",  "RHT"),
    "TQ-FKV":    (True,  "FULL", "NONE"),
    "TQ-KFV":    (True,  "NONE", "FULL"),
    "TQ-FKFV":   (True,  "FULL", "FULL"),
}

# SQ schemes: (family, qjl_K, qjl_V)
SQ_SCHEME_FLAGS = {
    "SQU-KV":   ("SQU", False, False),
    "SQU-QKV":  ("SQU", True,  False),
    "SQU-KQV":  ("SQU", False, True),
    "SQU-QKQV": ("SQU", True,  True),
    "SQW-KV":   ("SQW", False, False),
    "SQW-QKV":  ("SQW", True,  False),
    "SQW-KQV":  ("SQW", False, True),
    "SQW-QKQV": ("SQW", True,  True),
}

NQ_VALS = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512]

def run_python_sweep():
    print("[Python] running sweep...", file=sys.stderr)
    rows = []
    rng  = np.random.default_rng(SEED)

    # Pre-solve all codebooks (budget → cb), reused across schemes
    needed_bits = set()
    for budget in args.budget:
        needed_bits.add(budget)
        needed_bits.add(budget - 1)
    needed_bits.discard(0)
    print(f"[Python] solving codebooks for bits={sorted(needed_bits)}...", file=sys.stderr)
    codebooks = {n: tq_solve_codebook(D, n) for n in sorted(needed_bits)}
    print("[Python] codebooks ready.", file=sys.stderr)

    for regime in args.regime:
        fn = REGIME_FN[regime]
        max_S = max(args.S)
        K_all, V_all, K_cal = fn(max_S, 512, rng)

        for S in sorted(args.S):
            K = K_all[:S]; V = V_all[:S]

            # Draw signs once per (regime, S) — same order as main.hip
            wht_signs = rng.choice([-1., 1.], size=D).astype(np.float32)
            S2_K      = rng.choice([-1., 1.], size=D).astype(np.float32)
            S2_V      = rng.choice([-1., 1.], size=D).astype(np.float32)
            _S_mat_K  = rng.choice([-1., 1.], size=(D, D)).astype(np.float32)

            for budget in args.budget:
                print(f"[Python] regime={regime} S={S} budget={budget}", file=sys.stderr)
                for scheme_name in args.scheme:
                    if scheme_name not in SCHEME_FLAGS:
                        continue
                    wht, var_K, var_V = SCHEME_FLAGS[scheme_name]
                    qjl_K = var_K != "NONE"
                    qjl_V = var_V != "NONE"
                    nK = budget - int(qjl_K)
                    nV = budget - int(qjl_V)
                    if nK < 1 or nV < 1:
                        continue

                    cb_K = codebooks[nK]
                    cb_V = codebooks[nV]

                    # Select sign vectors based on variant
                    S_K = (make_sign_matrix(D, np.random.default_rng(SEED^0xCAFE))
                           if var_K == "FULL" else S2_K)
                    S_V = (make_sign_matrix(D, np.random.default_rng(SEED^0xBEEF))
                           if var_V == "FULL" else S2_V)

                    # Encode K and V
                    if wht:
                        K_hat = tq_roundtrip(K, cb_K, use_qjl=False)
                        V_hat = tq_roundtrip(V, cb_V,
                                             use_qjl=qjl_V,
                                             S2=S_V if qjl_V else None)
                    else:
                        # Plain-KV: scalar quantization, no WHT
                        # Normalize → quantize scalar per dim → reconstruct
                        norms_K = np.linalg.norm(K, axis=1, keepdims=True) + 1e-12
                        norms_V = np.linalg.norm(V, axis=1, keepdims=True) + 1e-12
                        Kn = K / norms_K; Vn = V / norms_V
                        # Quantize each dim independently with cb boundaries
                        def plain_roundtrip(Xn, cb, norms):
                            bnd = cb.boundaries[1:-1]
                            idx = np.clip(np.searchsorted(bnd, Xn), 0, len(cb.centroids)-1)
                            return cb.centroids[idx] * norms
                        K_hat = plain_roundtrip(Kn, cb_K, norms_K)
                        V_hat = plain_roundtrip(Vn, cb_V, norms_V)

                    if qjl_K:
                        k_score_enc = tq_encode_qjl_score(K, cb_K, S_K)
                    else:
                        k_score_enc = None

                    ptcos_K   = pt_cosine(K, K_hat)
                    ptcos_V   = pt_cosine(V, V_hat)
                    ptrelmse_K = pt_relmse(K, K_hat)
                    ptrelmse_V = pt_relmse(V, V_hat)

                    for Nq in NQ_VALS:
                        if Nq > S: continue

                        sum_cos = sum_mse = sum_kl = sum_topk = 0.0
                        sum_mse_K = sum_mse_V = 0.0
                        trial_rng = np.random.default_rng(SEED ^ 0xBEEF1234)
                        for _ in range(args.trials):
                            Q = trial_rng.standard_normal((Nq, D))
                            T_ref, W_ref = attention(Q, K, V)
                            if qjl_K and k_score_enc is not None:
                                scores = tq_attention_score(Q, k_score_enc, S_K)
                                scores /= np.sqrt(D)
                                W_hat  = softmax(scores)
                                T_hat  = W_hat @ V_hat
                            else:
                                T_hat, W_hat = attention(Q, K_hat, V_hat)

                            # K-isolation: K_hat + V_ref
                            _, W_Ko = attention(Q, K_hat, V)
                            T_Ko = W_Ko @ V
                            # V-isolation: K_ref + V_hat
                            _, W_Vo = attention(Q, K, V_hat)
                            T_Vo = W_Vo @ V_hat

                            # KL divergence
                            P = np.clip(W_ref, 1e-12, None)
                            R = np.clip(W_hat, 1e-12, None)
                            kl = float(np.mean(np.sum(P * np.log(P / R), axis=1)))

                            # top-5 recall
                            k5 = min(5, S)
                            top_ref = np.argsort(W_ref, axis=1)[:, -k5:]
                            top_hat = np.argsort(W_hat, axis=1)[:, -k5:]
                            topk = float(np.mean([
                                len(np.intersect1d(top_ref[i], top_hat[i])) / k5
                                for i in range(Nq)]))

                            sum_cos   += cosine_mean(T_ref, T_hat)
                            sum_mse   += rel_mse(T_ref, T_hat)
                            sum_kl    += kl
                            sum_topk  += topk
                            sum_mse_K += rel_mse(T_ref, T_Ko)
                            sum_mse_V += rel_mse(T_ref, T_Vo)

                        nt = args.trials
                        _cos = sum_cos / nt; _mse = sum_mse / nt
                        _d2  = float(np.sqrt((1-_cos)**2 + (_mse/(1+_mse))**2))
                        rows.append({
                            "scheme":    scheme_name,
                            "budget":    budget,
                            "S":         S,
                            "Nq":        Nq,
                            "regime":    regime,
                            "ptcosine_K": ptcos_K,
                            "ptcosine_V": ptcos_V,
                            "ptrelMSE_K": ptrelmse_K,
                            "ptrelMSE_V": ptrelmse_V,
                            "cosine":    _cos,
                            "relMSE":    _mse,
                            "KL":        sum_kl   / nt,
                            "topk5":     sum_topk / nt,
                            "relMSE_K":  sum_mse_K / nt,
                            "relMSE_V":  sum_mse_V / nt,
                            "d2":        _d2,
                        })

    # ── SQ schemes ────────────────────────────────────────────────────────────
    sq_schemes_requested = [s for s in args.scheme if s in SQ_SCHEME_FLAGS]
    if sq_schemes_requested:
        for regime in args.regime:
            fn = REGIME_FN[regime]
            for S in sorted(args.S):
                # Independent rng per (regime, S) — K_cal independent from K/V test data
                rng_data = np.random.default_rng(SEED ^ (hash(regime) & 0xFFFFFFFF) ^ S)
                K, V, K_cal = fn(S, 512, rng_data)
                print(f"[Python SQ] regime={regime} S={S}", file=sys.stderr)

                # Calibrate once per (regime, S)
                # V calibration: use V data (first n_cal rows) for correct subspace.
                # KNOWN LIMITATION: for lowrank_misalign, K and V live in different
                # subspaces so V must be calibrated on V tokens, not K_cal.
                # However, using test tokens as cal leaks information when S is small
                # (S=256: all test tokens used as cal → near-perfect reconstruction).
                # This is acceptable for large S (S≥1024: 512 cal vs 1024+ test).
                # The production sweep (sweep.py) generates independent V_cal correctly.
                # This comparison script is for validation only — use sweep.py CSVs
                # for ranking figures.
                # V_cal: for aligned regimes K and V share the same subspace, so
                # K_cal is a valid calibration set for V too. Using a fresh rng would
                # draw a different random basis entirely — wrong subspace for V.
                # For lowrank_misalign K and V live in orthogonal subspaces; V_cal
                # should ideally be V tokens, but this script uses K_cal as an
                # approximation (validation only — production sweep handles correctly).
                V_cal = K_cal
                max_deff = REGIME_RANK[regime]

                for budget in args.budget:
                    cb_K = fit_codebook(K_cal, K_cal, b_target=budget, b_tail=2, uniform=True, max_d_eff=max_deff)
                    cb_V = fit_codebook(K_cal, V_cal, b_target=budget, b_tail=2, uniform=True, max_d_eff=max_deff)
                    cb_K_qjl = fit_codebook(K_cal, K_cal, b_target=max(1,budget-1), b_tail=min(2,budget-1), uniform=True, max_d_eff=max_deff)

                    S_qjl_K = make_sign_matrix(cb_K.d_eff_K, np.random.default_rng(SEED^0xCAFE),
                                               m=args.m_qjl) if hasattr(args, 'm_qjl') else \
                              make_sign_matrix(cb_K.d_eff_K, np.random.default_rng(SEED^0xCAFE), m=64)

                    for scheme_name in sq_schemes_requested:
                        family, qjl_K, qjl_V = SQ_SCHEME_FLAGS[scheme_name]
                        nK = budget - int(qjl_K)
                        nV = budget - int(qjl_V)
                        if nK < 1 or nV < 1: continue

                        cb_use_K = cb_K_qjl if qjl_K else cb_K
                        cb_use_V = cb_K_qjl if qjl_V else cb_V

                        S_qjl_use = S_qjl_K if qjl_K else None
                        enc_K = sq_encode_K(K, cb_use_K, S_qjl=S_qjl_use)
                        enc_V = sq_encode_V(V, cb_use_V, S_qjl=None)
                        K_hat = sq_decode_K_for_metrics(enc_K, cb_use_K)
                        V_hat = sq_decode_V(enc_V, cb_use_V)

                        ptcos_K    = pt_cosine(K, K_hat)
                        ptcos_V    = pt_cosine(V, V_hat)
                        ptrelmse_K = pt_relmse(K, K_hat)
                        ptrelmse_V = pt_relmse(V, V_hat)

                        for Nq in NQ_VALS:
                            if Nq > S: continue
                            sum_cos=sum_mse=sum_kl=sum_topk=0.0
                            sum_mse_K=sum_mse_V=0.0
                            trial_rng = np.random.default_rng(SEED ^ 0xBEEF1234)
                            for _ in range(args.trials):
                                Q = trial_rng.standard_normal((Nq, D))
                                T_ref, W_ref = attention(Q, K, V)
                                scores = sq_attention_score(Q, enc_K, cb_use_K,
                                                             S_qjl=S_qjl_use) / np.sqrt(D)
                                W_hat = softmax(scores)
                                T_hat = W_hat @ V_hat
                                _, W_Ko = attention(Q, K_hat, V); T_Ko = W_Ko @ V
                                _, W_Vo = attention(Q, K, V_hat); T_Vo = W_Vo @ V_hat
                                P = np.clip(W_ref,1e-12,None); R = np.clip(W_hat,1e-12,None)
                                kl = float(np.mean(np.sum(P*np.log(P/R),axis=1)))
                                k5 = min(5,S)
                                top_ref = np.argsort(W_ref,axis=1)[:,-k5:]
                                top_hat = np.argsort(W_hat,axis=1)[:,-k5:]
                                topk = float(np.mean([len(np.intersect1d(top_ref[i],top_hat[i]))/k5
                                                       for i in range(Nq)]))
                                sum_cos+=cosine_mean(T_ref,T_hat); sum_mse+=rel_mse(T_ref,T_hat)
                                sum_kl+=kl; sum_topk+=topk
                                sum_mse_K+=rel_mse(T_ref,T_Ko); sum_mse_V+=rel_mse(T_ref,T_Vo)
                            nt = args.trials
                            _cos = sum_cos/nt; _mse = sum_mse/nt
                            _d2 = float(np.sqrt((1-_cos)**2 + (_mse/(1+_mse))**2))
                            rows.append({"scheme":scheme_name,"budget":budget,"S":S,"Nq":Nq,
                                         "regime":regime,
                                         "ptcosine_K":ptcos_K,"ptcosine_V":ptcos_V,
                                         "ptrelMSE_K":ptrelmse_K,"ptrelMSE_V":ptrelmse_V,
                                         "cosine":_cos,"relMSE":_mse,
                                         "KL":sum_kl/nt,"topk5":sum_topk/nt,
                                         "relMSE_K":sum_mse_K/nt,"relMSE_V":sum_mse_V/nt,
                                         "d2":_d2})

    return pd.DataFrame(rows)

# ── HIP sweep ─────────────────────────────────────────────────────────────────

def run_hip_sweep():
    print("[HIP] running sweep...", file=sys.stderr)
    cmd = [
        args.hip_bin,
        "--trials", str(args.trials),
        "--seed",   str(SEED),
        "--regime", *args.regime,
        "--budget", *[str(b) for b in args.budget],
        "--scheme", *args.scheme,
        "--S",      *[str(s) for s in args.S],
    ]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=None, text=True)
    if result.returncode != 0:
        sys.exit(1)

    df = pd.read_csv(io.StringIO(result.stdout))
    df["d2"] = np.sqrt((1-df["cosine"])**2 + (df["relMSE"]/(1+df["relMSE"]))**2)
    # Filter to requested S values
    df = df[df["S"].isin(args.S)].copy()
    return df

# ── comparison ────────────────────────────────────────────────────────────────

def compare(py: pd.DataFrame, hip: pd.DataFrame):
    KEY = ["scheme", "budget", "S", "Nq", "regime"]
    METRICS = [
        "ptcosine_K", "ptcosine_V", "ptrelMSE_K", "ptrelMSE_V",
        "cosine", "relMSE", "d2", "KL", "topk5", "relMSE_K", "relMSE_V",
    ]

    merged = py.merge(hip, on=KEY, suffixes=("_py", "_hip"))
    if merged.empty:
        print("ERROR: no matching rows after join — check regime/scheme/S alignment")
        sys.exit(1)

    W = 108
    n = len(merged)
    print(f"\n{'='*W}")
    print(f"Python vs HIP comparison  ({n} matched rows)  "
          f"[~ p>=0.05  * p<0.05  ** p<0.001]")
    print(f"{'='*W}")
    print(f"{'Metric':<16} {'py μ±σ':>16} {'hip μ±σ':>16} {'Δμ±σ(Δ)':>18} {'z':>6} {'KS':>6} {'p':>8}  {'sig'}")
    print(f"{'-'*W}")

    for m in METRICS:
        col_py  = f"{m}_py"
        col_hip = f"{m}_hip"
        if col_py not in merged or col_hip not in merged:
            print(f"{m:<16} {'N/A':>16}")
            continue
        py_mu  = merged[col_py].mean();  py_sig  = merged[col_py].std()
        hip_mu = merged[col_hip].mean(); hip_sig = merged[col_hip].std()
        delta  = (merged[col_py] - merged[col_hip]).abs()
        mean_d = delta.mean()
        sig_d  = delta.std()
        z      = mean_d / (sig_d / np.sqrt(n)) if sig_d > 0 else float('inf')
        ks_stat, ks_p = ks_2samp(merged[col_py].values, merged[col_hip].values)
        sig    = "**" if ks_p < 0.001 else ("*" if ks_p < 0.05 else "~")
        py_str  = f"{py_mu:.4f}±{py_sig:.4f}"
        hip_str = f"{hip_mu:.4f}±{hip_sig:.4f}"
        d_str   = f"{mean_d:.6f}±{sig_d:.6f}"
        print(f"{m:<16} {py_str:>16} {hip_str:>16} {d_str:>18} {z:>6.1f} {ks_stat:>6.3f} {ks_p:>8.4f}  {sig}")

    print(f"{'='*W}")


# ── main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    py_df  = run_python_sweep()
    hip_df = run_hip_sweep()

    py_df.to_csv("/tmp/compare_py.csv",  index=False)
    hip_df.to_csv("/tmp/compare_hip.csv", index=False)
    print(f"[saved] /tmp/compare_py.csv  ({len(py_df)} rows)", file=sys.stderr)
    print(f"[saved] /tmp/compare_hip.csv ({len(hip_df)} rows)", file=sys.stderr)

    compare(py_df, hip_df)
