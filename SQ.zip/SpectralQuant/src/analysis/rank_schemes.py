"""
rank_schemes.py — compare Python vs HIP scheme rankings via d2 metric
======================================================================
Runs all 8 TQ schemes on a given regime, computes d2 = sqrt(AS² + NF²)
where AS = 1-cosine, NF = relMSE/(1+relMSE), then ranks both sides
and shows where they agree/disagree.

Usage (from src/hip/):
    python3 ../analysis/rank_schemes.py --hip_bin ./sweep \
        --regime fattail --budget 2 3 4 --S 64 128 256 --trials 200
"""

import argparse
import subprocess
import sys
import io
import os
import pathlib
import numpy as np
import pandas as pd

HERE = pathlib.Path(__file__).parent
SRC  = HERE.parent
sys.path.insert(0, str(SRC))

from python.codecs.tq_codec import (tq_solve_codebook, tq_roundtrip,
                                     tq_encode_qjl_score, tq_attention_score)
from python.codecs.qjl import make_sign_vector, make_sign_matrix

ap = argparse.ArgumentParser()
ap.add_argument("--hip_bin",  default="./sweep")
ap.add_argument("--regime",   nargs="+", default=["fattail"])
ap.add_argument("--budget",   nargs="+", type=int, default=[2, 3, 4])
ap.add_argument("--S",        nargs="+", type=int, default=[64, 128, 256])
ap.add_argument("--trials",   type=int, default=200)
ap.add_argument("--seed",     type=int, default=42)
ap.add_argument("--d",        type=int, default=128)
args = ap.parse_args()

D    = args.d
SEED = args.seed
RNG  = np.random.default_rng(SEED)

SCHEMES = [
    "Plain-KV",
    "TQ-KV",
    "TQ-QKV", "TQ-FKV",
    "TQ-KQV", "TQ-KFV",
    "TQ-QKQV", "TQ-FKFV",
]

SCHEME_FLAGS = {
    "Plain-KV":  (False, "NONE", "NONE"),
    "TQ-KV":     (True,  "NONE", "NONE"),
    "TQ-KQV":    (True,  "NONE", "RHT"),
    "TQ-QKV":    (True,  "RHT",  "NONE"),
    "TQ-QKQV":   (True,  "RHT",  "RHT"),
    "TQ-FKV":    (True,  "FULL", "NONE"),
    "TQ-KFV":    (True,  "NONE", "FULL"),
    "TQ-FKFV":   (True,  "FULL", "FULL"),
}

NQ_VALS = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512]

def d2(cosine, relMSE):
    AS = 1.0 - cosine
    NF = relMSE / (1.0 + relMSE)
    return np.sqrt(AS**2 + NF**2)

def softmax(X):
    X = X - X.max(axis=-1, keepdims=True)
    E = np.exp(X); return E / E.sum(axis=-1, keepdims=True)

def attention(Q, K, V):
    W = softmax(Q @ K.T / np.sqrt(D))
    return W @ V, W

def cosine_mean(A, B):
    n = np.linalg.norm(A, axis=1) * np.linalg.norm(B, axis=1) + 1e-12
    return float(np.mean(np.sum(A * B, axis=1) / n))

def rel_mse(A, B):
    return float(np.sum((A-B)**2) / (np.sum(A**2) + 1e-30))

def make_fattail(S, rng, nu=3.0):
    normal = rng.standard_normal((S, D))
    chi2   = rng.chisquare(nu, size=(S, D))
    return normal / np.sqrt(chi2 / nu + 1e-6)

def make_unit_sphere(S, rng):
    X = rng.standard_normal((S, D))
    return X / np.linalg.norm(X, axis=1, keepdims=True)

def make_lowrank(S, rng, rank=8):
    A = rng.standard_normal((D, rank)) / np.sqrt(rank)
    return rng.standard_normal((S, rank)) @ A.T

REGIME_FN = {"fattail": make_fattail, "unit_sphere": make_unit_sphere, "lowrank": make_lowrank}

# ── Python sweep ──────────────────────────────────────────────────────────────

def run_python():
    print("[Python] running...", file=sys.stderr)
    needed = set()
    for b in args.budget:
        needed.add(b); needed.add(b-1)
    needed.discard(0)
    codebooks = {n: tq_solve_codebook(D, n) for n in sorted(needed)}

    rows = []
    rng  = np.random.default_rng(SEED)

    for regime in args.regime:
        fn = REGIME_FN[regime]
        max_S = max(args.S)
        K_all = fn(max_S, rng); V_all = fn(max_S, rng)

        wht_signs = rng.choice([-1.,1.], size=D).astype(np.float32)
        S2_K      = make_sign_vector(D, rng)
        S2_V      = make_sign_vector(D, rng)
        S_mat_K   = make_sign_matrix(D, rng)
        S_mat_V   = make_sign_matrix(D, rng)

        for S in sorted(args.S):
            K = K_all[:S]; V = V_all[:S]
            for budget in args.budget:
                print(f"[Python] regime={regime} S={S} budget={budget}", file=sys.stderr)
                for scheme in SCHEMES:
                    wht, var_K, var_V = SCHEME_FLAGS[scheme]
                    qjl_K = var_K != "NONE"; qjl_V = var_V != "NONE"
                    nK = budget - int(qjl_K); nV = budget - int(qjl_V)
                    if nK < 1 or nV < 1: continue

                    cb_K = codebooks[nK]; cb_V = codebooks[nV]
                    S_K = S_mat_K if var_K == "FULL" else S2_K
                    S_V = S_mat_V if var_V == "FULL" else S2_V

                    if wht:
                        K_hat = tq_roundtrip(K, cb_K, use_qjl=False)
                        V_hat = tq_roundtrip(V, cb_V, use_qjl=qjl_V, S2=S_V if qjl_V else None)
                    else:
                        norms_K = np.linalg.norm(K, axis=1, keepdims=True) + 1e-12
                        norms_V = np.linalg.norm(V, axis=1, keepdims=True) + 1e-12
                        def plain_rt(Xn, cb, norms):
                            bnd = cb.boundaries[1:-1]
                            idx = np.clip(np.searchsorted(bnd, Xn/norms), 0, len(cb.centroids)-1)
                            return cb.centroids[idx] * norms
                        K_hat = plain_rt(K, cb_K, norms_K)
                        V_hat = plain_rt(V, cb_V, norms_V)

                    k_enc = tq_encode_qjl_score(K, cb_K, S_K) if qjl_K else None

                    sum_cos = sum_mse = 0.0
                    trial_rng = np.random.default_rng(SEED ^ 0xBEEF1234)
                    for _ in range(args.trials):
                        Q = trial_rng.standard_normal((32, D))  # fixed Nq=32
                        T_ref, _ = attention(Q, K, V)
                        if qjl_K and k_enc:
                            sc = tq_attention_score(Q, k_enc, S_K) / np.sqrt(D)
                            W  = softmax(sc); T_hat = W @ V_hat
                        else:
                            T_hat, _ = attention(Q, K_hat, V_hat)
                        sum_cos += cosine_mean(T_ref, T_hat)
                        sum_mse += rel_mse(T_ref, T_hat)

                    nt = args.trials
                    rows.append({"scheme": scheme, "budget": budget, "S": S, "regime": regime,
                                 "cosine": sum_cos/nt, "relMSE": sum_mse/nt,
                                 "d2": float(d2(sum_cos/nt, sum_mse/nt))})
    return pd.DataFrame(rows)

# ── HIP sweep ─────────────────────────────────────────────────────────────────

def run_hip():
    print("[HIP] running...", file=sys.stderr)
    cmd = [args.hip_bin,
           "--trials", str(args.trials), "--seed", str(SEED),
           "--regime", *args.regime,
           "--budget", *[str(b) for b in args.budget],
           "--scheme", *SCHEMES,
           "--S",      *[str(s) for s in args.S]]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=None, text=True)
    df = pd.read_csv(io.StringIO(result.stdout))
    df = df[df["S"].isin(args.S)].copy()
    df["d2"] = np.sqrt((1-df["cosine"])**2 + (df["relMSE"]/(1+df["relMSE"]))**2)
    return df

# ── summary table ─────────────────────────────────────────────────────────────

def summarize(py_df, hip_df):
    for regime in args.regime:
        py_r  = py_df[py_df["regime"] == regime]
        hip_r = hip_df[hip_df["regime"] == regime]

        for budget in args.budget:
            py_b  = py_r[py_r["budget"] == budget].groupby("scheme")["d2"].mean()
            hip_b = hip_r[hip_r["budget"] == budget].groupby("scheme")["d2"].mean()

            all_schemes = [s for s in SCHEMES if s in py_b.index and s in hip_b.index]
            py_ranked  = sorted(all_schemes, key=lambda s: py_b[s])
            hip_ranked = sorted(all_schemes, key=lambda s: hip_b[s])

            print(f"\nRegime={regime}  Budget={budget}  d2 (lower=better)")
            print(f"{'Scheme':<12} {'py d2':>8} {'py rank':>8} {'hip d2':>8} {'hip rank':>9} {'agree':>7}")
            print("-" * 58)
            for sch in all_schemes:
                py_rank  = py_ranked.index(sch) + 1
                hip_rank = hip_ranked.index(sch) + 1
                agree    = "✓" if py_rank == hip_rank else f"Δ{abs(py_rank-hip_rank)}"
                print(f"{sch:<12} {py_b[sch]:>8.4f} {py_rank:>8} {hip_b[sch]:>8.4f} {hip_rank:>9} {agree:>7}")

py_df  = run_python()
hip_df = run_hip()
summarize(py_df, hip_df)
