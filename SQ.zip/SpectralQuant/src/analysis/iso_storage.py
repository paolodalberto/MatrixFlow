"""
iso_storage.py — Iso-storage comparison: TQ-KV vs SQ schemes
==============================================================
For each TQ-KV budget b, find the SQ budget b_SQ such that
vram(SQ, b_SQ) <= vram(TQ-KV, b), then compare d2 at that point.

Outputs a LaTeX table ready to paste into the paper.

Usage (from src/):
    python3 analysis/iso_storage.py \
        --csv csv/final6_gpu_d128_t200.csv \
        --ref TQ-KV \
        --sq  SQU-KV SQU-QKV SQW-KV \
        --regime lowrank_aligned lowrank fattail lowrank_misalign
"""

import argparse
import numpy as np
import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument("--csv",     default="csv/final6_gpu_d128_t200.csv")
ap.add_argument("--csv64",   default="csv/final6_gpu_d64_t200.csv")
ap.add_argument("--csv256",  default="csv/final6_gpu_d256_t200.csv")
ap.add_argument("--ref",     default="TQ-KV")
ap.add_argument("--sq",      nargs="+", default=["SQU-KV", "SQU-QKV"])
ap.add_argument("--regime",  nargs="+",
                default=["lowrank_aligned","lowrank","fattail","lowrank_misalign"])
ap.add_argument("--S",       nargs="+", type=int, default=[64, 1024, 4096])
ap.add_argument("--d",       nargs="+", type=int, default=[64, 128, 256])
ap.add_argument("--out",     default=None)
args = ap.parse_args()

# ── load all three d values ───────────────────────────────────────────────────

dfs = []
for d_val, path in [(64, args.csv64), (128, args.csv), (256, args.csv256)]:
    if d_val not in args.d:
        continue
    try:
        tmp = pd.read_csv(path)
        tmp["d_val"] = d_val
        dfs.append(tmp)
    except FileNotFoundError:
        print(f"Warning: {path} not found, skipping d={d_val}")

df = pd.concat(dfs, ignore_index=True)
df["d2"] = np.sqrt((1-df["cosine"])**2 + (df["relMSE"]/(1+df["relMSE"]))**2)

# Filter to requested S values and average over Nq only
df = df[df["S"].isin(args.S)].copy()
agg = df.groupby(["scheme","regime","budget","S","d_val"]).agg(
    d2    = ("d2",     "mean"),
    vram  = ("vram_B", "mean"),
).reset_index()

# ── iso-storage comparison ────────────────────────────────────────────────────

BUDGETS = sorted(agg["budget"].unique())

rows = []
for regime in args.regime:
  for d_val in args.d:
    for S_val in args.S:
      ref_df = agg[(agg["scheme"] == args.ref) & (agg["regime"] == regime) &
                   (agg["d_val"] == d_val) & (agg["S"] == S_val)]

      for b_ref in BUDGETS:
        ref_row = ref_df[ref_df["budget"] == b_ref]
        if ref_row.empty: continue
        vram_ref = float(ref_row["vram"].iloc[0])
        d2_ref   = float(ref_row["d2"].iloc[0])

        for sq_scheme in args.sq:
            sq_df = agg[(agg["scheme"] == sq_scheme) & (agg["regime"] == regime) &
                        (agg["d_val"] == d_val) & (agg["S"] == S_val)]
            if sq_df.empty: continue

            feasible = sq_df[sq_df["vram"] <= vram_ref].sort_values("budget", ascending=False)
            if feasible.empty:
                feasible = sq_df.sort_values("budget")

            best    = feasible.iloc[0]
            d2_sq   = float(best["d2"])
            b_sq    = int(best["budget"])
            vram_sq = float(best["vram"])
            delta   = d2_sq - d2_ref
            verdict = "SQ wins" if delta < -0.005 else \
                      ("ties" if abs(delta) <= 0.005 else "TQ wins")

            rows.append({
                "regime":    regime,
                "d":         d_val,
                "S":         S_val,
                "ref_b":     b_ref,
                "ref_vram":  vram_ref,
                "ref_d2":    d2_ref,
                "sq_scheme": sq_scheme,
                "sq_b":      b_sq,
                "sq_vram":   vram_sq,
                "sq_d2":     d2_sq,
                "delta":     delta,
                "verdict":   verdict,
            })

result = pd.DataFrame(rows)

# ── print summary ──────────────────────────────────────────────────────────────

print("\n=== ISO-STORAGE COMPARISON ===")
print(f"Reference: {args.ref}")
for d_val in args.d:
  for S_val in args.S:
    subset = result[(result["d"]==d_val) & (result["S"]==S_val)]
    if subset.empty: continue
    print(f"\n--- d={d_val}, S={S_val} ---")
    print(f"{'Regime':<20} {'b_TQ':>5} {'d2_TQ':>7} | "
          f"{'SQ scheme':<12} {'b_SQ':>5} {'d2_SQ':>7} {'Δd2':>7} {'verdict'}")
    print("-"*75)
    for _, r in subset.iterrows():
        print(f"{r['regime']:<20} {r['ref_b']:>5} {r['ref_d2']:>7.4f} | "
              f"{r['sq_scheme']:<12} {r['sq_b']:>5} {r['sq_d2']:>7.4f} "
              f"{r['delta']:>+7.4f} {r['verdict']}")

# ── LaTeX table ───────────────────────────────────────────────────────────────

latex = []
latex.append(r"\begin{table}[h]")
latex.append(r"\centering")
latex.append(r"\caption{Iso-storage comparison: for each TQ-KV budget the best SQ scheme")
latex.append(r"  at equal or lower memory is identified and $\dtwo$ compared.")
latex.append(r"  $\Delta\dtwo = \dtwo(\text{SQ}) - \dtwo(\text{TQ-KV})$; negative = SQ wins.}")
latex.append(r"\label{tab:isostorage}")
latex.append(r"\small")
latex.append(r"\begin{tabular}{@{}llrrrrrr@{}}")
latex.append(r"\toprule")
latex.append(r"Regime & SQ scheme & $b_{\text{TQ}}$ & bytes & $\dtwo$(TQ) & "
             r"$b_{\text{SQ}}$ & $\dtwo$(SQ) & $\Delta\dtwo$ \\")
latex.append(r"\midrule")

prev_regime = None
# Show only b=3 and b=5 for compactness
for _, r in result[result["ref_b"].isin([3, 5])].iterrows():
    regime_str = r["regime"].replace("_", r"\_") if r["regime"] != prev_regime else ""
    prev_regime = r["regime"]
    delta_str = f"${r['delta']:+.3f}$"
    if r["delta"] < -0.005:
        delta_str = r"\textbf{" + delta_str + "}"
    latex.append(
        f"{regime_str} & {r['sq_scheme']} & {r['ref_b']} & "
        f"{r['ref_vram']:.0f} & {r['ref_d2']:.3f} & "
        f"{r['sq_b']} & {r['sq_d2']:.3f} & {delta_str} \\\\"
    )

latex.append(r"\bottomrule")
latex.append(r"\end{tabular}")
latex.append(r"\end{table}")

print("\n\n=== LaTeX TABLE ===")
print("\n".join(latex))

if args.out:
    with open(args.out, "w") as f:
        f.write("\n".join(latex))
    print(f"\nSaved to {args.out}")
