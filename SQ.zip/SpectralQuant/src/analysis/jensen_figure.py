"""
jensen_figure.py — Experimental demonstration of Jensen amplification
======================================================================
Shows that QJL-K's T output depends on S_mat_K (Jensen-sensitive) while
K reconstruction and QJL-V are S_mat-independent.

Two panels:
  Left:  ptcosine_K vs budget — identical across all implementations
  Right: cosine (T output) vs budget — gap between Python and GPU for TQ-QKV,
         no gap for TQ-KV or TQ-KQV

Usage:
    python jensen_figure.py \
        --gpu    ./hip/csv/tq_d64_t200.csv \
        --py_new /tmp/py_fattail_qredrawn.csv \
        --out    /tmp/jensen_figure.png
"""

import argparse
import pathlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ap = argparse.ArgumentParser()
ap.add_argument("--gpu",    required=True, help="GPU 200-trial CSV")
ap.add_argument("--py_new", required=True, help="Python new (Q redrawn) CSV")
ap.add_argument("--py_old", default=None,  help="Python old (Q fixed) CSV (optional)")
ap.add_argument("--regime", default="fattail")
ap.add_argument("--S",      type=int, default=64)
ap.add_argument("--out",    default="jensen_figure.png")
ap.add_argument("--dpi",    type=int, default=180)
args = ap.parse_args()

def load(path):
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    df["dir_T"] = 1.0 - df["cosine"]
    return df

gpu    = load(args.gpu)
py_new = load(args.py_new)
py_old = load(args.py_old) if args.py_old else None

budgets = sorted(gpu["budget"].unique())

def med(df, scheme, metric):
    sub = df[(df["regime"]==args.regime) & (df["scheme"]==scheme) &
             (df["S"]==args.S)]
    return [sub[sub["budget"]==b][metric].median() for b in budgets]

# ── figure ────────────────────────────────────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(12, 5))
fig.subplots_adjust(wspace=0.35)

# Colour/style scheme
STYLES = {
    "gpu_tqkv":    dict(color="#2166ac", ls="-",  marker="o", lw=2.0, label="GPU: TQ-KV"),
    "gpu_tqqkv":   dict(color="#d73027", ls="-",  marker="o", lw=2.0, label="GPU: TQ-QKV"),
    "gpu_tqkqv":   dict(color="#4dac26", ls="-",  marker="o", lw=2.0, label="GPU: TQ-KQV"),
    "py_tqkv":     dict(color="#2166ac", ls="--", marker="s", lw=1.5, label="Python: TQ-KV"),
    "py_tqqkv":    dict(color="#d73027", ls="--", marker="s", lw=1.5, label="Python: TQ-QKV"),
    "py_tqkqv":    dict(color="#4dac26", ls="--", marker="s", lw=1.5, label="Python: TQ-KQV"),
    "old_tqqkv":   dict(color="#d73027", ls=":",  marker="^", lw=1.2, label="Python old Q: TQ-QKV"),
}

ax_k, ax_t = axes

# ── Left panel: ptcosine_K ────────────────────────────────────────────────────
for scheme, style_base in [("TQ-KV","tqkv"), ("TQ-QKV","tqqkv")]:
    ax_k.plot(budgets, med(gpu, scheme, "ptcosine_K"),
              **STYLES[f"gpu_{style_base}"])
    ax_k.plot(budgets, med(py_new, scheme, "ptcosine_K"),
              **STYLES[f"py_{style_base}"])

ax_k.set_title("K cache reconstruction\n(budget-neutral cost of QJL, S_mat-independent)",
               fontsize=10, fontweight="bold")
ax_k.set_xlabel("bit budget $b$", fontsize=10)
ax_k.set_ylabel("ptcosine_K  (↑ better)", fontsize=10)
ax_k.set_xticks(budgets)
ax_k.set_ylim(0.75, 1.01)
ax_k.grid(True, alpha=0.3)
ax_k.spines[["top","right"]].set_visible(False)
ax_k.legend(fontsize=7.5, ncol=2, framealpha=0.9)

# Annotation
ax_k.annotate("GPU ≈ Python per scheme\n→ S_mat$_K$ has no effect\non K reconstruction",
              xy=(4.5, 0.965), fontsize=8, color="#444444",
              ha="center", va="bottom")

# ── Right panel: cosine (T output) ───────────────────────────────────────────
for scheme, style_base in [("TQ-KV","tqkv"), ("TQ-QKV","tqqkv")]:
    ax_t.plot(budgets, med(gpu, scheme, "cosine"),
              **STYLES[f"gpu_{style_base}"])
    ax_t.plot(budgets, med(py_new, scheme, "cosine"),
              **STYLES[f"py_{style_base}"])

if py_old is not None:
    ax_t.plot(budgets, med(py_old, "TQ-QKV", "cosine"),
              **STYLES["old_tqqkv"])

# Annotate Jensen gap at b=2
gpu_qkv = med(gpu, "TQ-QKV", "cosine")[0]
py_qkv  = med(py_new, "TQ-QKV", "cosine")[0]
ax_t.annotate("", xy=(2, gpu_qkv), xytext=(2, py_qkv),
              arrowprops=dict(arrowstyle="<->", color="#d73027", lw=1.5))
ax_t.text(2.15, (gpu_qkv + py_qkv)/2,
          f"Jensen\ngap\n{py_qkv-gpu_qkv:.3f}",
          fontsize=7.5, color="#d73027", va="center")

ax_t.set_title("T output cosine\n(Jensen-sensitive for TQ-QKV on fattail)",
               fontsize=10, fontweight="bold")
ax_t.set_xlabel("bit budget $b$", fontsize=10)
ax_t.set_ylabel("cosine(T, T_ref)  (↑ better)", fontsize=10)
ax_t.set_xticks(budgets)
ax_t.set_ylim(0.35, 1.02)
ax_t.grid(True, alpha=0.3)
ax_t.spines[["top","right"]].set_visible(False)
ax_t.legend(fontsize=7.5, ncol=2, framealpha=0.9)

fig.suptitle(f"Jensen Amplification in QJL-K — regime={args.regime}, d=64, S={args.S}\n"
             f"Same K reconstruction, different T output: gap driven by S_mat_K via softmax convexity",
             fontsize=10, y=1.02)

out = pathlib.Path(args.out)
out.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(out, dpi=args.dpi, bbox_inches="tight")
print(f"Saved → {out}")
plt.close(fig)
