"""
v_vs_t_quality.py  —  compare per-token V quality vs T output quality
======================================================================
Shows that per-token V d_2 is monotone in budget while T output d_2
is non-monotone — isolating the bump to the attention composition step.

Uses ptcosine_V / ptrelMSE_V for V quality (per-token, GPU measured)
and cosine / relMSE for T output quality.

Usage:
    python v_vs_t_quality.py sq_full_final.csv \
        --regime unit_sphere --scheme TQ-KQV --S 64
"""

import argparse
import numpy as np
import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument("csv")
ap.add_argument("--regime", default="unit_sphere")
ap.add_argument("--scheme", default="TQ-KQV")
ap.add_argument("--S",      type=int, default=None,
                help="Filter to single S value (None = all S, then show per-S breakdown)")
args = ap.parse_args()

df = pd.read_csv(args.csv)
df.columns = [c.strip() for c in df.columns]

sub = df[(df["regime"] == args.regime) & (df["scheme"] == args.scheme)].copy()
if args.S is not None:
    sub = sub[sub["S"] == args.S]

if sub.empty:
    print(f"No data for regime={args.regime} scheme={args.scheme} S={args.S}")
    exit(1)

# T output metrics
sub["AS_T"] = 1.0 - sub["cosine"]
sub["NF_T"] = sub["relMSE"] / (1.0 + sub["relMSE"])
sub["d2_T"] = np.sqrt(sub["AS_T"]**2 + sub["NF_T"]**2)

# Per-token V metrics
sub["AS_V"] = 1.0 - sub["ptcosine_V"]
sub["NF_V"] = sub["ptrelMSE_V"] / (1.0 + sub["ptrelMSE_V"])
sub["d2_V"] = np.sqrt(sub["AS_V"]**2 + sub["NF_V"]**2)

# Per-token K metrics
sub["AS_K"] = 1.0 - sub["ptcosine_K"]
sub["NF_K"] = sub["ptrelMSE_K"] / (1.0 + sub["ptrelMSE_K"])
sub["d2_K"] = np.sqrt(sub["AS_K"]**2 + sub["NF_K"]**2)

budgets = sorted(sub["budget"].unique())

S_label = f"S={args.S}" if args.S is not None else "all S"
print(f"regime={args.regime}  scheme={args.scheme}  {S_label}")
print()
print(f"{'budget':>8}  {'d2_K':>10}  {'d2_V':>10}  {'d2_T':>10}  "
      f"{'1-cos_V':>10}  {'1-cos_T':>10}")
print("-" * 68)
for b in budgets:
    rows = sub[sub["budget"] == b]
    d2_K  = rows["d2_K"].median()
    d2_V  = rows["d2_V"].median()
    d2_T  = rows["d2_T"].median()
    cos_V = rows["AS_V"].median()
    cos_T = rows["AS_T"].median()
    print(f"{b:>8}  {d2_K:>10.4f}  {d2_V:>10.4f}  {d2_T:>10.4f}  "
          f"{cos_V:>10.4f}  {cos_T:>10.4f}")

print()
print("V monotone?", all(
    sub[sub["budget"]==budgets[i]]["d2_V"].median() >=
    sub[sub["budget"]==budgets[i+1]]["d2_V"].median()
    for i in range(len(budgets)-1)))
print("T monotone?", all(
    sub[sub["budget"]==budgets[i]]["d2_T"].median() >=
    sub[sub["budget"]==budgets[i+1]]["d2_T"].median()
    for i in range(len(budgets)-1)))

# If multiple S values, show per-S breakdown for T
if args.S is None:
    print()
    print("Per-S median d2_T:")
    print(sub.groupby(["budget", "S"])["d2_T"].median().unstack("S").round(3).to_string())
    print()
    print("Per-S median d2_V:")
    print(sub.groupby(["budget", "S"])["d2_V"].median().unstack("S").round(3).to_string())
