"""
plot_jensen.py — Jensen's effect: d2 and topk5 vs budget on fattail
====================================================================
5 lines:
  TQ-KV   GPU       — reference, no QJL, no Jensen
  TQ-QKV  GPU       — RHT-K score correction, Jensen via softmax
  TQ-FKV  GPU       — FULL-K score correction, stronger Jensen (higher variance)
  TQ-QKV  Python    — same algorithm, different S2_K seed → different amplification
  TQ-FKV  Python    — same algorithm, different S_mat_K seed

Gap between GPU solid and Python dashed for QKV/FKV = Jensen effect:
different random projections → different score noise → exponential amplification
by softmax → different T output. TQ-KV has no gap (no QJL, no Jensen).

Two panels: left=d2, right=topk5 (topk5: higher=better).

Usage (from src/):
    python3 analysis/plot_jensen.py \
        --hip csv/tq_d128_t200.csv \
        --py  csv/tq_py_d128_t16.csv \
        --out figures/jensen_effect.png \
        --regime fattail
"""

import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.lines as mlines

ap = argparse.ArgumentParser()
ap.add_argument("--hip",    default="csv/tq_d128_t200.csv")
ap.add_argument("--py",     default="csv/tq_py_d128_t16.csv")
ap.add_argument("--out",    default="figures/jensen_effect.png")
ap.add_argument("--regime", default="fattail")
args = ap.parse_args()

# ── load ──────────────────────────────────────────────────────────────────────

def load(path, src, regime):
    df = pd.read_csv(path)
    df = df[df["regime"] == regime].copy()
    df["d2"] = np.sqrt((1 - df["cosine"])**2 +
                       (df["relMSE"] / (1 + df["relMSE"]))**2)
    df["src"] = src
    # HIP stores topk5 as recall (higher=better)
    # Python stores topk5 as 1-recall (lower=better) → convert
    if src == "py":
        df["topk5_recall"] = 1.0 - df["topk5"]
    else:
        df["topk5_recall"] = df["topk5"]
    return df.groupby(["scheme", "budget"])[["d2", "topk5_recall"]].mean().reset_index()

hip = load(args.hip, "hip", args.regime)
py  = load(args.py,  "py",  args.regime)

# ── style ─────────────────────────────────────────────────────────────────────

LINES = [
    # (label,         scheme,    src,   color,     ls,    lw,  marker)
    ("TQ-KV (GPU)",   "TQ-KV",   hip,   "#2ca02c", "-",   2.5, "o"),
    ("TQ-QKV (GPU)",  "TQ-QKV",  hip,   "#17becf", "-",   2.0, "^"),
    ("TQ-FKV (GPU)",  "TQ-FKV",  hip,   "#ff7f0e", "-",   2.0, "v"),
    ("TQ-QKV (Py)",   "TQ-QKV",  py,    "#17becf", "--",  1.5, "^"),
    ("TQ-FKV (Py)",   "TQ-FKV",  py,    "#ff7f0e", "--",  1.5, "v"),
]

budgets = sorted(hip["budget"].unique())

# ── plot ──────────────────────────────────────────────────────────────────────

fig, axes = plt.subplots(1, 2, figsize=(13, 5))

metrics = [
    ("d2",           "d2 (lower = better)",     False),  # lower=better
    ("topk5_recall", "top-5 recall (higher = better)", True),   # higher=better
]

for ax, (metric, ylabel, higher_better) in zip(axes, metrics):
    for label, scheme, df, color, ls, lw, marker in LINES:
        s = df[df["scheme"] == scheme].sort_values("budget")
        if s.empty:
            continue
        ax.plot(s["budget"], s[metric],
                color=color, ls=ls, lw=lw, marker=marker, ms=6,
                label=label, zorder=3)

    ax.set_xlabel("Budget (bits/dim)", fontsize=11)
    ax.set_ylabel(ylabel, fontsize=11)
    ax.set_xticks(budgets)
    ax.grid(True, alpha=0.3, lw=0.5)
    ax.set_title(f"Fattail — {ylabel.split('(')[0].strip()}", fontsize=11, fontweight="bold")

    pass

# Legend on right panel
handles = [mlines.Line2D([], [], color=c, ls=ls, lw=lw, marker=m, ms=6, label=lbl)
           for lbl, _, _, c, ls, lw, m in LINES]
axes[1].legend(handles=handles, loc="lower right", fontsize=9, framealpha=0.9)

fig.suptitle(
    "QJL-K Score Correction — Fattail, d=128\n"
    "Solid=GPU, Dashed=Python. Vertical spread within each color: RNG-induced variance\n"
    "in the random projection (S₂ or S_mat). Spread between colors (QKV vs FKV):\n"
    "projection mechanics — RHT (low variance) vs Full (high variance).\n"
    "Both effects are amplified exponentially by the softmax (Jensen's inequality).",
    fontsize=9, y=1.05)

import os
os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
plt.tight_layout()
plt.savefig(args.out, dpi=150, bbox_inches="tight")
print(f"Saved: {args.out}")
