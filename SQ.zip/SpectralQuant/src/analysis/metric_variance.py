"""
metric_variance.py — mean and std of quality metrics per (scheme, regime, budget, S)
=====================================================================================
Usage:
    python metric_variance.py sweep.csv \
        --regime fattail --scheme TQ-KV TQ-QKV --S 64
"""
import argparse
import numpy as np
import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument("csv")
ap.add_argument("--regime",  nargs="+", required=True)
ap.add_argument("--scheme",  nargs="+", required=True)
ap.add_argument("--S",       type=int, default=64)
ap.add_argument("--metrics", nargs="+",
                default=["ptcosine_K","ptcosine_V","cosine"])
args = ap.parse_args()

df = pd.read_csv(args.csv)
df.columns = [c.strip() for c in df.columns]
df["dir_T"] = 1.0 - df["cosine"]
if "dir_T" not in args.metrics and "1-cos_T" in args.metrics:
    args.metrics = [m.replace("1-cos_T","dir_T") for m in args.metrics]

sub = df[df["S"] == args.S]

for regime in args.regime:
    rsub = sub[sub["regime"] == regime]
    print(f"\n{'='*70}")
    print(f"Regime: {regime}  S={args.S}")
    for metric in args.metrics:
        if metric not in rsub.columns:
            continue
        print(f"\n  {metric}:  mean ± std  (n=rows per cell)")
        header = f"  {'budget':>6}" + "".join(f"  {s:>28}" for s in args.scheme)
        print(header)
        print("  " + "-"*(len(header)-2))
        for b in sorted(rsub["budget"].unique()):
            row = f"  {b:>6}"
            for s in args.scheme:
                cell = rsub[(rsub["scheme"]==s) & (rsub["budget"]==b)][metric]
                if len(cell) == 0:
                    row += f"  {'N/A':>28}"
                else:
                    m, sd, n = cell.mean(), cell.std(), len(cell)
                    row += f"  {m:.4f} ± {sd:.4f}  (n={n:3d})"
            print(row)
