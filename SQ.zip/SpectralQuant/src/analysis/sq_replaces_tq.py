"""
sq_replaces_tq.py — For each TQ-KV budget, find the minimum SQ budget
that achieves equal or better d2. Report memory savings.

Usage (from src/):
    python3 analysis/sq_replaces_tq.py \
        --csv128 hip/csv/final6_gpu_d128_t200_v2.csv \
        --regime lowrank_aligned lowrank lowrank_steep lowrank_misalign fattail unit_sphere \
        --S 64 1024 4096
"""

import argparse
import numpy as np
import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument("--csv128", default="hip/csv/final6_gpu_d128_t200_v2.csv")
ap.add_argument("--regime", nargs="+",
                default=["lowrank_aligned","lowrank","lowrank_steep",
                         "lowrank_misalign","fattail","unit_sphere"])
ap.add_argument("--S", nargs="+", type=int, default=[64, 1024, 4096])
ap.add_argument("--ref",  default="TQ-KV")
ap.add_argument("--sq",   default="SQU-KV")
args = ap.parse_args()

df = pd.read_csv(args.csv128)
df["d2"] = np.sqrt((1-df["cosine"])**2 + (df["relMSE"]/(1+df["relMSE"]))**2)
agg = df.groupby(["scheme","regime","budget","S"])["d2"].mean().reset_index()

for S in args.S:
    print(f"\n{'='*80}")
    print(f"d=128  S={S}")
    print(f"{'='*80}")
    print(f"  {'Regime':<20} {'b_TQ':>4}  {'d2_TQ':>7}  {'b_SQ':>5}  {'d2_SQ':>7}  {'Δbytes':>8}  verdict")
    print(f"  {'-'*78}")

    for regime in args.regime:
        tq = agg[(agg["scheme"]==args.ref) & (agg["regime"]==regime) &
                 (agg["S"]==S)].sort_values("budget")
        sq = agg[(agg["scheme"]==args.sq) & (agg["regime"]==regime) &
                 (agg["S"]==S)].sort_values("budget")

        if tq.empty or sq.empty:
            continue

        for _, trow in tq.iterrows():
            b_tq   = int(trow["budget"])
            d2_tq  = trow["d2"]
            # TQ bytes: b_tq bits × 128 dims × S tokens / 8
            bytes_tq = b_tq * 128 * S // 8

            # Find minimum SQ budget where d2_SQ <= d2_TQ
            candidates = sq[sq["d2"] <= d2_tq].sort_values("budget")

            if candidates.empty:
                # Best SQ available
                best = sq.iloc[-1]
                b_sq  = int(best["budget"])
                d2_sq = best["d2"]
                # SQ bytes: b_sq bits × 8 semantic dims + 2 bits × 120 tail dims
                bytes_sq = (b_sq * 8 + 2 * 120) * S // 8
                delta = bytes_sq - bytes_tq
                verdict = "SQ cannot match"
            else:
                best  = candidates.iloc[0]
                b_sq  = int(best["budget"])
                d2_sq = best["d2"]
                bytes_sq = (b_sq * 8 + 2 * 120) * S // 8
                delta = bytes_sq - bytes_tq
                if delta < -100:
                    verdict = f"SQ saves {-delta:,} bytes"
                elif delta > 100:
                    verdict = f"SQ costs {delta:,} bytes more"
                else:
                    verdict = "same storage"

            print(f"  {regime:<20} {b_tq:>4}  {d2_tq:>7.4f}  {b_sq:>5}  {d2_sq:>7.4f}  {delta:>+8,}  {verdict}")
        print()
