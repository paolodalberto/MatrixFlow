"""
plot_d2_vs_budget.py — d2 vs budget curves, one panel per regime
=================================================================
Six panels (one per regime), x=budget, y=d2, one line per scheme.
Shows how quality improves with budget and where QJL variants cross.

Usage (from src/):
    python3 analysis/plot_d2_vs_budget.py \
        --csv csv/tq_d128_t200.csv \
        --out figures/d2_vs_budget.png
"""

import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.lines as mlines

ap = argparse.ArgumentParser()
ap.add_argument("--csv", default="csv/tq_d128_t200.csv")
ap.add_argument("--out", default="figures/d2_vs_budget.png")
ap.add_argument("--d",   type=int, default=None,
                help="Embedding dimension (inferred from filename if not set)")
args = ap.parse_args()

# Infer d from filename if not provided
import re as _re
if args.d is None:
    m = _re.search(r'_d(\d+)_', args.csv)
    args.d = int(m.group(1)) if m else 128

# ── load ──────────────────────────────────────────────────────────────────────

df = pd.read_csv(args.csv)
df["d2"] = np.sqrt((1 - df["cosine"])**2 +
                   (df["relMSE"] / (1 + df["relMSE"]))**2)

agg = df.groupby(["scheme", "regime", "budget"])["d2"].mean().reset_index()

# ── style ─────────────────────────────────────────────────────────────────────

SCHEMES = [
    "Plain-KV",
    "TQ-KV",
    "TQ-QKV",
    "SQU-KV",
    "SQW-KV",
    "SQU-QKV",
]

STYLE = {
    "Plain-KV":  dict(color="#7f7f7f", lw=1.5, ls="-.", marker="*", ms=6),
    "TQ-KV":     dict(color="#2ca02c", lw=2.5, ls="-",  marker="o", ms=6),
    "TQ-QKV":    dict(color="#17becf", lw=1.8, ls="-",  marker="^", ms=5),
    "SQU-KV":    dict(color="#1f77b4", lw=1.8, ls="-",  marker="s", ms=5),
    "SQW-KV":    dict(color="#9467bd", lw=1.5, ls="--", marker="D", ms=4),
    "SQU-QKV":   dict(color="#ff7f0e", lw=1.5, ls="-",  marker="v", ms=5),
}

REGIMES = [
    "unit_sphere",
    "lowrank_aligned",
    "lowrank",
    "fattail",
    "lowrank_steep",
    "lowrank_misalign",
]

REGIME_LABELS = {
    "unit_sphere":      "Unit Sphere",
    "lowrank_aligned":  "Lowrank Aligned",
    "lowrank":          "Lowrank",
    "fattail":          "Fattail",
    "lowrank_steep":    "Lowrank Steep",
    "lowrank_misalign": "Lowrank Misalign",
}

budgets = sorted(agg["budget"].unique())

# ── plot ──────────────────────────────────────────────────────────────────────

fig, axes = plt.subplots(2, 3, figsize=(15, 9), sharey=False)
axes_flat = axes.flatten()

for ax, regime in zip(axes_flat, REGIMES):
    sub = agg[agg["regime"] == regime]

    for sch in SCHEMES:
        s = sub[sub["scheme"] == sch].sort_values("budget")
        if s.empty:
            continue
        st = STYLE[sch]
        ax.plot(s["budget"], s["d2"],
                color=st["color"], lw=st["lw"], ls=st["ls"],
                marker=st["marker"], ms=st["ms"],
                label=sch, zorder=3)

    ax.set_title(REGIME_LABELS[regime], fontsize=11, fontweight="bold")
    ax.set_xlabel("Budget (bits/dim)", fontsize=9)
    ax.set_ylabel("d2 (lower = better)", fontsize=9)
    ax.set_xticks(budgets)
    ax.grid(True, alpha=0.3, lw=0.5)
    ax.set_ylim(bottom=0)

# Legend in panel (1,3) — bottom-right = lowrank_misalign
handles = [mlines.Line2D([], [],
                         color=STYLE[s]["color"],
                         lw=STYLE[s]["lw"],
                         ls=STYLE[s]["ls"],
                         marker=STYLE[s]["marker"],
                         ms=STYLE[s]["ms"],
                         label=s)
           for s in SCHEMES]

axes[1][2].legend(handles=handles, loc="upper right",
                  fontsize=8, framealpha=0.9, ncol=1)

fig.suptitle(f"d2 vs Budget — HIP sweep d={args.d}, 200 trials\n"
             "d2 = √((1−cosine)² + (relMSE/(1+relMSE))²)  lower = better",
             fontsize=12, y=1.01)

import os
os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
plt.tight_layout()
plt.savefig(args.out, dpi=150, bbox_inches="tight")
print(f"Saved: {args.out}")
