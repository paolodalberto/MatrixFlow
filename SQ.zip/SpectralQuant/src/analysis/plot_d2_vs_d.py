"""
plot_d2_vs_d.py — d2 vs dimension (d=64/128/256), one panel per regime
=======================================================================
Shows whether scheme rankings are stable across embedding dimensions.
X-axis = d, one line per scheme, one panel per regime.

Usage (from src/):
    python3 analysis/plot_d2_vs_d.py \
        --csv64  csv/tq_d64_t200.csv \
        --csv128 csv/tq_d128_t200.csv \
        --csv256 csv/tq_d256_t200.csv \
        --out    figures/d2_vs_d.png \
        --budget 2 4 6
"""

import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.lines as mlines

ap = argparse.ArgumentParser()
ap.add_argument("--csv64",   default="csv/tq_d64_t200.csv")
ap.add_argument("--csv128",  default="csv/tq_d128_t200.csv")
ap.add_argument("--csv256",  default="csv/tq_d256_t200.csv")
ap.add_argument("--out",     default="figures/d2_vs_d.png")
ap.add_argument("--budget",  nargs="+", type=int, default=[2, 4, 6])
args = ap.parse_args()

# ── load and tag ──────────────────────────────────────────────────────────────

dfs = []
for d_val, path in [(64, args.csv64), (128, args.csv128), (256, args.csv256)]:
    df = pd.read_csv(path)
    df["d"] = d_val
    dfs.append(df)

df = pd.concat(dfs, ignore_index=True)
df["d2"] = np.sqrt((1 - df["cosine"])**2 +
                   (df["relMSE"] / (1 + df["relMSE"]))**2)

agg = df.groupby(["scheme", "regime", "budget", "d"])["d2"].mean().reset_index()

# ── style ─────────────────────────────────────────────────────────────────────

SCHEMES = [
    "Plain-KV",
    "TQ-KV",
    "TQ-QKV",
    "SQU-KV",
    "SQW-KV",
    "SQU-QKV",
]

STYLE = {
    "Plain-KV":  dict(color="#7f7f7f", lw=1.5, ls="-.",  marker="*", ms=7),
    "TQ-KV":     dict(color="#2ca02c", lw=2.5, ls="-",   marker="o", ms=6),
    "TQ-QKV":    dict(color="#17becf", lw=1.8, ls="--",  marker="^", ms=5),
    "SQU-KV":    dict(color="#1f77b4", lw=2.0, ls="-",   marker="s", ms=6),
    "SQW-KV":    dict(color="#9467bd", lw=1.5, ls=":",   marker="D", ms=5),
    "SQU-QKV":   dict(color="#ff7f0e", lw=1.5, ls=(0,(3,1,1,1)), marker="v", ms=5),
}

REGIMES = [
    "unit_sphere",
    "lowrank_aligned",
    "lowrank",
    "fattail",
    "lowrank_steep",
    "lowrank_misalign",
]

REGIME_LABELS = {
    "unit_sphere":      "Unit Sphere",
    "lowrank_aligned":  "Lowrank Aligned",
    "lowrank":          "Lowrank",
    "fattail":          "Fattail",
    "lowrank_steep":    "Lowrank Steep",
    "lowrank_misalign": "Lowrank Misalign",
}

D_VALS = [64, 128, 256]
BUDGETS = args.budget

# ── plot: one row per regime, one col per budget ──────────────────────────────

nrows = len(REGIMES)
ncols = len(BUDGETS)
fig, axes = plt.subplots(nrows, ncols,
                         figsize=(4.5 * ncols, 3.2 * nrows),
                         sharey=False, squeeze=False)

for ri, regime in enumerate(REGIMES):
    for ci, budget in enumerate(BUDGETS):
        ax = axes[ri][ci]
        sub = agg[(agg["budget"] == budget) & (agg["regime"] == regime)]

        for sch in SCHEMES:
            s = sub[sub["scheme"] == sch].sort_values("d")
            if s.empty:
                continue
            st = STYLE[sch]
            ax.plot(s["d"], s["d2"],
                    color=st["color"], lw=st["lw"], ls=st["ls"],
                    marker=st["marker"], ms=st["ms"],
                    label=sch, zorder=3)

        ax.set_xticks(D_VALS)
        ax.set_xticklabels([str(d) for d in D_VALS], fontsize=8)
        ax.grid(True, alpha=0.3, lw=0.5)
        ax.set_ylim(bottom=0)

        if ri == 0:
            ax.set_title(f"b={budget}", fontsize=10, fontweight="bold")
        if ci == 0:
            ax.set_ylabel(f"{REGIME_LABELS[regime]}\nd₂", fontsize=9)
        if ri == nrows - 1:
            ax.set_xlabel("d", fontsize=9)

handles = [mlines.Line2D([], [],
                         color=STYLE[s]["color"],
                         lw=STYLE[s]["lw"],
                         ls=STYLE[s]["ls"],
                         marker=STYLE[s]["marker"],
                         ms=STYLE[s]["ms"],
                         label=s)
           for s in SCHEMES]

fig.suptitle("d2 vs Dimension — HIP sweep 200 trials\n"
             "d2 = √((1−cosine)² + (relMSE/(1+relMSE))²)  lower = better",
             fontsize=11, y=1.01)

import os
os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
plt.tight_layout(rect=[0, 0.05, 1, 1])
fig.legend(handles=handles, loc="lower center", ncol=len(SCHEMES),
           fontsize=8.5, framealpha=0.9,
           bbox_to_anchor=(0.5, 0.0))
plt.savefig(args.out, dpi=150, bbox_inches="tight")
print(f"Saved: {args.out}")
