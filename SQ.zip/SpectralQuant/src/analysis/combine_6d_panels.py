"""
combine_6d_panels.py — stitch two PNGs side by side
Usage:
    python3 analysis/combine_6d_panels.py left.png right.png out.png
"""
import sys
from PIL import Image

left  = Image.open(sys.argv[1])
right = Image.open(sys.argv[2])
h = max(left.height, right.height)
left  = left.crop((0, 0, left.width, h))
right = right.crop((0, 0, right.width, h))
out = Image.new("RGB", (left.width + right.width, h), (255, 255, 255))
out.paste(left,  (0, 0))
out.paste(right, (left.width, 0))
out.save(sys.argv[3])
print(f"Saved: {sys.argv[3]}")
