"""
compare_py_gpu.py — side-by-side Python vs GPU comparison of cached values
===========================================================================
Compares ptcosine_K and ptcosine_V (per-token cache quality, RNG-independent)
between Python and GPU implementations.

Usage:
    python compare_py_gpu.py python.csv gpu.csv \
        --regime unit_sphere lowrank fattail \
        --schemes TQ-KV TQ-QKV \
        --S 64
"""
import argparse
import numpy as np
import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument("python_csv")
ap.add_argument("gpu_csv")
ap.add_argument("--regime",  nargs="+", default=["unit_sphere","lowrank","fattail"])
ap.add_argument("--schemes", nargs="+", default=["TQ-KV","TQ-QKV"])
ap.add_argument("--S",       type=int, default=64)
args = ap.parse_args()

def load(path):
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    return df

py  = load(args.python_csv)
gpu = load(args.gpu_csv)

budgets = sorted(py["budget"].unique())

for regime in args.regime:
    print(f"\n{'='*70}")
    print(f"Regime: {regime}  S={args.S}")
    print(f"{'='*70}")
    for metric, col in [("ptcosine_K", "ptcosine_K"), ("ptcosine_V", "ptcosine_V"), ("1-cos_T", "dir_T")]:
        print(f"\n  {metric}:")
        header = f"  {'budget':>6}" + "".join(
            f"  {'Py:'+s:>14}  {'GPU:'+s:>14}  {'diff':>8}"
            for s in args.schemes)
        print(header)
        print("  " + "-" * (len(header)-2))
        for b in budgets:
            row = f"  {b:>6}"
            for s in args.schemes:
                def med(df, s):
                    sub = df[(df["regime"]==regime)&(df["scheme"]==s)&
                             (df["budget"]==b)&(df["S"]==args.S)]
                    return sub[col].median() if len(sub) else float("nan")
                py_v  = med(py,  s)
                gpu_v = med(gpu, s)
                diff  = abs(gpu_v - py_v) if not (np.isnan(py_v) or np.isnan(gpu_v)) else float("nan")
                row += f"  {py_v:>14.4f}  {gpu_v:>14.4f}  {diff:>8.4f}"
            print(row)
