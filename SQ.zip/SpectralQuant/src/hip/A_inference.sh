#!/bin/bash
# A_inference.sh — production sweep across d=256/128/64, 200 trials, all 13 schemes
# Run from: /scratch/SpectralQuant/src/hip/
# Output:   csv/sq_d{64,128,256}_t200.csv

mkdir -p csv

for D in 256 128 64; do
    echo ""
    echo "=== D=$D ==="
    sed -i "s/constexpr int D\s*=\s*[0-9]*/constexpr int D = $D/" common/pquant_common.h
    hipcc -O3 -I./common -o sweep_hip sweep_hip.hip -lrocblas
    bash run_sweep_200.sh
    mv sq_full.csv csv/tq_d${D}_t200.csv
    echo "=== D=$D DONE: csv/tq_d${D}_t200.csv ==="
done

echo ""
echo "All sweeps complete."
ls -lh csv/tq_d*_t200.csv
