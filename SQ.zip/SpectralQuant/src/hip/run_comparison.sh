#!/bin/bash
# run_comparison.sh — install Python deps and run Python vs HIP comparison
# Run from src/hip/ where the sweep binary lives.
set -e

echo "=== Installing Python dependencies ==="
pip3 install --quiet numpy pandas

echo "=== Running comparison ==="
python3 ../../analysis/compare_py_hip.py \
    --hip_bin ./sweep \
    --regime unit_sphere lowrank fattail \
    --budget 2 3 4 \
    --trials 10 \
    --S 64 128 \
    --scheme Plain-KV TQ-KV TQ-KQV TQ-QKV TQ-QKQV \
    --tol_pt 1e-4 \
    --tol_cos 0.05

echo "=== Done ==="
