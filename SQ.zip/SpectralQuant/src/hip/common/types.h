/*
 * types.h — shared structs for TQ and SQ sweep schemes
 * =====================================================
 * SweepConfig:  everything a scheme needs to run one (S, Nq, budget) cell
 * SweepResult:  everything a scheme produces — matches Python CSV columns
 *
 * QJLVariant:   selects QJL algorithm
 *   NONE  — no QJL (default, TQ-KV behavior)
 *   RHT   — Randomized Hadamard Transform, d-vector S2, O(d log d)
 *   FULL  — full d×d Rademacher projection, O(d²)
 */

#pragma once
#include <vector>
#include <cmath>
#include <hip/hip_runtime.h>
#include <hip/hip_fp16.h>

// ── compile-time pool sizes ───────────────────────────────────────────────────
// D and QJL_BYTES are defined in pquant_common.h — include that first.

static constexpr int MAX_QUERIES    = 512;
static constexpr int MAX_SEQ        = 4096;
static constexpr int MAX_K_BYTES_PT = D;                    // at 8 bits/dim
static constexpr int MAX_V_BYTES_PT = (D * 8 + 7) / 8;
static constexpr int SQ_MAX_D_EFF   = 32;
static constexpr int SQ_MAX_LEVELS  = 256;
static constexpr int SQ_TAIL_BITS   = 2;
static constexpr int SQ_TAIL_BPT    = (D * SQ_TAIL_BITS + 7) / 8;
static constexpr int SQ_QJL_BYTES   = (SQ_MAX_D_EFF + 7) / 8;  // 4 bytes

// ── device buffer pool (allocated once, reused across all schemes) ────────────

struct DeviceBuffers {
    // fp32 working buffers
    float*   d_Q32      = nullptr;   // MAX_QUERIES × D
    float*   d_Khat32   = nullptr;   // MAX_SEQ × D   — decoded K
    float*   d_Vhat32   = nullptr;   // MAX_SEQ × D   — decoded V
    float*   d_sc32     = nullptr;   // MAX_QUERIES × MAX_SEQ — scores
    float*   d_out32    = nullptr;   // MAX_QUERIES × D — attention output
    float*   d_Kfp32    = nullptr;   // MAX_SEQ × D   — reference K fp32
    float*   d_Vfp32    = nullptr;   // MAX_SEQ × D   — reference V fp32

    // fp16 working buffers
    __half*  d_Q16      = nullptr;
    __half*  d_Khat16   = nullptr;
    __half*  d_Vhat16   = nullptr;
    __half*  d_sc16     = nullptr;
    __half*  d_out16    = nullptr;
    __half*  d_Kfp16    = nullptr;
    __half*  d_Vfp16    = nullptr;

    // TQ encoded K/V
    uint8_t* d_k_pack   = nullptr;   // MAX_SEQ × MAX_K_BYTES_PT
    uint8_t* d_v_pack   = nullptr;   // MAX_SEQ × MAX_V_BYTES_PT
    float*   d_k_norms  = nullptr;   // MAX_SEQ
    float*   d_v_norms  = nullptr;   // MAX_SEQ
    float*   d_r_norms_K = nullptr;  // MAX_SEQ — WHT-domain residual norms (QJL-V)
    float*   d_r_norms_V = nullptr;  // MAX_SEQ

    // WHT and QJL signs
    float*   d_s        = nullptr;   // D — WHT randomization signs
    float*   d_S2_K     = nullptr;   // D — QJL signs for K (RHT)
    float*   d_S2_V     = nullptr;   // D — QJL signs for V (RHT)

    // TQ WHT-domain QJL packed bits
    uint8_t* d_qjl_K_pack = nullptr; // MAX_SEQ × QJL_BYTES
    uint8_t* d_qjl_V_pack = nullptr; // MAX_SEQ × QJL_BYTES

    // X-space asymmetric QJL for K score correction (TQ-QKV, TQ-QKQV)
    float*   d_xqjl_K_sign_bits = nullptr; // MAX_SEQ × D — float ±1
    float*   d_xqjl_K_r_norms  = nullptr;  // MAX_SEQ
    float*   d_xqjl_q_sketch   = nullptr;  // MAX_QUERIES × D
    float*   d_xqjl_S_mat_K    = nullptr;  // D × D — Rademacher matrix for K sketch

    // TQ codebook levels (per scheme, uploaded before decode)
    float*   d_lvl_K    = nullptr;   // 256 floats
    float*   d_lvl_V    = nullptr;   // 256 floats

    // SQ encoded K/V
    uint8_t* d_sq_sem_pack_K  = nullptr;  // MAX_SEQ × SQ_MAX_D_EFF
    uint8_t* d_sq_sem_pack_V  = nullptr;
    uint8_t* d_sq_tail_pack_K = nullptr;  // MAX_SEQ × SQ_TAIL_BPT
    uint8_t* d_sq_tail_pack_V = nullptr;
    uint8_t* d_sq_qjl_K_pack  = nullptr;  // MAX_SEQ × SQ_QJL_BYTES
    uint8_t* d_sq_qjl_V_pack  = nullptr;
    float*   d_sq_r_norms_K   = nullptr;  // MAX_SEQ
    float*   d_sq_r_norms_V   = nullptr;

    // SQ codebook (shared across K and V, one basis per calibration)
    float*   d_sq_U        = nullptr;  // D × SQ_MAX_D_EFF
    float*   d_sq_lvl_sem  = nullptr;  // SQ_MAX_D_EFF × SQ_MAX_LEVELS
    float*   d_sq_lvl_tail = nullptr;  // 2^SQ_TAIL_BITS

    // FULL-V: d×d Rademacher matrix for V reconstruction
    float*   d_S_mat_V  = nullptr;  // D × D

    // SQ selective QJL signs (d_eff-dimensional)
    float*   d_sq_S2_V  = nullptr;  // SQ_MAX_D_EFF
    float*   d_sq_S2_K  = nullptr;  // SQ_MAX_D_EFF
};

// QJLVariant defined in pquant_common.h (included before types.h)

// ── sweep configuration ───────────────────────────────────────────────────────

struct SweepConfig {
    // budget and effective MSE bits
    int budget;           // total bits per dim (nominal)
    int nK;               // MSE bits for K  (budget - 1 if QJL-K, else budget)
    int nV;               // MSE bits for V  (budget - 1 if QJL-V, else budget)

    // trial dimensions
    int S;                // sequence length
    int Nq;               // number of queries
    int n_trials;         // number of independent trials

    // trial control
    uint32_t trial_seed = 42;  // RNG seed for Q draws — same seed → same Q sequence

    // QJL variants — default NONE (plain TQ-KV behavior)
    QJLVariant qjl_K = QJLVariant::NONE;
    QJLVariant qjl_V = QJLVariant::NONE;

    // TQ codebooks (pre-solved Lloyd-Max for Beta distribution)
    const std::vector<float>* bnd_K = nullptr;
    const std::vector<float>* lvl_K = nullptr;
    const std::vector<float>* bnd_V = nullptr;
    const std::vector<float>* lvl_V = nullptr;

    // WHT randomization signs (d-vector, shared between K and V)
    const std::vector<float>* wht_signs = nullptr;

    // QJL signs — d-vector for RHT variant (used if qjl_K/V == RHT)
    const std::vector<float>* S2_K = nullptr;
    const std::vector<float>* S2_V = nullptr;

    // QJL matrix — d×d for FULL variant (used if qjl_K/V == FULL)
    // nullptr by default — only set when FULL variant is selected
    const std::vector<float>* S_mat_K = nullptr;
    const std::vector<float>* S_mat_V = nullptr;
};

// ── sweep result ──────────────────────────────────────────────────────────────
// Column names match Python CSV and compare_quant_6d.py expectations.

struct SweepResult {
    // T output quality
    double cosine    = 0.0;   // mean cosine(T, T_ref) over trials
    double relMSE    = 0.0;   // mean ||T-T_ref||² / ||T_ref||²
    double topk5     = 0.0;   // mean top-5 recall (1-topk5 in CSV)
    double KL        = 0.0;   // mean KL(softmax_ref || softmax_quant)

    // isolation metrics (K-path and V-path separately)
    double relMSE_K  = 0.0;   // K-isolation: K_hat + V_ref → T_Ko vs T_ref
    double relMSE_V  = 0.0;   // V-isolation: K_ref + V_hat → T_Vo vs T_ref

    // per-token cache metrics (Q-independent, from first trial)
    float ptcosine_K  = 0.f;
    float ptcosine_V  = 0.f;
    float ptrelMSE_K  = 0.f;
    float ptrelMSE_V  = 0.f;

    // timing (ms, averaged over trials)
    double kern32_ms   = 0.0;  // quantized fp32 attention (decode + GEMM + softmax)
    double kern16_ms   = 0.0;  // quantized fp16 attention (timing only)
    double fpkern32_ms = 0.0;  // reference fp32 attention
    double fpkern16_ms = 0.0;  // reference fp16 attention
};
