#!/bin/bash
# run_final6_sweep_v2.sh — Final 6 schemes, 3 GPUs, d=128, 200 trials
# Fixed: spectral gap criterion in sq_calibrate + independent cal_rng
# Outputs to csv/final6_gpu_d128_t200_v2.csv (keep v1 for comparison)
# Run from src/hip/ after: hipcc -O3 -I./common -o sweep main.hip -lrocblas
set -e

TRIALS=200
SCHEMES="Plain-KV TQ-KV TQ-QKV SQU-KV SQW-KV SQU-QKV"
BUDGETS="2 3 4 5 6 7"
mkdir -p csv logs

echo "[$(date +%T)] Starting final6 v2 sweep on 3 GPUs (200 trials, spectral-gap fix)..."

# GPU 0: unit_sphere + lowrank_aligned
HIP_VISIBLE_DEVICES=0 ./sweep \
    --regime unit_sphere lowrank_aligned \
    --budget $BUDGETS --trials $TRIALS \
    --scheme $SCHEMES \
    > csv/final6_v2_gpu0.csv 2>logs/err_v2_gpu0.log &
PID0=$!

# GPU 1: lowrank + fattail
HIP_VISIBLE_DEVICES=1 ./sweep \
    --regime lowrank fattail \
    --budget $BUDGETS --trials $TRIALS \
    --scheme $SCHEMES \
    > csv/final6_v2_gpu1.csv 2>logs/err_v2_gpu1.log &
PID1=$!

# GPU 2: lowrank_steep + lowrank_misalign
HIP_VISIBLE_DEVICES=2 ./sweep \
    --regime lowrank_steep lowrank_misalign \
    --budget $BUDGETS --trials $TRIALS \
    --scheme $SCHEMES \
    > csv/final6_v2_gpu2.csv 2>logs/err_v2_gpu2.log &
PID2=$!

echo "[$(date +%T)] PIDs: gpu0=$PID0 gpu1=$PID1 gpu2=$PID2"
wait $PID0 $PID1 $PID2 && echo "[$(date +%T)] ALL DONE" || echo "[$(date +%T)] SOME FAILED"

# Merge
cat csv/final6_v2_gpu0.csv \
    <(tail -n +2 csv/final6_v2_gpu1.csv) \
    <(tail -n +2 csv/final6_v2_gpu2.csv) \
    > csv/final6_gpu_d128_t200_v2.csv

echo "[$(date +%T)] Merged: csv/final6_gpu_d128_t200_v2.csv"
rm csv/final6_v2_gpu0.csv csv/final6_v2_gpu1.csv csv/final6_v2_gpu2.csv
