#!/bin/bash
# run_big_sweep.sh — Full TQ+SQ sweep: d=64/128/256, 200 trials, 3 GPUs
# Final 6 schemes, all 6 regimes, budgets 2-7
# Run from src/hip/
set -e

TRIALS=200
SCHEMES="Plain-KV TQ-KV TQ-QKV SQU-KV SQW-KV SQU-QKV"
BUDGETS="2 3 4 5 6 7"
mkdir -p csv logs

for D_VAL in 256 128 64; do
    echo "=== D=$D_VAL ==="

    # Patch D in pquant_common.h
    sed -i "s/^static constexpr int D\s*=\s*[0-9]*/static constexpr int D = $D_VAL/" common/pquant_common.h
    echo "[build] D=$D_VAL"
    hipcc -O3 -I./common -Wno-unused-result -o sweep main.hip -lrocblas
    echo "[build] OK"

    OUT="csv/final6_gpu_d${D_VAL}_t${TRIALS}"

    # GPU 0: unit_sphere + lowrank_aligned
    HIP_VISIBLE_DEVICES=0 ./sweep \
        --regime unit_sphere lowrank_aligned \
        --budget $BUDGETS --trials $TRIALS \
        --scheme $SCHEMES \
        > ${OUT}_gpu0.csv 2>logs/err_d${D_VAL}_gpu0.log &
    PID0=$!

    # GPU 1: lowrank + fattail
    HIP_VISIBLE_DEVICES=1 ./sweep \
        --regime lowrank fattail \
        --budget $BUDGETS --trials $TRIALS \
        --scheme $SCHEMES \
        > ${OUT}_gpu1.csv 2>logs/err_d${D_VAL}_gpu1.log &
    PID1=$!

    # GPU 2: lowrank_steep + lowrank_misalign
    HIP_VISIBLE_DEVICES=2 ./sweep \
        --regime lowrank_steep lowrank_misalign \
        --budget $BUDGETS --trials $TRIALS \
        --scheme $SCHEMES \
        > ${OUT}_gpu2.csv 2>logs/err_d${D_VAL}_gpu2.log &
    PID2=$!

    echo "[$(date +%T)] D=$D_VAL PIDs: $PID0 $PID1 $PID2"
    wait $PID0 $PID1 $PID2 && echo "[$(date +%T)] D=$D_VAL DONE" || echo "[$(date +%T)] D=$D_VAL FAILED"

    # Merge
    cat ${OUT}_gpu0.csv \
        <(tail -n +2 ${OUT}_gpu1.csv) \
        <(tail -n +2 ${OUT}_gpu2.csv) \
        > ${OUT}.csv

    echo "[merge] ${OUT}.csv"
    rm ${OUT}_gpu0.csv ${OUT}_gpu1.csv ${OUT}_gpu2.csv
done

echo "=== ALL DONE ==="
echo "Output:"
ls -lh csv/final6_gpu_d*_t${TRIALS}.csv
