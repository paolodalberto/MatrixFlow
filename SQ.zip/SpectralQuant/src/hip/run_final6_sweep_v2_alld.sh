#!/bin/bash
# run_final6_sweep_v2_alld.sh — Final 6 schemes, d=64/128/256, 200 trials
# Fixed: spectral gap criterion + independent cal_rng
# Outputs: csv/final6_gpu_d{64,128,256}_t200_v2.csv
# Run from: /scratch/SpectralQuant/src/hip/
set -e

TRIALS=200
SCHEMES="Plain-KV TQ-KV TQ-QKV SQU-KV SQW-KV SQU-QKV"
BUDGETS="2 3 4 5 6 7"
mkdir -p csv logs

for D in 256 128 64; do
    echo ""
    echo "=== D=$D: compiling ==="
    sed -i "s/constexpr int D\s*=\s*[0-9]*/constexpr int D = $D/" common/pquant_common.h
    hipcc -O3 -I./common -Wno-unused-result -o sweep main.hip -lrocblas
    echo "=== D=$D: sweep start $(date +%T) ==="

    # GPU 0: unit_sphere + lowrank_aligned
    HIP_VISIBLE_DEVICES=0 ./sweep \
        --regime unit_sphere lowrank_aligned \
        --budget $BUDGETS --trials $TRIALS \
        --scheme $SCHEMES \
        > csv/final6_v2_d${D}_gpu0.csv 2>logs/err_v2_d${D}_gpu0.log &
    PID0=$!

    # GPU 1: lowrank + fattail
    HIP_VISIBLE_DEVICES=1 ./sweep \
        --regime lowrank fattail \
        --budget $BUDGETS --trials $TRIALS \
        --scheme $SCHEMES \
        > csv/final6_v2_d${D}_gpu1.csv 2>logs/err_v2_d${D}_gpu1.log &
    PID1=$!

    # GPU 2: lowrank_steep + lowrank_misalign
    HIP_VISIBLE_DEVICES=2 ./sweep \
        --regime lowrank_steep lowrank_misalign \
        --budget $BUDGETS --trials $TRIALS \
        --scheme $SCHEMES \
        > csv/final6_v2_d${D}_gpu2.csv 2>logs/err_v2_d${D}_gpu2.log &
    PID2=$!

    echo "    PIDs: gpu0=$PID0 gpu1=$PID1 gpu2=$PID2"
    wait $PID0 $PID1 $PID2 \
        && echo "=== D=$D: done $(date +%T) ===" \
        || { echo "=== D=$D: SOME FAILED ==="; exit 1; }

    # Merge
    cat csv/final6_v2_d${D}_gpu0.csv \
        <(tail -n +2 csv/final6_v2_d${D}_gpu1.csv) \
        <(tail -n +2 csv/final6_v2_d${D}_gpu2.csv) \
        > csv/final6_gpu_d${D}_t200_v2.csv

    echo "    Merged: csv/final6_gpu_d${D}_t200_v2.csv"
    rm csv/final6_v2_d${D}_gpu0.csv csv/final6_v2_d${D}_gpu1.csv csv/final6_v2_d${D}_gpu2.csv
done

echo ""
echo "All sweeps complete."
ls -lh csv/final6_gpu_d*_t200_v2.csv
