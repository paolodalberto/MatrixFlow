#!/bin/bash
# run_tq_sweep.sh — full TQ sweep: d=64/128/256, 200 trials, 3 GPUs
# All 8 TQ schemes, 6 regimes, budgets 2-7
# Run from src/hip/
set -e

TRIALS=200
SCHEMES="Plain-KV TQ-KV TQ-KQV TQ-KFV TQ-QKV TQ-QKQV TQ-FKV TQ-FKFV"
BUDGETS="2 3 4 5 6 7"
mkdir -p csv

for D_VAL in 256 128 64; do
    echo "=== D=$D_VAL ==="

    # Patch D in pquant_common.h
    sed -i "s/^static constexpr int D\s*=\s*[0-9]*/static constexpr int D = $D_VAL/" common/pquant_common.h
    echo "[build] D=$D_VAL"
    hipcc -O3 -I./common -Wno-unused-result -o sweep main.hip -lrocblas
    echo "[build] OK"

    OUT="csv/tq_d${D_VAL}_t${TRIALS}"

    # GPU 0: unit_sphere + lowrank_aligned
    HIP_VISIBLE_DEVICES=0 ./sweep \
        --regime unit_sphere lowrank_aligned \
        --budget $BUDGETS --trials $TRIALS \
        --scheme $SCHEMES \
        > ${OUT}_gpu0.csv 2>logs/err_d${D_VAL}_gpu0.log &
    PID0=$!

    # GPU 1: lowrank + fattail
    HIP_VISIBLE_DEVICES=1 ./sweep \
        --regime lowrank fattail \
        --budget $BUDGETS --trials $TRIALS \
        --scheme $SCHEMES \
        > ${OUT}_gpu1.csv 2>logs/err_d${D_VAL}_gpu1.log &
    PID1=$!

    # GPU 2: lowrank_steep + lowrank_misalign
    HIP_VISIBLE_DEVICES=2 ./sweep \
        --regime lowrank_steep lowrank_misalign \
        --budget $BUDGETS --trials $TRIALS \
        --scheme $SCHEMES \
        > ${OUT}_gpu2.csv 2>logs/err_d${D_VAL}_gpu2.log &
    PID2=$!

    echo "[sweep] D=$D_VAL running on 3 GPUs (PIDs: $PID0 $PID1 $PID2)"
    wait $PID0 $PID1 $PID2
    echo "[sweep] D=$D_VAL done"

    # Merge: keep header from gpu0, strip from gpu1/gpu2
    cat ${OUT}_gpu0.csv \
        <(tail -n +2 ${OUT}_gpu1.csv) \
        <(tail -n +2 ${OUT}_gpu2.csv) \
        > ${OUT}.csv

    echo "[merge] ${OUT}.csv ready"
    rm ${OUT}_gpu0.csv ${OUT}_gpu1.csv ${OUT}_gpu2.csv
done

echo "=== ALL DONE ==="
echo "Output: csv/tq_d64_t${TRIALS}.csv  csv/tq_d128_t${TRIALS}.csv  csv/tq_d256_t${TRIALS}.csv"
