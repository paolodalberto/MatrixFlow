/*
 * test_tq_codec.cpp — verify tq_codec.h matches tq_codec.py
 * ===========================================================
 * Generates unit-sphere vectors with the same RNG sequence as Python
 * (numpy default_rng(42), standard_normal then normalize), then
 * computes ptcosine and ptrelMSE for TQ-KV and TQ-KQV at budgets 2..7.
 *
 * Compile:
 *   g++ -O2 -std=c++17 -I.. -o test_tq_codec test_tq_codec.cpp -lm
 *
 * Usage:
 *   ./test_tq_codec [N_tokens]    default N=1000
 *
 * Expected output (compare against Python):
 *   scheme   budget  ptcosine_V  ptrelMSE_V
 *   TQ-KV    2       ...         ...
 *   TQ-KQV   2       ...         ...
 *   ...
 */

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <random>
#include <string>
#include <unordered_set>
#include <algorithm>
#include <numeric>

#include "pquant_common.h"   // D, wht_rows_cpu, solve_lloyd_max, quantise_scalar
#include "tq_codec.h"

// ── simple Box-Muller normal RNG seeded with PCG (matches numpy approximately) ─
// For exact match we'd need to replicate numpy's MT19937 or PCG64.
// Here we use std::mt19937 with seed 42 and normal_distribution — close enough
// for a sanity check. For exact numerical match use the Python-generated CSV.
static std::vector<float> make_unit_sphere(int N, int d, uint64_t seed = 42) {
    std::mt19937_64 rng(seed);
    std::normal_distribution<float> gauss(0.f, 1.f);
    std::vector<float> X(N * d);
    for (int i = 0; i < N; ++i) {
        float n2 = 0.f;
        for (int j = 0; j < d; ++j) { X[i*d+j] = gauss(rng); n2 += X[i*d+j]*X[i*d+j]; }
        float norm = sqrtf(n2 + 1e-30f);
        for (int j = 0; j < d; ++j) X[i*d+j] /= norm;
    }
    return X;
}

static std::vector<float> make_signs(int d, uint64_t seed) {
    std::mt19937_64 rng(seed);
    std::uniform_int_distribution<int> coin(0, 1);
    std::vector<float> s(d);
    for (int j = 0; j < d; ++j) s[j] = coin(rng) ? 1.f : -1.f;
    return s;
}

int main(int argc, char** argv) {
    int N = (argc > 1) ? atoi(argv[1]) : 1000;
    const int d = D;

    auto X = make_unit_sphere(N, d, 42);
    auto wht_signs = make_signs(d, 1);
    auto S2        = make_signs(d, 2);

    printf("%-12s  %-8s  %-14s  %-14s\n",
           "scheme", "budget", "ptcosine_V", "ptrelMSE_V");
    printf("%s\n", std::string(52, '-').c_str());

    for (int n_bits : {2, 3, 4, 5, 6, 7}) {
        // TQ-KV: n_bits MSE, no QJL
        {
            TQCodebook cb = tq_make_codebook(d, n_bits, wht_signs);
            auto X_hat = tq_roundtrip(X, N, cb, false, {});
            float cos = tq_cosine_sim(X, X_hat, N, d);
            float mse = tq_per_token_relmse(X, X_hat, N, d);
            printf("%-12s  %-8d  %-14.4f  %-14.4f\n",
                   "TQ-KV", n_bits, cos, mse);
        }

        // TQ-KQV: (n_bits-1) MSE + QJL on V
        if (n_bits >= 2) {
            TQCodebook cb = tq_make_codebook(d, n_bits - 1, wht_signs);
            auto X_hat = tq_roundtrip(X, N, cb, true, S2);
            float cos = tq_cosine_sim(X, X_hat, N, d);
            float mse = tq_per_token_relmse(X, X_hat, N, d);
            printf("%-12s  %-8d  %-14.4f  %-14.4f\n",
                   "TQ-KQV", n_bits, cos, mse);
        }
    }
    return 0;
}
