/*
 * tq_codec.h — TurboQuant CPU encode/decode
 * ==========================================
 * Matches src/python/codecs/tq_codec.py exactly.
 *
 * Pipeline per token vector v:
 *   1. Normalize:  v_norm = v / ||v||,  store norm
 *   2. Rotate:     y = WHT_norm(v_norm * wht_signs)   — Beta-distributed
 *   3. Quantize:   idx = Lloyd-Max(y, codebook)
 *   4. QJL (opt):  e = y - centroids[idx]             — residual in WHT domain
 *                  sign_bits = sign(WHT_norm(e * S2))  — sketch
 *                  r_norm = ||e||
 *   5. Decode:     y_hat = centroids[idx]
 *                  + sqrt(pi/2)/d * r_norm * S2 * WHT_norm(sign_bits)  (if QJL)
 *                  v_hat = ||v|| * wht_signs * WHT_norm(y_hat)
 *
 * QJL uses a d-vector S2 in {-1,+1} — WHT-based design for reconstruction.
 * This is the pquant_hip_metrics design, not TurboQuant Algorithm 2
 * (which uses a d×d matrix for asymmetric inner product estimation on K).
 */

#pragma once

#include <vector>
#include <cmath>
#include <cassert>
#include <cstdint>
#include <algorithm>
#include <numeric>

#include "pquant_common.h"   // D, wht_rows_cpu, solve_lloyd_max, quantise_scalar

// ── structs ───────────────────────────────────────────────────────────────────

struct TQCodebook {
    int d;
    int n_bits;
    std::vector<float> centroids;    // (2^n_bits,)  Lloyd-Max levels
    std::vector<float> boundaries;   // (2^n_bits+1,) Lloyd-Max boundaries
    std::vector<float> wht_signs;    // (d,)          WHT randomization signs
};

struct TQEncodeResult {
    std::vector<uint8_t> pack;       // (N*d) quantized indices, one per coordinate
    std::vector<float>   norms;      // (N,)  per-token L2 norms
    std::vector<float>   r_norms;    // (N,)  per-token residual norms (QJL only)
    std::vector<float>   sign_bits;  // (N*d) QJL sign bits in {-1,+1} (QJL only)
};

// ── codebook ──────────────────────────────────────────────────────────────────

/*
 * Solve Beta Lloyd-Max codebook for WHT-rotated data.
 * Uses solve_lloyd_max from pquant_common.h (double precision, symmetric).
 * wht_signs must be pre-drawn by the caller.
 */
static TQCodebook tq_make_codebook(int d, int n_bits,
                                    const std::vector<float>& wht_signs) {
    TQCodebook cb;
    cb.d        = d;
    cb.n_bits   = n_bits;
    cb.wht_signs = wht_signs;
    solve_lloyd_max(d, n_bits, cb.boundaries, cb.centroids);
    return cb;
}

// ── encode ────────────────────────────────────────────────────────────────────

/*
 * TurboQuant encode for N tokens.
 *
 * X       : (N * d) row-major token matrix
 * N       : number of tokens
 * cb      : TQCodebook
 * use_qjl : if true, encode WHT-domain QJL residual sketch
 * S2      : (d,) random sign vector in {-1,+1} (required if use_qjl)
 */
static TQEncodeResult tq_encode(const std::vector<float>& X, int N,
                                  const TQCodebook& cb,
                                  bool use_qjl = false,
                                  const std::vector<float>& S2 = {}) {
    const int d = cb.d;
    assert((int)X.size() == N * d);
    if (use_qjl) assert((int)S2.size() == d);

    TQEncodeResult enc;
    enc.pack.resize(N * d);
    enc.norms.resize(N);
    enc.r_norms.assign(N, 0.f);
    enc.sign_bits.assign(N * d, 0.f);

    std::vector<float> tmp(d), res(d);

    for (int i = 0; i < N; ++i) {
        const float* x = X.data() + i * d;

        // 1. Normalize
        float n2 = 0.f;
        for (int j = 0; j < d; ++j) n2 += x[j] * x[j];
        float norm = sqrtf(n2 + 1e-30f);
        enc.norms[i] = norm;

        // 2. WHT rotate: tmp = WHT_norm(x_norm * wht_signs)
        for (int j = 0; j < d; ++j) tmp[j] = (x[j] / norm) * cb.wht_signs[j];
        wht_rows_cpu(tmp.data(), 1, d);   // normalizes by 1/sqrt(d)

        // 3. Quantize
        for (int j = 0; j < d; ++j)
            enc.pack[i * d + j] = (uint8_t)quantise_scalar(tmp[j], cb.boundaries);

        // 4. QJL (optional): residual in WHT domain
        if (use_qjl) {
            float rn2 = 0.f;
            for (int j = 0; j < d; ++j) {
                float e = tmp[j] - cb.centroids[enc.pack[i * d + j]];
                rn2 += e * e;
                res[j] = e * S2[j];    // apply S2 element-wise
            }
            enc.r_norms[i] = sqrtf(rn2);

            // WHT of (residual * S2), then sign
            wht_rows_cpu(res.data(), 1, d);
            for (int j = 0; j < d; ++j)
                enc.sign_bits[i * d + j] = (res[j] >= 0.f) ? 1.f : -1.f;
        }
    }
    return enc;
}

// ── decode ────────────────────────────────────────────────────────────────────

/*
 * TurboQuant decode.
 *
 * Returns X_hat: (N * d) reconstructed token matrix.
 */
static std::vector<float> tq_decode(const TQEncodeResult& enc,
                                     const TQCodebook& cb,
                                     bool use_qjl = false,
                                     const std::vector<float>& S2 = {}) {
    const int d  = cb.d;
    const int N  = (int)enc.norms.size();
    if (use_qjl) assert((int)S2.size() == d);

    std::vector<float> out(N * d);
    std::vector<float> y_hat(d), r(d);
    const float scale = sqrtf((float)M_PI / 2.f) / (float)d;  // sqrt(π/2)/d

    for (int i = 0; i < N; ++i) {
        // Look up centroids in WHT domain
        for (int j = 0; j < d; ++j)
            y_hat[j] = cb.centroids[enc.pack[i * d + j]];

        // QJL correction in WHT domain
        if (use_qjl) {
            // r = WHT_norm(sign_bits)
            for (int j = 0; j < d; ++j) r[j] = enc.sign_bits[i * d + j];
            wht_rows_cpu(r.data(), 1, d);
            // correction = scale * r_norm * S2 * r
            for (int j = 0; j < d; ++j)
                y_hat[j] += scale * enc.r_norms[i] * S2[j] * r[j];
        }

        // Inverse WHT: WHT_norm(y_hat) * wht_signs * norm
        wht_rows_cpu(y_hat.data(), 1, d);
        float* xh = out.data() + i * d;
        for (int j = 0; j < d; ++j)
            xh[j] = enc.norms[i] * cb.wht_signs[j] * y_hat[j];
    }
    return out;
}

// ── roundtrip convenience ─────────────────────────────────────────────────────

static std::vector<float> tq_roundtrip(const std::vector<float>& X, int N,
                                         const TQCodebook& cb,
                                         bool use_qjl = false,
                                         const std::vector<float>& S2 = {}) {
    auto enc = tq_encode(X, N, cb, use_qjl, S2);
    return tq_decode(enc, cb, use_qjl, S2);
}

// ── per-token metrics (for test_tq_hip.py comparison) ────────────────────────

static float tq_cosine_sim(const std::vector<float>& A,
                             const std::vector<float>& B, int N, int d) {
    double sum = 0.0;
    for (int i = 0; i < N; ++i) {
        double dot = 0, na = 0, nb = 0;
        for (int j = 0; j < d; ++j) {
            dot += A[i*d+j] * B[i*d+j];
            na  += A[i*d+j] * A[i*d+j];
            nb  += B[i*d+j] * B[i*d+j];
        }
        sum += dot / (sqrt(na) * sqrt(nb) + 1e-30);
    }
    return (float)(sum / N);
}

static float tq_per_token_relmse(const std::vector<float>& orig,
                                   const std::vector<float>& hat, int N, int d) {
    float tot = 0.f;
    for (int i = 0; i < N; ++i) {
        float num = 0.f, den = 0.f;
        for (int j = 0; j < d; ++j) {
            float e = orig[i*d+j] - hat[i*d+j];
            num += e * e;
            den += orig[i*d+j] * orig[i*d+j];
        }
        tot += num / (den + 1e-30f);
    }
    return tot / N;
}
