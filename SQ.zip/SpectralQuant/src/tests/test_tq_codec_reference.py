"""
test_tq_codec_reference.py — generate reference numbers for test_tq_codec.cpp
==============================================================================
Prints ptcosine_V and ptrelMSE_V for TQ-KV and TQ-KQV at budgets 2..7.
Run this first, then compile and run test_tq_codec.cpp — numbers should match.

Run:
    cd src
    python tests/test_tq_codec_reference.py [N_tokens]
"""

import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import numpy as np
from python.codecs.tq_codec import tq_solve_codebook, tq_roundtrip
from python.codecs.qjl import make_sign_vector

N = int(sys.argv[1]) if len(sys.argv) > 1 else 1000
D = 128

# Same seeds as test_tq_codec.cpp
rng_data  = np.random.default_rng(42)
rng_wht   = np.random.default_rng(1)
rng_s2    = np.random.default_rng(2)

X = rng_data.standard_normal((N, D))
X /= np.linalg.norm(X, axis=1, keepdims=True)

wht_signs = rng_wht.choice([-1.0, 1.0], size=D)
S2        = rng_s2.choice([-1.0, 1.0], size=D)

def cosine_sim(A, B):
    return np.mean(np.sum(A * B, axis=1) /
                   (np.linalg.norm(A, axis=1) * np.linalg.norm(B, axis=1) + 1e-12))

def per_token_relmse(A, B):
    return np.mean(np.sum((A - B)**2, axis=1) /
                   (np.sum(A**2, axis=1) + 1e-30))

print(f"{'scheme':<12}  {'budget':<8}  {'ptcosine_V':<14}  {'ptrelMSE_V':<14}")
print("-" * 52)

for n_bits in [2, 3, 4, 5, 6, 7]:
    # TQ-KV: n_bits MSE, no QJL
    cb = tq_solve_codebook(D, n_bits, rng=np.random.default_rng(1))
    cb.wht_signs = wht_signs.astype(np.float32)
    X_hat = tq_roundtrip(X, cb, use_qjl=False)
    print(f"{'TQ-KV':<12}  {n_bits:<8}  {cosine_sim(X, X_hat):<14.4f}  {per_token_relmse(X, X_hat):<14.4f}")

    # TQ-KQV: (n_bits-1) MSE + QJL
    cb_qjl = tq_solve_codebook(D, n_bits - 1, rng=np.random.default_rng(1))
    cb_qjl.wht_signs = wht_signs.astype(np.float32)
    X_hat_qjl = tq_roundtrip(X, cb_qjl, use_qjl=True, S2=S2)
    print(f"{'TQ-KQV':<12}  {n_bits:<8}  {cosine_sim(X, X_hat_qjl):<14.4f}  {per_token_relmse(X, X_hat_qjl):<14.4f}")
