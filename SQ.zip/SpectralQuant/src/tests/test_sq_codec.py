"""
test_sq_codec.py — tests for sq_codec.py (corrected SpectralQuant design)

Key properties tested:
  1. Separate U_K and U_V — K and V calibrated independently
  2. sq_decode_K_for_metrics roundtrips K (MSE only, no QJL)
  3. sq_decode_V roundtrips V (MSE only, no QJL)
  4. sq_attention_score without QJL = exact inner product in Z space
  5. sq_attention_score with QJL is unbiased (mean converges to exact)
  6. QJL with m > d_eff has lower variance than m = d_eff
  7. Separate U_K/U_V helps on lowrank_misalign vs shared U
  8. Water-filling monotone: uniform ≤ waterfill quality on aligned lowrank
  9. Budget monotone: more bits → lower ptrelMSE
 10. d_eff_K and d_eff_V are independently determined
"""

import numpy as np
import pytest
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from python.codecs.sq_codec import (
    calibrate, participation_ratio, fit_codebook,
    sq_encode_K, sq_encode_V, sq_decode_V, sq_decode_K_for_metrics,
    sq_attention_score,
)
from python.codecs.qjl import make_sign_matrix

RNG = np.random.default_rng(42)
D   = 64   # small for fast tests


def make_lowrank(S, rank, rng, A=None, noise=0.01):
    """K and K_cal must share the same A for calibration to work."""
    if A is None:
        A = rng.standard_normal((D, rank)) / np.sqrt(rank)
    X = rng.standard_normal((S, rank)) @ A.T
    return X + noise * rng.standard_normal((S, D)), A


def make_misalign(S, rank, rng, AK=None, AV=None):
    """K and V in different random subspaces."""
    if AK is None:
        AK = rng.standard_normal((D, rank)); AK, _ = np.linalg.qr(AK); AK = AK[:, :rank]
    if AV is None:
        AV = rng.standard_normal((D, rank)); AV, _ = np.linalg.qr(AV); AV = AV[:, :rank]
    K = rng.standard_normal((S, rank)) @ AK.T / np.sqrt(rank)
    V = rng.standard_normal((S, rank)) @ AV.T / np.sqrt(rank)
    return K, V, AK, AV


def softmax(X):
    X = X - X.max(axis=-1, keepdims=True)
    E = np.exp(X); return E / E.sum(axis=-1, keepdims=True)


def attention(Q, K, V):
    W = softmax(Q @ K.T / np.sqrt(D))
    return W @ V, W


def cosine_mean(A, B):
    n = np.linalg.norm(A, axis=1) * np.linalg.norm(B, axis=1) + 1e-12
    return float(np.mean(np.sum(A * B, axis=1) / n))


def rel_mse(A, B):
    return float(np.sum((A - B)**2) / (np.sum(A**2) + 1e-30))


# ── fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def kv_lowrank():
    rng = np.random.default_rng(0)
    # K and K_cal share the same subspace A_K; V and V_cal share A_V
    K,     A_K = make_lowrank(256, rank=4, rng=rng)
    K_cal, _   = make_lowrank(512, rank=4, rng=rng, A=A_K)
    V,     A_V = make_lowrank(256, rank=4, rng=rng)
    V_cal, _   = make_lowrank(512, rank=4, rng=rng, A=A_V)
    return K, V, K_cal, V_cal


@pytest.fixture(scope="module")
def kv_misalign():
    rng = np.random.default_rng(1)
    # K and K_cal share AK; V and V_cal share AV; AK ≠ AV
    K,     _, AK, AV = make_misalign(256, rank=4, rng=rng)
    V      = make_misalign(256, rank=4, rng=rng, AK=AK, AV=AV)[1]
    K_cal  = make_misalign(512, rank=4, rng=rng, AK=AK, AV=AV)[0]
    V_cal  = make_misalign(512, rank=4, rng=rng, AK=AK, AV=AV)[1]
    return K, V, K_cal, V_cal


@pytest.fixture(scope="module")
def cb_lowrank(kv_lowrank):
    K, V, K_cal, V_cal = kv_lowrank
    return fit_codebook(K_cal, V_cal, b_target=3, b_tail=2, uniform=True)


# ── test 1: separate U_K and U_V ─────────────────────────────────────────────

def test_separate_bases(kv_misalign):
    K, V, K_cal, V_cal = kv_misalign
    cb = fit_codebook(K_cal, V_cal, b_target=3, b_tail=2)
    # U_K and U_V should differ on misaligned data
    assert not np.allclose(cb.U_K, cb.U_V, atol=0.01), \
        "U_K and U_V should differ on misaligned K/V"


def test_deff_independent(kv_misalign):
    K, V, K_cal, V_cal = kv_misalign
    cb = fit_codebook(K_cal, V_cal, b_target=3, b_tail=2)
    # d_eff_K and d_eff_V are both ≥ 1 and ≤ D
    assert 1 <= cb.d_eff_K <= D
    assert 1 <= cb.d_eff_V <= D


# ── test 2: K roundtrip quality ───────────────────────────────────────────────

def test_K_roundtrip_quality(kv_lowrank, cb_lowrank):
    K, V, K_cal, V_cal = kv_lowrank
    enc_K = sq_encode_K(K, cb_lowrank, S_qjl=None)
    K_hat = sq_decode_K_for_metrics(enc_K, cb_lowrank)
    cos = cosine_mean(K, K_hat)
    assert cos > 0.85, f"K roundtrip cosine too low: {cos:.4f}"


# ── test 3: V roundtrip quality ───────────────────────────────────────────────

def test_V_roundtrip_quality(kv_lowrank, cb_lowrank):
    K, V, K_cal, V_cal = kv_lowrank
    enc_V = sq_encode_V(V, cb_lowrank)
    V_hat = sq_decode_V(enc_V, cb_lowrank)
    cos = cosine_mean(V, V_hat)
    assert cos > 0.85, f"V roundtrip cosine too low: {cos:.4f}"


# ── test 4: exact score without QJL ──────────────────────────────────────────

def test_exact_score_in_Z(kv_lowrank, cb_lowrank):
    K, V, K_cal, V_cal = kv_lowrank
    rng = np.random.default_rng(2)
    Q = rng.standard_normal((16, D))

    enc_K = sq_encode_K(K, cb_lowrank, S_qjl=None)  # no QJL
    K_hat = sq_decode_K_for_metrics(enc_K, cb_lowrank)

    # Score from sq_attention_score (no QJL) should match Q @ K_hat.T
    scores_sq  = sq_attention_score(Q, enc_K, cb_lowrank, S_qjl=None)
    scores_ref = Q @ K_hat.T

    assert np.allclose(scores_sq, scores_ref, atol=1e-4), \
        "sq_attention_score (no QJL) should match Q @ K_hat.T"


# ── test 5: QJL score is unbiased ────────────────────────────────────────────

def test_qjl_score_unbiased(kv_lowrank, cb_lowrank):
    K, V, K_cal, V_cal = kv_lowrank
    rng = np.random.default_rng(3)
    Q = rng.standard_normal((8, D))
    d_eff  = cb_lowrank.d_eff_K
    U_eff  = cb_lowrank.U_K[:, :d_eff]
    U_tail = cb_lowrank.U_K[:, d_eff:]

    # QJL corrects toward true semantic score — compare against true, not quantized
    Z_sem_true = K @ U_eff
    enc_K_base = sq_encode_K(K, cb_lowrank, S_qjl=None)
    true_score = (Q @ U_eff) @ Z_sem_true.T + (Q @ U_tail) @ enc_K_base.Z_tail_hat.T

    n_trials = 2000
    estimates = np.zeros_like(true_score)
    for _ in range(n_trials):
        S = make_sign_matrix(d_eff, rng=np.random.default_rng(rng.integers(1<<31)), m=d_eff)
        enc_K_qjl = sq_encode_K(K, cb_lowrank, S_qjl=S)
        estimates += sq_attention_score(Q, enc_K_qjl, cb_lowrank, S_qjl=S)
    estimates /= n_trials

    scale = np.sqrt(np.mean(true_score**2)) + 1e-6
    norm_err = np.abs(estimates - true_score).mean() / scale
    assert norm_err < 0.10, \
        f"1-bit QJL score not unbiased (m=d_eff), normalized error={norm_err:.4f}"


def test_qjl_m64_converges_fast():
    """m=64 > d_eff=8: unbiased AND low variance — converges in 200 trials."""
    rng = np.random.default_rng(7)
    # Build a rank-8 regime so d_eff=8 exactly
    rank = 8
    A = rng.standard_normal((D, rank)) / np.sqrt(rank)
    def make(n):
        X = rng.standard_normal((n, rank)) @ A.T
        return X + 0.001 * rng.standard_normal((n, D))

    K_cal = make(512); V_cal = make(512)
    K     = make(256); Q     = rng.standard_normal((8, D))

    cb = fit_codebook(K_cal, V_cal, b_target=3, b_tail=2, uniform=True)
    d_eff  = cb.d_eff_K
    U_eff  = cb.U_K[:, :d_eff]
    U_tail = cb.U_K[:, d_eff:]
    enc_K_base = sq_encode_K(K, cb, S_qjl=None)
    true_score = (Q @ U_eff) @ (K @ U_eff).T + (Q @ U_tail) @ enc_K_base.Z_tail_hat.T

    # m=64 — only 200 trials needed to converge
    m = 64
    n_trials = 200
    estimates = np.zeros_like(true_score)
    for _ in range(n_trials):
        S = make_sign_matrix(d_eff, rng=np.random.default_rng(rng.integers(1<<31)), m=m)
        enc_K_qjl = sq_encode_K(K, cb, S_qjl=S)
        estimates += sq_attention_score(Q, enc_K_qjl, cb, S_qjl=S)
    estimates /= n_trials

    scale = np.sqrt(np.mean(true_score**2)) + 1e-6
    norm_err = np.abs(estimates - true_score).mean() / scale
    assert norm_err < 0.05, \
        f"1-bit QJL m=64 should converge fast, normalized error={norm_err:.4f}"
    print(f"\n  d_eff={d_eff}, m=64: norm_err={norm_err:.4f} (200 trials)")


def test_qjl_variance_m64_vs_deff():
    """m=64 has lower score variance than m=d_eff — confirms variance ∝ 1/m."""
    rng = np.random.default_rng(8)
    rank = 8
    A = rng.standard_normal((D, rank)) / np.sqrt(rank)
    def make(n):
        X = rng.standard_normal((n, rank)) @ A.T
        return X + 0.001 * rng.standard_normal((n, D))

    K_cal = make(512); V_cal = make(512)
    K     = make(256); Q     = rng.standard_normal((8, D))

    cb = fit_codebook(K_cal, V_cal, b_target=3, b_tail=2, uniform=True)
    d_eff  = cb.d_eff_K
    U_eff  = cb.U_K[:, :d_eff]
    U_tail = cb.U_K[:, d_eff:]
    enc_K_base = sq_encode_K(K, cb, S_qjl=None)
    true_score = (Q @ U_eff) @ (K @ U_eff).T + (Q @ U_tail) @ enc_K_base.Z_tail_hat.T

    n_trials = 500
    vars_small, vars_large = [], []
    for _ in range(n_trials):
        seed = rng.integers(1<<31)
        S_small = make_sign_matrix(d_eff, rng=np.random.default_rng(seed), m=d_eff)
        S_large = make_sign_matrix(d_eff, rng=np.random.default_rng(seed), m=64)
        enc_small = sq_encode_K(K, cb, S_qjl=S_small)
        enc_large = sq_encode_K(K, cb, S_qjl=S_large)
        err_small = sq_attention_score(Q, enc_small, cb, S_small) - true_score
        err_large = sq_attention_score(Q, enc_large, cb, S_large) - true_score
        vars_small.append(np.var(err_small))
        vars_large.append(np.var(err_large))

    v_small = np.mean(vars_small)
    v_large = np.mean(vars_large)
    ratio   = v_small / (v_large + 1e-10)

    assert ratio > 2.0, \
        f"m=64 should have much lower variance than m=d_eff={d_eff}: ratio={ratio:.2f}"
    print(f"\n  d_eff={d_eff}: var(m={d_eff})={v_small:.4f}, var(m=64)={v_large:.4f}, ratio={ratio:.1f}x")


# ── test 6: larger m → lower variance ────────────────────────────────────────

def test_larger_m_lower_variance(kv_lowrank, cb_lowrank):
    K, V, K_cal, V_cal = kv_lowrank
    rng = np.random.default_rng(4)
    Q = rng.standard_normal((8, D))
    d_eff = cb_lowrank.d_eff_K
    enc_K_base = sq_encode_K(K, cb_lowrank, S_qjl=None)
    exact = sq_attention_score(Q, enc_K_base, cb_lowrank, S_qjl=None)

    n_trials = 200
    vars_small = []   # m = d_eff
    vars_large = []   # m = min(64, D)

    m_large = min(64, D)
    for _ in range(n_trials):
        seed = rng.integers(1<<31)
        S_small = make_sign_matrix(d_eff, rng=np.random.default_rng(seed), m=d_eff)
        S_large = make_sign_matrix(d_eff, rng=np.random.default_rng(seed), m=m_large)
        enc_s = sq_encode_K(K, cb_lowrank, S_qjl=S_small)
        enc_l = sq_encode_K(K, cb_lowrank, S_qjl=S_large)
        vars_small.append(np.var(sq_attention_score(Q, enc_s, cb_lowrank, S_small) - exact))
        vars_large.append(np.var(sq_attention_score(Q, enc_l, cb_lowrank, S_large) - exact))

    v_small = np.mean(vars_small)
    v_large = np.mean(vars_large)
    assert v_large < v_small, \
        f"Larger m should have lower variance: m={d_eff} var={v_small:.4f}, m={m_large} var={v_large:.4f}"


# ── test 7: separate U helps on misalign ─────────────────────────────────────

def test_separate_U_helps_misalign(kv_misalign):
    K, V, K_cal, V_cal = kv_misalign

    # Separate bases (correct design)
    cb_sep = fit_codebook(K_cal, V_cal, b_target=3, b_tail=2)
    enc_V_sep = sq_encode_V(V, cb_sep)
    V_hat_sep = sq_decode_V(enc_V_sep, cb_sep)
    cos_sep = cosine_mean(V, V_hat_sep)

    # Shared basis (wrong design — use K_cal for V too)
    cb_shared = fit_codebook(K_cal, K_cal, b_target=3, b_tail=2)
    enc_V_shared = sq_encode_V(V, cb_shared)
    V_hat_shared = sq_decode_V(enc_V_shared, cb_shared)
    cos_shared = cosine_mean(V, V_hat_shared)

    assert cos_sep > cos_shared + 0.05, \
        f"Separate U_V should help on misalign: sep={cos_sep:.4f}, shared={cos_shared:.4f}"


# ── test 8: water-fill ≥ uniform on aligned lowrank ──────────────────────────

def test_waterfill_helps_aligned():
    rng = np.random.default_rng(5)
    lam = np.array([4.0, 2.0, 1.0, 0.5])
    A = rng.standard_normal((D, 4))
    A, _ = np.linalg.qr(A); A = A[:, :4]
    def make(n): return rng.standard_normal((n, 4)) * np.sqrt(lam) @ A.T

    # K_cal and K share same A; same for V
    K_cal = make(512); V_cal = make(512)
    K     = make(256); V     = make(256)

    cb_uni = fit_codebook(K_cal, V_cal, b_target=3, b_tail=2, uniform=True)
    cb_wf  = fit_codebook(K_cal, V_cal, b_target=3, b_tail=2, uniform=False)

    enc_K_uni = sq_encode_K(K, cb_uni); K_hat_uni = sq_decode_K_for_metrics(enc_K_uni, cb_uni)
    enc_K_wf  = sq_encode_K(K, cb_wf);  K_hat_wf  = sq_decode_K_for_metrics(enc_K_wf,  cb_wf)

    mse_uni = rel_mse(K, K_hat_uni)
    mse_wf  = rel_mse(K, K_hat_wf)
    # Water-fill should be at least as good
    assert mse_wf <= mse_uni + 0.01, \
        f"Water-fill should help on steep spectrum: uni={mse_uni:.4f}, wf={mse_wf:.4f}"


# ── test 9: budget monotone ───────────────────────────────────────────────────

def test_budget_monotone(kv_lowrank):
    K, V, K_cal, V_cal = kv_lowrank
    mse_prev = float("inf")
    for b in [2, 3, 4, 5]:
        cb = fit_codebook(K_cal, V_cal, b_target=b, b_tail=2, uniform=True)
        enc_K = sq_encode_K(K, cb, S_qjl=None)
        K_hat = sq_decode_K_for_metrics(enc_K, cb)
        mse = rel_mse(K, K_hat)
        assert mse < mse_prev, f"ptrelMSE_K not monotone at b={b}: {mse:.4f} >= {mse_prev:.4f}"
        mse_prev = mse


# ── test 10: attention output quality ────────────────────────────────────────

def test_attention_output_quality(kv_lowrank, cb_lowrank):
    K, V, K_cal, V_cal = kv_lowrank
    rng = np.random.default_rng(6)
    Q = rng.standard_normal((32, D))

    T_ref, _ = attention(Q, K, V)

    enc_K = sq_encode_K(K, cb_lowrank, S_qjl=None)
    enc_V = sq_encode_V(V, cb_lowrank)
    V_hat = sq_decode_V(enc_V, cb_lowrank)

    scores = sq_attention_score(Q, enc_K, cb_lowrank, S_qjl=None) / np.sqrt(D)
    W_hat  = softmax(scores)
    T_hat  = W_hat @ V_hat

    cos = cosine_mean(T_ref, T_hat)
    assert cos > 0.80, f"Attention output cosine too low: {cos:.4f}"
