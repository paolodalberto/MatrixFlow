"""
compare_cpp_python_qjl.py  —  step-by-step comparison of C++ and Python QJL
=============================================================================
Replicates the exact encode/decode path of both implementations on the same
data to find where they diverge.

Run:
    python compare_cpp_python_qjl.py
"""

import numpy as np
from turbo_proto import solve_lloyd_max_beta, fwht_batch, wht_rotate, wht_rotate_inv

rng = np.random.default_rng(42)
d = 128
N = 10_000

wht_signs = rng.choice([-1., 1.], size=d)
S2        = rng.choice([-1., 1.], size=d)

# draw N unit-sphere tokens
V = rng.standard_normal((N, d))
V /= np.linalg.norm(V, axis=1, keepdims=True)

# ── normalized WHT (matches C++ wht_rows_cpu which divides by sqrt(d)) ──────
def wht_normalized(X):
    """Normalized WHT: WHT(X) / sqrt(d). Matches C++ wht_rows_cpu."""
    X = np.array(X, dtype=np.float64)
    N_, d_ = X.shape
    h = 1
    while h < d_:
        X = X.reshape(N_, -1, h*2)
        left  = X[:, :, :h] + X[:, :, h:]
        right = X[:, :, :h] - X[:, :, h:]
        X = np.concatenate([left, right], axis=2).reshape(N_, d_)
        h *= 2
    return X / np.sqrt(d_)

print(f"N={N} tokens, d={d}")
print()

for b_mse in [1, 2]:
    centroids, boundaries = solve_lloyd_max_beta(d, b_mse)
    n_levels = len(centroids)

    print(f"{'='*60}")
    print(f"b_mse={b_mse}  ({n_levels} centroids)")

    # ── PYTHON path (turbo_proto._roundtrip) ─────────────────────────────────
    # wht_rotate = fwht_batch(X * signs) / sqrt(d)  — normalized
    V_rot_py = wht_rotate(V, wht_signs)   # normalized WHT — same as C++
    idx_py   = np.clip(np.searchsorted(boundaries[1:-1], V_rot_py), 0, n_levels-1)
    V_quant_py = centroids[idx_py]
    residual_py = V_rot_py - V_quant_py
    r_norms_py  = np.linalg.norm(residual_py, axis=1)

    # QJL encode: sign(fwht_batch(residual * S2))  — unnormalized WHT
    qjl_bits_py = np.sign(fwht_batch(residual_py * S2[np.newaxis, :]))

    # QJL decode: fwht_batch(bits) * S2 / d * sqrt(pi/2) * r_norms — unnormalized WHT
    r_hat_py = (fwht_batch(qjl_bits_py) * S2[np.newaxis, :]
                / d * np.sqrt(np.pi / 2.0) * r_norms_py[:, np.newaxis])
    V_corrected_py = V_quant_py + r_hat_py

    # inverse WHT: fwht_batch(x) * signs / sqrt(d) — normalized
    V_hat_py = wht_rotate_inv(V_corrected_py, wht_signs)
    V_hat_py *= np.linalg.norm(V, axis=1, keepdims=True)  # restore norms (=1)

    cos_py    = np.sum(V * V_hat_py, axis=1) / (np.linalg.norm(V_hat_py, axis=1) + 1e-12)
    relmse_py = np.sum((V - V_hat_py)**2, axis=1) / np.sum(V**2, axis=1)

    print(f"  PYTHON:  1-cos={1-cos_py.mean():.4f}±{(1-cos_py).std():.4f}  "
          f"relMSE={relmse_py.mean():.4f}±{relmse_py.std():.4f}")

    # ── C++ path (exact replica of pquant_common.h dequant_mse_qjl) ──────────
    # encode: same forward WHT (normalized)
    V_rot_cpp = wht_normalized(V * wht_signs[np.newaxis, :])   # = V_rot_py
    idx_cpp   = np.clip(np.searchsorted(boundaries[1:-1], V_rot_cpp), 0, n_levels-1)
    V_quant_cpp = centroids[idx_cpp]
    residual_cpp = V_rot_cpp - V_quant_cpp
    r_norms_cpp  = np.linalg.norm(residual_cpp, axis=1)        # same as Python

    # QJL encode: wht_normalized(residual * S2) — normalized WHT
    res_cpp     = residual_cpp * S2[np.newaxis, :]
    res_wht_cpp = wht_normalized(res_cpp)
    qjl_bits_cpp = np.sign(res_wht_cpp)

    # QJL decode: wht_normalized(bits) then add to x, then wht_normalized(x)
    scale_cpp = np.sqrt(np.pi / 2.0) / np.sqrt(d)   # current C++ scale
    r_cpp     = wht_normalized(qjl_bits_cpp)          # normalized WHT of bits
    x_cpp     = V_quant_cpp + scale_cpp * r_norms_cpp[:, np.newaxis] * S2[np.newaxis, :] * r_cpp
    x_back_cpp = wht_normalized(x_cpp)                # inverse WHT (normalized)
    V_hat_cpp  = x_back_cpp * wht_signs[np.newaxis, :] * np.linalg.norm(V, axis=1, keepdims=True)

    cos_cpp    = np.sum(V * V_hat_cpp, axis=1) / (np.linalg.norm(V_hat_cpp, axis=1) + 1e-12)
    relmse_cpp = np.sum((V - V_hat_cpp)**2, axis=1) / np.sum(V**2, axis=1)

    print(f"  C++ sim: 1-cos={1-cos_cpp.mean():.4f}±{(1-cos_cpp).std():.4f}  "
          f"relMSE={relmse_cpp.mean():.4f}±{relmse_cpp.std():.4f}")

    # ── intermediate comparison ───────────────────────────────────────────────
    print(f"  r_norms equal?      max_diff={np.abs(r_norms_py - r_norms_cpp).max():.2e}")
    print(f"  qjl_bits equal?     fraction_same={(qjl_bits_py == qjl_bits_cpp).mean():.4f}")
    print(f"  r_hat vs r_cpp:     cos={np.mean([np.dot(r_hat_py[i], scale_cpp*r_norms_cpp[i]*S2*r_cpp[i]) /                     (np.linalg.norm(r_hat_py[i])*np.linalg.norm(scale_cpp*r_norms_cpp[i]*S2*r_cpp[i])+1e-12)                     for i in range(min(100,N))]):.4f}")
    print()
