"""
qv_improvement_table.py  —  compute QV improvement in dir_err_T (Table 3)
==========================================================================
Reports median dir_err_T = 1 - cosine for SQ-uniform, SQ-uniform-qjlV,
and the delta, pooled over all 6 regimes (or per regime with --regime).

Usage:
    python qv_improvement_table.py sq_d256_t200.csv
    python qv_improvement_table.py sq_d256_t200.csv --regime lowrank
"""

import argparse
import numpy as np
import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument("csv")
ap.add_argument("--regime", default=None,
                help="Filter to single regime (default: all regimes pooled)")
ap.add_argument("--scheme_plain", default="SQ-uniform")
ap.add_argument("--scheme_qjlv",  default="SQ-uniform-qjlV")
args = ap.parse_args()

df = pd.read_csv(args.csv)
df.columns = [c.strip() for c in df.columns]
df["dir_err_T"] = 1.0 - df["cosine"]

if args.regime:
    df = df[df["regime"] == args.regime]
    label = args.regime
else:
    label = "all regimes pooled"

budgets = sorted(df["budget"].unique())

print(f"QV improvement in dir_err_T  ({label})")
print(f"Source: {args.csv}")
print()

rows = {}
for scheme in [args.scheme_plain, args.scheme_qjlv]:
    vals = []
    for b in budgets:
        med = df.loc[(df["scheme"] == scheme) & (df["budget"] == b), "dir_err_T"].median()
        vals.append(med)
    rows[scheme] = vals

delta = [rows[args.scheme_qjlv][i] - rows[args.scheme_plain][i]
         for i in range(len(budgets))]

header = "  ".join(f"b={b}" for b in budgets)
print(f"{'Scheme':28s}  {header}")
print("-" * (28 + 4 + len(header)))
for scheme, vals in rows.items():
    row = "  ".join(f"{v:6.3f}" for v in vals)
    print(f"{scheme:28s}  {row}")
delta_row = "  ".join(f"{d:+6.3f}" for d in delta)
print(f"{'Delta (qjlV - plain)':28s}  {delta_row}")
print()

# LaTeX table row format
print("LaTeX rows:")
print(f"Plain SQ $\\direrr_T$  & " +
      " & ".join(f"{v:.3f}" for v in rows[args.scheme_plain]) + " \\\\")
print(f"SQ-QV $\\direrr_T$ & " +
      " & ".join(f"{v:.3f}" for v in rows[args.scheme_qjlv]) + " \\\\")
print(f"$\\Delta$              & " +
      " & ".join((f"$-${abs(d):.3f}" if d < 0 else f"$+${d:.3f}") for d in delta) +
      " \\\\")
