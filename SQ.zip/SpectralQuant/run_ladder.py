"""
run_ladder.py — SpectralQuant comparison ladder
=================================================

Runs all synthetic distribution regimes and all schemes at b∈{2,3,4,5},
produces per-regime CSV files and a summary table.

Schemes
-------
    SQ-uniform   — eigenbasis + uniform bits on d_eff dims
    SQ-waterfill — eigenbasis + water-filled bits on d_eff dims
    SQ-wf-qjl    — water-fill + selective QJL on semantic dims

Input regimes
-------------
    random       — Gaussian baseline (no structure)
    lowrank_r4   — rank-4 signal subspace (strong spectral gap)
    lowrank_r16  — rank-16 subspace (moderate gap)
    fattail_nu3  — Student-t(3) per-dim marginals (mild non-Gaussianity)
    fattail_nu15 — Student-t(1.5) (severe non-Gaussianity, undefined variance)
    misalign_0   — K/V same subspace (theta=0, V reuse is exact)
    misalign_90  — K/V orthogonal subspaces (theta=pi/2, worst case)
    twopop       — two-population mixture (deff=4 vs deff=12)

Usage
-----
    python run_ladder.py                          # all regimes, b=2..5
    python run_ladder.py --regime lowrank_r4      # single regime
    python run_ladder.py --budget 4 5             # specific budgets
    python run_ladder.py --n_tokens 8192          # larger context
"""

import argparse
import os
import sys

import numpy as np
import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)

from spectralquant_proto import run_experiment, calibrate, beta_diagnostic
from synth_kv import (
    gaussian_lowrank, student_rotated, misaligned_kv, two_population
)

# ── regime registry ────────────────────────────────────────────────────────────

def _make_random(n, d, n_cal, seed):
    """Uniform on the unit sphere — TurboQuant's theoretical home territory."""
    rng = np.random.default_rng(seed)
    def unit_sphere(shape):
        X = rng.standard_normal(shape).astype(np.float32)
        return X / np.linalg.norm(X, axis=1, keepdims=True)
    K_cal = unit_sphere((n_cal, d))
    K     = unit_sphere((n,     d))
    V     = unit_sphere((n,     d))
    Q     = unit_sphere((64,    d))
    return K, V, Q, K_cal


REGIMES = {
    "random":       lambda n, d, n_cal, seed: _make_random(n, d, n_cal, seed),
    "lowrank_r4":     lambda n, d, n_cal, seed: gaussian_lowrank(n, d, 4,  n_cal=n_cal, seed=seed),
    "lowrank_r4_exp": lambda n, d, n_cal, seed: gaussian_lowrank(n, d, 4,  n_cal=n_cal, seed=seed, lam_decay="exp"),
    "lowrank_r8_exp": lambda n, d, n_cal, seed: gaussian_lowrank(n, d, 8,  n_cal=n_cal, seed=seed, lam_decay="exp"),
    "lowrank_r16":    lambda n, d, n_cal, seed: gaussian_lowrank(n, d, 16, n_cal=n_cal, seed=seed),
    "fattail_nu3":  lambda n, d, n_cal, seed: student_rotated(n, d, 4, nu=3.0,  n_cal=n_cal, seed=seed),
    "fattail_nu15": lambda n, d, n_cal, seed: student_rotated(n, d, 4, nu=1.5,  n_cal=n_cal, seed=seed),
    "misalign_0":   lambda n, d, n_cal, seed: misaligned_kv(n, d, 4, theta=0.0,          n_cal=n_cal, seed=seed),
    "misalign_90":  lambda n, d, n_cal, seed: misaligned_kv(n, d, 4, theta=np.pi/2,      n_cal=n_cal, seed=seed),
    "twopop":       lambda n, d, n_cal, seed: two_population(n, d, rank_1=4, rank_2=12,  n_cal=n_cal, seed=seed),
}


# ── main ───────────────────────────────────────────────────────────────────────

def run_regime(name, K, V, Q, K_cal, budgets, b_tail, verbose):
    print(f"\n{'='*64}")
    print(f"Regime: {name}")
    print(f"{'='*64}")

    # Beta diagnostic on calibration data
    calib = calibrate(K_cal)
    diag  = beta_diagnostic(K_cal, calib)
    print(f"  d_eff={calib['d_eff']}  "
          f"Beta KS={diag['ks_stat']:.3f}  "
          f"KL={diag['kl_div']:.4f}")

    df = run_experiment(K, V, Q, K_cal,
                        budgets=budgets,
                        b_tail=b_tail,
                        verbose=verbose)
    df["regime"] = name
    df["d_eff"]  = calib["d_eff"]
    df["beta_ks"] = diag["ks_stat"]
    df["beta_kl"] = diag["kl_div"]
    return df


def print_summary(all_df: pd.DataFrame):
    # Compute 1-cosine columns and effective budget
    all_df = all_df.copy()
    all_df["dirK"]       = 1 - all_df["ptcosine_K"]
    all_df["dirV"]       = 1 - all_df["ptcosine_V"]
    all_df["dirT"]       = 1 - all_df["cosine"]
    # QJL schemes carry 1 extra effective bit — shift their budget column by +1
    all_df["budget_eff"] = all_df["budget"] + all_df["has_qjl_K"].astype(int)

    g = all_df.groupby(["regime", "scheme", "budget_eff"])

    for metric, label in [
        ("ptrelMSE_K", "K  relMSE"),
        ("dirK",       "K  1-cos "),
        ("ptrelMSE_V", "V  relMSE"),
        ("dirV",       "V  1-cos "),
        ("kl_sm",      "SM KL-div"),
        ("relMSE",     "T  relMSE"),
        ("dirT",       "T  1-cos "),
        ("d_6",        "d_6      "),
    ]:
        print(f"\n{'='*64}")
        print(f"SUMMARY — {label}  (lower is better, QJL shown at effective budget b+1)")
        print(f"{'='*64}")
        pivot = g[metric].mean().unstack("budget_eff")
        print(pivot.to_string())


def main():
    parser = argparse.ArgumentParser(description="SpectralQuant comparison ladder")
    parser.add_argument("--regime",   nargs="+", default=list(REGIMES.keys()),
                        choices=list(REGIMES.keys()),
                        help="Regimes to run (default: all)")
    parser.add_argument("--budget",   type=int, nargs="+", default=[2, 3, 4, 5],
                        help="Bit budgets to sweep")
    parser.add_argument("--n_tokens", type=int, default=4096)
    parser.add_argument("--n_cal",    type=int, default=512)
    parser.add_argument("--d_h",      type=int, default=128)
    parser.add_argument("--b_tail",   type=int, default=2)
    parser.add_argument("--seed",     type=int, default=42)
    parser.add_argument("--out_dir",  default=".",
                        help="Directory for CSV outputs")
    parser.add_argument("--quiet",    action="store_true",
                        help="Suppress per-scheme verbose output")
    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    all_dfs = []

    for name in args.regime:
        fn = REGIMES[name]
        K, V, Q, K_cal = fn(args.n_tokens, args.d_h, args.n_cal, args.seed)

        df = run_regime(name, K, V, Q, K_cal,
                        budgets=args.budget,
                        b_tail=args.b_tail,
                        verbose=not args.quiet)

        out_path = os.path.join(args.out_dir, f"metrics_sq_{name}.csv")
        df.to_csv(out_path, index=False)
        print(f"  → {out_path}")
        all_dfs.append(df)

    all_df = pd.concat(all_dfs, ignore_index=True)
    combined_path = os.path.join(args.out_dir, "metrics_sq_all.csv")
    all_df.to_csv(combined_path, index=False)
    print(f"\nCombined: {combined_path}")

    print_summary(all_df)


if __name__ == "__main__":
    main()
