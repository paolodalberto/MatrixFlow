"""
d2_stratified_S_2panel.py  —  2-panel figure for paper
=======================================================
Panel 1 (unit_sphere / TQ-QKQV): d_2 rises with S at every budget ->
  more bits needed to maintain accuracy as context grows.
Panel 2 (lowrank / SQ-uniform): d_2 plateaus after b=4 at every S ->
  SQ gains nothing by increasing budget due to fixed tail floor.

Usage:
    python d2_stratified_S_2panel.py sq_full_final.csv --out figures/d2_by_S_2panel.png
"""

import argparse
import pathlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
try:
    cmap_fn = matplotlib.colormaps["plasma"]
except AttributeError:
    import matplotlib.cm as cm
    cmap_fn = cm.get_cmap("plasma")

ap = argparse.ArgumentParser()
ap.add_argument("csv")
ap.add_argument("--out", default="d2_by_S_2panel.png")
ap.add_argument("--dpi", type=int, default=180)
args = ap.parse_args()

df = pd.read_csv(args.csv)
df.columns = [c.strip() for c in df.columns]
df["AS"]  = 1.0 - df["cosine"]
df["NF"]  = df["relMSE"] / (1.0 + df["relMSE"])
df["d_2"] = np.sqrt(df["AS"]**2 + df["NF"]**2)

budgets  = sorted(df["budget"].unique())
S_values = sorted(df["S"].unique())

PANELS = [
    ("unit_sphere", "TQ-QKQV",
     r"unit\_sphere / TQ-QKQV: longer context needs more bits",
     r"Longer sequences ($S\!\uparrow$) raise $d_2$ at every budget;"
     r" achieving fixed quality requires higher $b$."),
    ("lowrank", "SQ-uniform",
     r"lowrank / SQ-uniform: no benefit beyond $b=4$",
     r"All sequence lengths plateau after $b=4$;"
     r" the fixed tail floor absorbs additional bits."),
]

n_S = len(S_values)
colors = {s: cmap_fn((i + 1) / (n_S + 2)) for i, s in enumerate(S_values)}

fig, axes = plt.subplots(1, 2, figsize=(11, 4.2), sharey=False)
fig.subplots_adjust(wspace=0.38)

for ax, (regime, scheme, title, subtitle) in zip(axes, PANELS):
    sub = df[(df["regime"] == regime) & (df["scheme"] == scheme)]
    if sub.empty:
        ax.set_title(f"{title}  [NO DATA]", fontsize=9)
        continue

    for s in S_values:
        rows = sub[sub["S"] == s]
        if rows.empty:
            continue
        medians = [rows[rows["budget"] == b]["d_2"].median() for b in budgets]
        ax.plot(budgets, medians,
                color=colors[s], marker="o", markersize=5,
                lw=1.8, label=f"$S={s}$")

    ax.set_title(title.replace(r"\_", "_"), fontsize=10, fontweight="bold", pad=4)
    ax.set_xlabel(r"bit budget $b$", fontsize=10)
    ax.set_ylabel(r"$d_2$", fontsize=11)
    ax.set_ylim(0, None)
    ax.set_xticks(budgets)
    ax.grid(True, alpha=0.28, lw=0.7)
    ax.spines[["top", "right"]].set_visible(False)


    # subtitle below x-label
    ax.annotate(subtitle.replace(r"\_", "_"),
                xy=(0.5, -0.22), xycoords="axes fraction",
                ha="center", va="top", fontsize=7.5,
                color="#444444", wrap=True)

# shared legend on left panel
axes[0].legend(title="seq len $S$", fontsize=8, title_fontsize=8,
               loc="upper right", ncol=2,
               frameon=True, framealpha=0.92, edgecolor="lightgray")
axes[1].legend(title="seq len $S$", fontsize=8, title_fontsize=8,
               loc="upper right", ncol=2,
               frameon=True, framealpha=0.92, edgecolor="lightgray")

out = pathlib.Path(args.out)
out.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(out, dpi=args.dpi, bbox_inches="tight")
print(f"Saved -> {out}")
plt.close(fig)
