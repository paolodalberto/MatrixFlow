"""
turbo_gpu.py — PyTorch GPU port of TurboQuant and SpectralQuant codecs
=======================================================================

Implements the same encode/decode logic as turbo_proto.py and
spectralquant_proto.py but using PyTorch tensors so the computation
runs on CUDA / ROCm (HIP) or CPU with the same code path.

Key design choices
------------------
- All operations are pure PyTorch (no custom CUDA kernels)
- WHT is implemented via a recursive butterfly on GPU tensors
- Codebook lookup uses torch.bucketize (vectorized, GPU-friendly)
- Timing uses torch.cuda.Event for GPU-accurate wall-time measurement
- Works transparently on CPU if no GPU is available

Usage
-----
    # quick sanity check
    python turbo_gpu.py --regime lowrank_aligned random --budget 2 3 4 5 --quiet

    # GPU run with timing
    python turbo_gpu.py --device cuda --n_tokens 16384 --timing_reps 10

    # compare CPU vs GPU timings
    python turbo_gpu.py --device cpu  --n_tokens 4096 --timing_reps 5
    python turbo_gpu.py --device cuda --n_tokens 4096 --timing_reps 5
"""

from __future__ import annotations
import argparse
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F
import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
sys.path.insert(0, os.path.join(_HERE, "pquant_6d"))

# CPU codebooks are still solved on CPU via the numpy implementation
from turbo_proto import solve_lloyd_max_beta, REGIMES, _CODEBOOK_CACHE
from spectralquant_proto import calibrate, beta_diagnostic

RNG_SEED = 42


# ═══════════════════════════════════════════════════════════════════════════════
# 1.  GPU FAST WALSH-HADAMARD TRANSFORM
# ═══════════════════════════════════════════════════════════════════════════════

def fwht_gpu(X: torch.Tensor) -> torch.Tensor:
    """
    Vectorized in-place WHT for batch of row-vectors.
    X : (N, d)  — d must be a power of 2.
    Returns same-shape tensor (new allocation).
    """
    X = X.clone()
    N, d = X.shape
    w = 1
    while w < d:
        X = X.view(N, -1, w * 2)
        left  = X[:, :, :w] + X[:, :, w:]
        right = X[:, :, :w] - X[:, :, w:]
        X = torch.cat([left, right], dim=2).view(N, d)
        w *= 2
    return X


def wht_rotate_gpu(X: torch.Tensor, signs: torch.Tensor) -> torch.Tensor:
    """WHT(X * signs) / sqrt(d)."""
    d = X.shape[1]
    return fwht_gpu(X * signs.unsqueeze(0)) / (d ** 0.5)


def wht_rotate_inv_gpu(X: torch.Tensor, signs: torch.Tensor) -> torch.Tensor:
    """WHT(X) * signs / sqrt(d)."""
    d = X.shape[1]
    return fwht_gpu(X) * signs.unsqueeze(0) / (d ** 0.5)


# ═══════════════════════════════════════════════════════════════════════════════
# 2.  GPU TURBO CODEC
# ═══════════════════════════════════════════════════════════════════════════════

class TurboQuantCodecGPU:
    """
    TurboQuant codec running on a specified torch device.

    Parameters
    ----------
    d_h       : head dimension (power of 2)
    b_mse_K   : MSE bits for K
    b_mse_V   : MSE bits for V
    use_qjl_K : add QJL on K residual
    use_qjl_V : add QJL on V residual
    use_wht   : apply randomized WHT (False = Plain-KV baseline)
    device    : torch device string, e.g. "cuda", "cpu"
    rng       : numpy Generator for sign initialization
    """

    def __init__(
        self,
        d_h: int,
        b_mse_K: int,
        b_mse_V: int,
        use_qjl_K: bool = False,
        use_qjl_V: bool = False,
        use_wht: bool = True,
        device: str = "cpu",
        rng: np.random.Generator = None,
    ):
        self.d_h = d_h
        self.b_mse_K = b_mse_K
        self.b_mse_V = b_mse_V
        self.use_qjl_K = use_qjl_K
        self.use_qjl_V = use_qjl_V
        self.use_wht = use_wht
        self.device = torch.device(device)

        if rng is None:
            rng = np.random.default_rng(RNG_SEED)

        def _signs():
            return torch.tensor(
                rng.choice([-1.0, 1.0], size=d_h), dtype=torch.float32,
            ).to(self.device)

        self.wht_signs  = _signs()
        self.qjl_signs_K = _signs()
        self.qjl_signs_V = _signs()

        # Codebook tensors (set by fit_codebooks)
        self.centroids_K  = None
        self.boundaries_K = None
        self.centroids_V  = None
        self.boundaries_V = None

    def fit_codebooks(self):
        """Solve Lloyd-Max on CPU and move tensors to device."""
        def _load(n_bits):
            c, b = solve_lloyd_max_beta(self.d_h, n_bits)
            c_t = torch.tensor(c, dtype=torch.float32).to(self.device)
            b_t = torch.tensor(b[1:-1], dtype=torch.float32).to(self.device)  # interior
            return c_t, b_t

        self.centroids_K, self.boundaries_K = _load(self.b_mse_K)
        self.centroids_V, self.boundaries_V = _load(self.b_mse_V)

    def _roundtrip(
        self,
        X: torch.Tensor,
        centroids: torch.Tensor,
        boundaries: torch.Tensor,
        use_qjl: bool,
        qjl_signs: torch.Tensor,
    ) -> torch.Tensor:
        d = self.d_h
        n_levels = centroids.shape[0]

        norms = X.norm(dim=1, keepdim=True).clamp(min=1e-12)
        X_norm = X / norms

        if self.use_wht:
            X_rot = wht_rotate_gpu(X_norm, self.wht_signs)
        else:
            X_rot = X_norm

        # Vectorized codebook lookup via bucketize
        idx = torch.bucketize(X_rot, boundaries)          # (N, d) in [0, n_levels]
        idx = idx.clamp(0, n_levels - 1)
        X_quant = centroids[idx]                           # (N, d)

        if use_qjl:
            residual = X_rot - X_quant
            r_norms  = residual.norm(dim=1, keepdim=True)
            qjl_bits = fwht_gpu(residual * qjl_signs.unsqueeze(0)).sign()
            r_hat    = (
                fwht_gpu(qjl_bits) * qjl_signs.unsqueeze(0)
                / d * (torch.pi / 2.0) ** 0.5 * r_norms
            )
            X_quant = X_quant + r_hat

        if self.use_wht:
            X_hat_norm = wht_rotate_inv_gpu(X_quant, self.wht_signs)
        else:
            X_hat_norm = X_quant

        return X_hat_norm * norms

    def encode_decode(self, X: torch.Tensor, is_key: bool = True) -> torch.Tensor:
        if is_key:
            return self._roundtrip(
                X, self.centroids_K, self.boundaries_K,
                self.use_qjl_K, self.qjl_signs_K,
            )
        else:
            return self._roundtrip(
                X, self.centroids_V, self.boundaries_V,
                self.use_qjl_V, self.qjl_signs_V,
            )


# ═══════════════════════════════════════════════════════════════════════════════
# 3.  GPU SPECTRALQUANT CODEC
# ═══════════════════════════════════════════════════════════════════════════════

class SpectralQuantCodecGPU:
    """
    SpectralQuant codec on GPU.  Calibration (eigh, Lloyd-Max) runs on CPU;
    encode/decode (matmul, bucketize) runs on device.
    """

    def __init__(
        self,
        d_h: int,
        budget: int,
        b_tail: int = 2,
        device: str = "cpu",
        rng: np.random.Generator = None,
    ):
        self.d_h    = d_h
        self.budget = budget
        self.b_tail = b_tail
        self.device = torch.device(device)
        self.rng    = rng or np.random.default_rng(RNG_SEED)

        # Set by fit_codebooks
        self.U_eff       = None   # (d_h, d_eff)  on device
        self.d_eff       = None
        self.bit_alloc   = None   # (d_eff,) int array
        self.centroids   = None   # list[torch.Tensor] length d_eff + 1 (tail)
        self.boundaries  = None   # list[torch.Tensor]

    def fit_codebooks(self, K_cal: np.ndarray):
        from spectralquant_proto import water_fill, lloyd_max_1d

        calib  = calibrate(K_cal)
        d_eff  = calib["d_eff"]
        U_eff  = calib["U_eff"]      # (d_h, d_eff) numpy
        sig_eff = calib["sig_eff"]   # (d_eff,)

        self.d_eff = d_eff
        self.U_eff = torch.tensor(U_eff, dtype=torch.float32).to(self.device)

        # Water-fill bit allocation
        from spectralquant_proto import water_fill
        budget_bits = self.budget * d_eff
        bit_alloc = water_fill(sig_eff, budget_bits, min_bits=self.b_tail)
        self.bit_alloc = bit_alloc

        # Per-dim Lloyd-Max codebooks (CPU, then move to device)
        K_rot = K_cal @ U_eff      # (N_cal, d_eff)
        self.centroids  = []
        self.boundaries = []

        for i in range(d_eff):
            n_bits = int(bit_alloc[i])
            c, b = lloyd_max_1d(K_rot[:, i], n_bits)
            self.centroids.append(
                torch.tensor(c, dtype=torch.float32).to(self.device)
            )
            self.boundaries.append(
                torch.tensor(b[1:-1], dtype=torch.float32).to(self.device)
            )

        # Tail codebook: b_tail bits, analytical Beta
        c_tail, b_tail_arr = solve_lloyd_max_beta(self.d_h, self.b_tail)
        self.c_tail = torch.tensor(c_tail, dtype=torch.float32).to(self.device)
        self.b_tail_boundaries = torch.tensor(
            b_tail_arr[1:-1], dtype=torch.float32
        ).to(self.device)

    def encode_decode(self, X: torch.Tensor, is_key: bool = True) -> torch.Tensor:
        """
        Rotate → quantize per-dim → reconstruct → rotate back.
        QJL not yet implemented in GPU path (use CPU SQ for now).
        """
        d_eff = self.d_eff
        d_h   = self.d_h

        # Rotate into semantic subspace
        X_sem  = X @ self.U_eff                 # (N, d_eff)
        X_tail = X - X_sem @ self.U_eff.T       # (N, d_h) residual (tail dims)

        # Quantize semantic dims
        X_sem_q = torch.zeros_like(X_sem)
        for i in range(d_eff):
            idx = torch.bucketize(X_sem[:, i], self.boundaries[i])
            idx = idx.clamp(0, self.centroids[i].shape[0] - 1)
            X_sem_q[:, i] = self.centroids[i][idx]

        # Quantize tail via WHT + Beta codebook
        # (simplified: skip WHT, quantize directly with tail codebook)
        idx_tail = torch.bucketize(
            X_tail / (X_tail.norm(dim=1, keepdim=True).clamp(1e-12)),
            self.b_tail_boundaries,
        ).clamp(0, self.c_tail.shape[0] - 1)
        X_tail_q = self.c_tail[idx_tail] * X_tail.norm(dim=1, keepdim=True).clamp(1e-12)

        # Rotate semantic back and add tail
        X_hat = X_sem_q @ self.U_eff.T + X_tail_q

        return X_hat


# ═══════════════════════════════════════════════════════════════════════════════
# 4.  TIMING UTILITIES
# ═══════════════════════════════════════════════════════════════════════════════

def gpu_time_ms(fn, device, warmup=2, reps=5):
    """
    Measure GPU wall-time of fn() using CUDA events if device is CUDA,
    or perf_counter otherwise.  Returns mean time in ms over `reps` runs.
    """
    is_cuda = (torch.device(device).type == "cuda")

    # Warmup
    for _ in range(warmup):
        fn()
    if is_cuda:
        torch.cuda.synchronize()

    if is_cuda:
        start = torch.cuda.Event(enable_timing=True)
        end   = torch.cuda.Event(enable_timing=True)
        start.record()
        for _ in range(reps):
            fn()
        end.record()
        torch.cuda.synchronize()
        return start.elapsed_time(end) / reps
    else:
        t0 = time.perf_counter()
        for _ in range(reps):
            fn()
        return (time.perf_counter() - t0) / reps * 1000.0


# ═══════════════════════════════════════════════════════════════════════════════
# 5.  METRICS (GPU tensors → scalar)
# ═══════════════════════════════════════════════════════════════════════════════

def rel_mse_gpu(orig: torch.Tensor, hat: torch.Tensor) -> float:
    err   = ((orig - hat) ** 2).sum(dim=1)
    denom = (orig ** 2).sum(dim=1).clamp(min=1e-12)
    return (err / denom).mean().item()


def cosine_sim_gpu(orig: torch.Tensor, hat: torch.Tensor) -> float:
    num = (orig * hat).sum(dim=1)
    den = (orig.norm(dim=1) * hat.norm(dim=1)).clamp(min=1e-12)
    return (num / den).mean().item()


def attention_output_gpu(Q, K, V, d_h):
    scores  = Q @ K.T / (d_h ** 0.5)
    weights = F.softmax(scores, dim=1)
    return weights @ V


# ═══════════════════════════════════════════════════════════════════════════════
# 6.  EXPERIMENT RUNNER
# ═══════════════════════════════════════════════════════════════════════════════

def run_gpu_experiment(K_np, V_np, Q_np, K_cal_np, budgets, device, timing_reps,
                       verbose=True):
    dev = torch.device(device)
    K = torch.tensor(K_np, dtype=torch.float32).to(dev)
    V = torch.tensor(V_np, dtype=torch.float32).to(dev)
    Q = torch.tensor(Q_np, dtype=torch.float32).to(dev)
    d_h = K.shape[1]
    n_tokens = K.shape[0]

    rows = []

    for b in budgets:
        shared_seed = int(
            np.random.default_rng(RNG_SEED + b * 997).integers(1 << 31)
        )
        for n_bits in {b, b - 1} - {0}:
            solve_lloyd_max_beta(d_h, n_bits)   # warm cache

        schemes = [
            ("Plain-KV", b,     b,     False, False, False),
            ("TQ-KV",    b,     b,     False, False, True),
            ("TQ-QKV",   b - 1, b,     True,  False, True),
            ("TQ-KQV",   b,     b - 1, False, True,  True),
            ("TQ-QKQV",  b - 1, b - 1, True,  True,  True),
        ]

        for scheme_name, b_mse_K, b_mse_V, use_qjl_K, use_qjl_V, use_wht in schemes:
            if b_mse_K < 1 or b_mse_V < 1:
                continue

            codec = TurboQuantCodecGPU(
                d_h, b_mse_K, b_mse_V,
                use_qjl_K=use_qjl_K, use_qjl_V=use_qjl_V,
                use_wht=use_wht,
                device=device,
                rng=np.random.default_rng(shared_seed),
            )
            codec.fit_codebooks()

            K_hat = codec.encode_decode(K, is_key=True)
            V_hat = codec.encode_decode(V, is_key=False)

            t_K = gpu_time_ms(
                lambda: codec.encode_decode(K, is_key=True),
                device, warmup=2, reps=timing_reps,
            )
            t_V = gpu_time_ms(
                lambda: codec.encode_decode(V, is_key=False),
                device, warmup=2, reps=timing_reps,
            )

            T_ref = attention_output_gpu(Q, K,     V,     d_h)
            T_hat = attention_output_gpu(Q, K_hat, V_hat, d_h)
            t_attn = gpu_time_ms(
                lambda: attention_output_gpu(Q, K_hat, V_hat, d_h),
                device, warmup=2, reps=timing_reps,
            )

            n_bits_K = float(b_mse_K + int(use_qjl_K))
            n_bits_V = float(b_mse_V + int(use_qjl_V))

            row = dict(
                framework    = "TurboQuant-GPU",
                scheme       = scheme_name,
                device       = device,
                budget       = b,
                n_tokens     = n_tokens,
                n_bits_K     = n_bits_K,
                n_bits_V     = n_bits_V,
                total_bits_K = n_bits_K * d_h,
                total_bits_V = n_bits_V * d_h,
                t_enc_K_ms   = t_K,
                t_enc_V_ms   = t_V,
                t_attn_ms    = t_attn,
                tok_per_s_K  = n_tokens / (t_K / 1000.0),
                tok_per_s_V  = n_tokens / (t_V / 1000.0),
                relMSE       = rel_mse_gpu(T_ref, T_hat),
                cosine       = cosine_sim_gpu(T_ref, T_hat),
                ptrelMSE_K   = rel_mse_gpu(K, K_hat),
                ptrelMSE_V   = rel_mse_gpu(V, V_hat),
                ptcosine_K   = cosine_sim_gpu(K, K_hat),
                ptcosine_V   = cosine_sim_gpu(V, V_hat),
            )
            rows.append(row)

            if verbose:
                print(f"  {scheme_name:<14} b={b}  "
                      f"K={t_K:.2f}ms  V={t_V:.2f}ms  "
                      f"attn={t_attn:.2f}ms  "
                      f"T-1cos={1-row['cosine']:.4f}  "
                      f"toks/s={row['tok_per_s_K']/1e6:.2f}M")

    return pd.DataFrame(rows)


# ═══════════════════════════════════════════════════════════════════════════════
# 7.  MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="TurboQuant GPU prototype")
    parser.add_argument("--regime",      nargs="+", default=["lowrank_aligned", "random"],
                        choices=list(REGIMES.keys()))
    parser.add_argument("--budget",      type=int, nargs="+", default=[2, 3, 4, 5])
    parser.add_argument("--n_tokens",    type=int, nargs="+", default=[4096, 16384])
    parser.add_argument("--n_cal",       type=int, default=512)
    parser.add_argument("--d_h",         type=int, default=128)
    parser.add_argument("--seed",        type=int, default=42)
    parser.add_argument("--device",      default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--timing_reps", type=int, default=5)
    parser.add_argument("--out_dir",     default="gpu_results")
    parser.add_argument("--quiet",       action="store_true")
    args = parser.parse_args()

    print(f"Device: {args.device}")
    if torch.cuda.is_available():
        print(f"  GPU: {torch.cuda.get_device_name(0)}")

    os.makedirs(args.out_dir, exist_ok=True)
    all_dfs = []

    for name in args.regime:
        fn = REGIMES[name]
        for n_tok in args.n_tokens:
            print(f"\n{'='*64}")
            print(f"Regime: {name}  n_tokens={n_tok}  device={args.device}")
            print(f"{'='*64}")

            K, V, Q, K_cal = fn(n_tok, args.d_h, args.n_cal, args.seed)
            Q = Q[:64]   # cap queries for speed

            df = run_gpu_experiment(
                K, V, Q, K_cal,
                budgets     = args.budget,
                device      = args.device,
                timing_reps = args.timing_reps,
                verbose     = not args.quiet,
            )
            df["regime"] = name
            all_dfs.append(df)

    all_df = pd.concat(all_dfs, ignore_index=True)
    out = os.path.join(args.out_dir, f"gpu_{args.device.replace(':', '_')}.csv")
    all_df.to_csv(out, index=False)
    print(f"\nSaved: {out}")

    print("\n=== T 1-cos summary ===")
    all_df["dirT"] = 1 - all_df["cosine"]
    g = all_df.groupby(["regime", "scheme", "budget"])
    print(g["dirT"].mean().unstack("budget").to_string())

    print("\n=== Throughput K (M tok/s) ===")
    print(g["tok_per_s_K"].mean().apply(lambda x: x / 1e6).unstack("budget").to_string())


if __name__ == "__main__":
    main()
