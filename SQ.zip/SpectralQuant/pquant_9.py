import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import beta as beta_dist
from scipy.integrate import quad
from scipy.special import softmax

# ============================================================
#  PARAMETERS — play with these
# ============================================================
D      = 128    # dimension (must be power of 2)
N_BITS = 4     # total bit budget per coordinate
N_KEYS = 32    # number of keys in attention
N_TRIALS = 100 # Monte Carlo trials per distribution
# ============================================================

# --- CORE ---

def fwht(x):
    x = x.astype(float)
    n = len(x)
    w = 1
    while w < n:
        for i in range(0, n, w * 2):
            for j in range(i, i + w):
                a, b = x[j], x[j + w]
                x[j], x[j + w] = a + b, a - b
        w *= 2
    return x

def randomized_wht(v, seed):
    d = len(v)
    rng = np.random.default_rng(seed)
    signs = rng.choice([-1, 1], size=d)
    return fwht(v * signs) / np.sqrt(d)

def prepare_beta_pdf(d):
    a = b = (d - 1) / 2.0
    # coordinate of unit sphere: Beta(a,b) on [-1,1]
    return a, b, lambda x: 0.5 * beta_dist.pdf((x + 1) / 2.0, a, b)

def solve_lloyd_max(d, num_bits):
    num_levels = 2 ** num_bits
    _, _, pdf = prepare_beta_pdf(d)
    centroids = np.linspace(-0.1, 0.1, num_levels)
    boundaries = np.zeros(num_levels + 1)
    for _ in range(300):
        boundaries[0], boundaries[-1] = -1.0, 1.0
        for j in range(1, num_levels):
            boundaries[j] = (centroids[j-1] + centroids[j]) / 2.0
        new_centroids = centroids.copy()
        for j in range(num_levels):
            num, _ = quad(lambda x: x * pdf(x), boundaries[j], boundaries[j+1])
            den, _ = quad(pdf, boundaries[j], boundaries[j+1])
            if den > 1e-12:
                new_centroids[j] = num / den
        if np.max(np.abs(new_centroids - centroids)) < 1e-10:
            break
        centroids = new_centroids
    return centroids, boundaries

def turbo_quant(v, centroids, boundaries, seed_wht, seed_qjl):
    d = len(v)
    norm_v = np.linalg.norm(v) + 1e-12
    x_rot = randomized_wht(v / norm_v, seed_wht)
    indices = np.clip(np.digitize(x_rot, boundaries) - 1, 0, len(centroids) - 1)
    x_beta = centroids[indices]
    residual = x_rot - x_beta
    r_norm = np.linalg.norm(residual)
    rng_qjl = np.random.default_rng(seed_qjl)
    signs_qjl = rng_qjl.choice([-1, 1], size=d)
    qjl_bits = np.sign(fwht(residual * signs_qjl))
    return indices, qjl_bits, norm_v, r_norm, signs_qjl

def dequant_mse_only(indices, norm_v, centroids, d, seed_wht):
    x_beta = centroids[indices]
    rng = np.random.default_rng(seed_wht)
    signs = rng.choice([-1, 1], size=d)
    return fwht(x_beta) * signs / np.sqrt(d) * norm_v

def dequant_mse_qjl(indices, qjl_bits, r_norm, norm_v, centroids, d, signs_qjl, seed_wht):
    x_beta = centroids[indices]
    r_hat = (fwht(qjl_bits) * signs_qjl / d) * np.sqrt(np.pi / 2.0) * r_norm
    rng = np.random.default_rng(seed_wht)
    signs = rng.choice([-1, 1], size=d)
    return fwht(x_beta + r_hat) * signs / np.sqrt(d) * norm_v

def make_K(dist, n_keys, d, rng):
    if dist == 'gaussian':
        return rng.standard_normal((n_keys, d))
    elif dist == 'heavy_tail':
        K = rng.standard_normal((n_keys, d))
        K[rng.random(n_keys) < 0.1] *= 10
        return K
    elif dist == 'low_rank':
        rank = max(1, d // 8)
        return rng.standard_normal((n_keys, rank)) @ rng.standard_normal((rank, d))

def kl_divergence(p, q):
    return np.sum(p * np.log(p / np.clip(q, 1e-10, None)))

def run_experiment(dist, centroids_full, boundaries_full,
                   centroids_reduced, boundaries_reduced,
                   d=64, n_keys=32, n_trials=100):
    kl_mse_list, kl_qjl_list = [], []
    for trial in range(n_trials):
        rng = np.random.default_rng(trial)
        K = make_K(dist, n_keys, d, rng)
        q = rng.standard_normal(d)
        true_attn = softmax(K @ q / np.sqrt(d))

        K_mse = np.zeros_like(K)
        K_qjl = np.zeros_like(K)
        for i in range(n_keys):
            sw, sq = trial * 1000 + i, trial * 1000 + i + 500
            # MSE only: full N_BITS
            idx_f, _, nv, _, _ = turbo_quant(K[i], centroids_full, boundaries_full, sw, sq)
            K_mse[i] = dequant_mse_only(idx_f, nv, centroids_full, d, sw)
            # MSE+QJL: (N_BITS-1) MSE + 1-bit QJL  [fair budget]
            idx_r, bits, nv2, nr, sq2 = turbo_quant(K[i], centroids_reduced,
                                                     boundaries_reduced, sw, sq)
            K_qjl[i] = dequant_mse_qjl(idx_r, bits, nr, nv2, centroids_reduced,
                                         d, sq2, sw)

        kl_mse_list.append(kl_divergence(true_attn, softmax(K_mse @ q / np.sqrt(d))))
        kl_qjl_list.append(kl_divergence(true_attn, softmax(K_qjl @ q / np.sqrt(d))))
    return np.array(kl_mse_list), np.array(kl_qjl_list)

# ============================================================
#  SOLVE CODEBOOKS
# ============================================================
print(f"Solving Lloyd-Max codebooks  d={D}  full={N_BITS}bit  reduced={N_BITS-1}bit ...")
centroids_full,    boundaries_full    = solve_lloyd_max(D, N_BITS)
centroids_reduced, boundaries_reduced = solve_lloyd_max(D, N_BITS - 1)

# ============================================================
#  FIGURE
#  Row 0 : histogram of rotated coordinates vs Beta PDF
#  Row 1 : KL boxplots — fair budget comparison
# ============================================================
dists = ['gaussian', 'heavy_tail', 'low_rank']
fig, axes = plt.subplots(2, 3, figsize=(15, 10))
fig.suptitle(
    f'TurboQuant  |  d={D}  |  fair budget: MSE {N_BITS}-bit  vs  '
    f'MSE {N_BITS-1}-bit + QJL 1-bit',
    fontsize=13)

# --- Row 0: histogram vs Beta PDF ---
a_param, b_param, pdf_fn = prepare_beta_pdf(D)
x_grid = np.linspace(-1, 1, 500)
pdf_vals = np.array([pdf_fn(xi) for xi in x_grid])

for col, dist in enumerate(dists):
    ax = axes[0, col]
    # collect rotated coordinates from many vectors
    rng = np.random.default_rng(0)
    K_sample = make_K(dist, 500, D, rng)
    rotated_coords = []
    for i in range(len(K_sample)):
        v = K_sample[i]
        norm_v = np.linalg.norm(v) + 1e-12
        x_rot = randomized_wht(v / norm_v, seed=i)
        rotated_coords.extend(x_rot.tolist())
    rotated_coords = np.array(rotated_coords)

    ax.hist(rotated_coords, bins=60, density=True,
            color='steelblue', alpha=0.6, label='Rotated coords')
    ax.plot(x_grid, pdf_vals, 'r-', lw=2,
            label=f'Beta({a_param:.1f},{b_param:.1f})')
    ax.set_title(f'Coord distribution — {dist}', fontsize=10)
    ax.set_xlabel('Coordinate value')
    ax.set_ylabel('Density')
    ax.legend(fontsize=8)
    ax.set_xlim(-1, 1)

# --- Row 1: KL boxplots ---
print(f"\n{'dist':12s}  {'KL MSE '+str(N_BITS)+'bit':>14s}  "
      f"{'KL MSE+QJL '+str(N_BITS)+'bit':>16s}  winner")

for col, dist in enumerate(dists):
    print(f"Running {dist}...")
    kl_mse, kl_qjl = run_experiment(
        dist, centroids_full, boundaries_full,
        centroids_reduced, boundaries_reduced,
        d=D, n_keys=N_KEYS, n_trials=N_TRIALS)

    ax = axes[1, col]
    bp = ax.boxplot([kl_mse, kl_qjl],
                    tick_labels=[f'MSE\n{N_BITS}-bit', f'MSE+QJL\n{N_BITS-1}+1 bit'],
                    patch_artist=True,
                    medianprops=dict(color='black', lw=2))
    for patch, color in zip(bp['boxes'], ['tomato', 'steelblue']):
        patch.set_facecolor(color)

    winner = 'MSE' if np.mean(kl_mse) < np.mean(kl_qjl) else 'MSE+QJL'
    ax.set_title(f'{dist}  —  winner: {winner}', fontsize=10)
    ax.set_ylabel('KL divergence')
    ax.set_yscale('log')

    print(f"{dist:12s}  {np.mean(kl_mse):>14.6f}  {np.mean(kl_qjl):>16.6f}  {winner}")

plt.tight_layout()
out = f'turbo_d{D}_b{N_BITS}.png'
plt.savefig(out, dpi=150, bbox_inches='tight')
print(f"\nSaved: {out}")
