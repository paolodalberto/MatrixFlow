"""
d2_scatter2d.py  —  2D error scatter: sin(theta) vs NF
=======================================================
Default mode: color by budget, all budgets shown.
S-mode (--color_by S --budget B): color by sequence length within one budget,
  reveals whether S is the variance source within a budget cluster.

X axis: sin(theta) = sqrt(1 - cosine^2)   [true angular distance in [0,1]]
Y axis: NF = relMSE / (1 + relMSE)        [noise fraction in [0,1)]

Usage:
    # color by budget (default)
    python d2_scatter2d.py sq_full_final.csv \
        --regime unit_sphere --scheme TQ-QKQV \
        --out scatter_unit_TQ-QKQV.png

    # color by S within a single budget
    python d2_scatter2d.py sq_full_final.csv \
        --regime unit_sphere --scheme TQ-QKQV \
        --color_by S --budget 3 \
        --out scatter_unit_TQ-QKQV_b3_byS.png
"""

import argparse
import pathlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BUDGET_COLORS = {
    2: "#e41a1c",
    3: "#ff7f00",
    4: "#cccc00",
    5: "#4daf4a",
    6: "#377eb8",
    7: "#984ea3",
}

ap = argparse.ArgumentParser()
ap.add_argument("csv")
ap.add_argument("--regime",    required=True)
ap.add_argument("--scheme",    required=True)
ap.add_argument("--color_by",  default="budget", choices=["budget", "S"])
ap.add_argument("--budget",    type=int, default=None,
                help="Filter to single budget (required when --color_by S)")
ap.add_argument("--out",       default="scatter2d.png")
ap.add_argument("--dpi",       type=int, default=180)
ap.add_argument("--alpha",     type=float, default=0.45)
ap.add_argument("--size",      type=float, default=10)
args = ap.parse_args()

df = pd.read_csv(args.csv)
df.columns = [c.strip() for c in df.columns]

sub = df[(df["regime"] == args.regime) & (df["scheme"] == args.scheme)].copy()
if args.budget is not None:
    sub = sub[sub["budget"] == args.budget]
if sub.empty:
    print(f"No data for regime={args.regime} scheme={args.scheme} budget={args.budget}")
    exit(1)

cos = sub["cosine"].clip(-1.0, 1.0)
sub["sin_theta"] = np.sqrt(np.maximum(0.0, 1.0 - cos**2))
sub["NF"]        = sub["relMSE"] / (1.0 + sub["relMSE"])

fig, ax = plt.subplots(figsize=(6.5, 5.5))

if args.color_by == "budget":
    budgets = sorted(sub["budget"].unique())
    for b in budgets:
        rows = sub[sub["budget"] == b]
        color = BUDGET_COLORS.get(b, "gray")
        ax.scatter(rows["sin_theta"], rows["NF"],
                   c=color, s=args.size, alpha=args.alpha, zorder=2)
        mx, my = rows["sin_theta"].median(), rows["NF"].median()
        ax.scatter(mx, my, c=color, s=90, marker="D",
                   edgecolors="black", linewidths=0.7, zorder=4)
        ax.annotate(f"$b={b}$", (mx, my),
                    textcoords="offset points", xytext=(5, 3),
                    fontsize=7.5, color=color, fontweight="bold")
    handles = [plt.scatter([], [], c=BUDGET_COLORS.get(b,"gray"), s=30, label=f"$b={b}$")
               for b in budgets]
    ax.legend(handles=handles, title="budget", fontsize=8, title_fontsize=8,
              loc="upper right", framealpha=0.92, edgecolor="lightgray")
    title_suffix = ""

else:  # color_by S
    S_values = sorted(sub["S"].unique())
    try:
        cmap = matplotlib.colormaps["plasma"]
    except AttributeError:
        import matplotlib.cm as cm
        cmap = cm.get_cmap("plasma")
    colors = {s: cmap((i + 1) / (len(S_values) + 2)) for i, s in enumerate(S_values)}

    for s in S_values:
        rows = sub[sub["S"] == s]
        color = colors[s]
        ax.scatter(rows["sin_theta"], rows["NF"],
                   c=[color], s=args.size, alpha=args.alpha, zorder=2)
        mx, my = rows["sin_theta"].median(), rows["NF"].median()
        ax.scatter(mx, my, c=[color], s=90, marker="D",
                   edgecolors="black", linewidths=0.7, zorder=4)
        ax.annotate(f"$S={s}$", (mx, my),
                    textcoords="offset points", xytext=(5, 3),
                    fontsize=7.5, color=color, fontweight="bold")

    handles = [plt.scatter([], [], c=[colors[s]], s=30, label=f"$S={s}$")
               for s in S_values]
    ax.legend(handles=handles, title="seq len $S$", fontsize=8, title_fontsize=8,
              loc="upper right", framealpha=0.92, edgecolor="lightgray")
    title_suffix = f"  [b={args.budget}]"

# iso-d_2 arcs
theta = np.linspace(0, np.pi/2, 300)
for d2 in [0.25, 0.5, 0.75, 1.0, 1.2]:
    ax.plot(d2*np.cos(theta), d2*np.sin(theta),
            color="lightgray", lw=0.7, ls="--", zorder=0)
    ax.annotate(f"$d_2={d2}$",
                (d2*np.cos(np.pi/6), d2*np.sin(np.pi/6)),
                fontsize=6, color="gray", ha="left")

ax.set_xlabel(r"$\sin\theta = \sqrt{1 - \mathrm{cosine}^2}$  (angular error)", fontsize=11)
ax.set_ylabel(r"$\mathrm{NF} = \frac{\mathrm{relMSE}}{1+\mathrm{relMSE}}$  (noise fraction)", fontsize=11)
ax.set_title(f"{args.regime} / {args.scheme}{title_suffix}", fontsize=11, fontweight="bold")
ax.set_xlim(0, None); ax.set_ylim(0, None)
ax.grid(True, alpha=0.2, lw=0.6)
ax.spines[["top", "right"]].set_visible(False)

out = pathlib.Path(args.out)
out.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(out, dpi=args.dpi, bbox_inches="tight")
print(f"Saved -> {out}")
plt.close(fig)
