"""
inspect_v_quantization.py  —  look directly at V and quantize(V)
=================================================================
For a single unit_sphere token, show what happens at each stage of
TQ encoding at b=2 (1-bit MSE) and b=3 (2-bit MSE), with and without QJL.

Run:
    python inspect_v_quantization.py
"""

import numpy as np
import sys
sys.path.insert(0, ".")
from turbo_proto import TurboQuantCodec, solve_lloyd_max_beta, wht_rotate, fwht_batch

rng = np.random.default_rng(42)
d   = 128
N   = 10_000   # tokens — enough to get stable means

# draw N unit-sphere tokens
V_raw = rng.standard_normal((N, d))
V_raw /= np.linalg.norm(V_raw, axis=1, keepdims=True)

wht_signs = rng.choice([-1., 1.], size=d)
qjl_signs = rng.choice([-1., 1.], size=d)

print(f"N={N} unit-sphere tokens, d={d}")
print(f"token norm: mean={np.linalg.norm(V_raw, axis=1).mean():.4f}  "
      f"std={np.linalg.norm(V_raw, axis=1).std():.6f}")
print()

from turbo_proto import wht_rotate_inv

for b_mse in [1, 2]:
    centroids, boundaries = solve_lloyd_max_beta(d, b_mse)
    n_levels = len(centroids)

    print(f"{'='*60}")
    print(f"b_mse={b_mse}  ({n_levels} centroids)")
    print(f"  centroids:  {centroids.round(5)}")
    print(f"  boundaries: {boundaries.round(5)}")
    print()

    # WHT rotate all tokens
    V_rot = wht_rotate(V_raw, wht_signs)   # (N, d)

    # Quantize
    idx    = np.clip(np.searchsorted(boundaries[1:-1], V_rot), 0, n_levels-1)
    V_quant = centroids[idx]               # (N, d)

    residuals  = V_rot - V_quant           # (N, d)
    r_norms    = np.linalg.norm(residuals, axis=1)           # (N,)
    v_norms    = np.linalg.norm(V_rot,     axis=1)           # (N,) = 1
    cos_res_rot = np.sum(residuals * V_rot, axis=1) / (v_norms * r_norms + 1e-12)

    print(f"  After quantize ({N} tokens):")
    print(f"    residual norm:       mean={r_norms.mean():.4f}  std={r_norms.std():.4f}")
    print(f"    cos(residual,v_rot): mean={cos_res_rot.mean():.4f}  std={cos_res_rot.std():.4f}")
    print()

    # QJL correction
    qjl_bits  = np.sign(fwht_batch(residuals * qjl_signs[np.newaxis, :]))  # (N,d)
    r_hat     = (fwht_batch(qjl_bits) * qjl_signs[np.newaxis, :]
                 / d * np.sqrt(np.pi / 2.0) * r_norms[:, np.newaxis])
    V_corrected = V_quant + r_hat

    residuals_after = V_rot - V_corrected
    r_norms_after   = np.linalg.norm(residuals_after, axis=1)
    cos_rhat_res    = (np.sum(r_hat * residuals, axis=1)
                       / (np.linalg.norm(r_hat, axis=1) * r_norms + 1e-12))

    print(f"  After QJL correction ({N} tokens):")
    print(f"    cos(r_hat, residual): mean={cos_rhat_res.mean():.4f}  std={cos_rhat_res.std():.4f}")
    print(f"    residual reduction:   mean={100*(1-r_norms_after/r_norms).mean():.1f}%  "
          f"std={100*(1-r_norms_after/r_norms).std():.1f}%")
    print()

    # Token-space metrics
    V_hat_no  = wht_rotate_inv(V_quant,    wht_signs)   # (N, d)
    V_hat_qjl = wht_rotate_inv(V_corrected, wht_signs)  # (N, d)

    def metrics(V_true, V_hat):
        cos    = np.sum(V_true * V_hat, axis=1) / (
                    np.linalg.norm(V_hat, axis=1) * np.linalg.norm(V_true, axis=1) + 1e-12)
        relmse = np.sum((V_true - V_hat)**2, axis=1) / np.sum(V_true**2, axis=1)
        return cos, relmse

    cos_no,  relmse_no  = metrics(V_raw, V_hat_no)
    cos_qjl, relmse_qjl = metrics(V_raw, V_hat_qjl)

    print(f"  Token-space quality ({N} tokens):")
    print(f"    {'':12s}  {'1-cosine':>12s}  {'relMSE':>12s}")
    print(f"    {'no QJL':12s}  {(1-cos_no).mean():>10.4f}±{(1-cos_no).std():>6.4f}"
          f"  {relmse_no.mean():>10.4f}±{relmse_no.std():>6.4f}")
    print(f"    {'with QJL':12s}  {(1-cos_qjl).mean():>10.4f}±{(1-cos_qjl).std():>6.4f}"
          f"  {relmse_qjl.mean():>10.4f}±{relmse_qjl.std():>6.4f}")
    print()
